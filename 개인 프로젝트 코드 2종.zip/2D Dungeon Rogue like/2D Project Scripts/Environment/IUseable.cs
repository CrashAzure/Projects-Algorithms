// Use this interface for components that the player can use
public interface IUseable
{
    void UseItem();
}