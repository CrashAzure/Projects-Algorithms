using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="Boss_Room_Coin_", menuName ="Scriptable Objects/Dungeon/Boss Room Coin")]
public class BossRoomCoinSO : ScriptableObject
{
    public Sprite coinImage;
    public Color coinColor;
    public int dungeonLevelForCoin;
}
