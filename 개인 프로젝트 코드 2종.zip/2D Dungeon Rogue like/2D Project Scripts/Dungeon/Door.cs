using UnityEngine;

[RequireComponent(typeof(Animator))]
[DisallowMultipleComponent]
public class Door : MonoBehaviour
{
    #region Header Object References
    [Space(10)]
    [Header("Object References")]
    #endregion Header
    #region Tooltip
    [Tooltip("Populate Box Collider 2D on DoorCollider gameObejct")]
    #endregion Tooltip
    [SerializeField] private BoxCollider2D doorCollider;
    [SerializeField] private BoxCollider2D doorColliderWithTeleportIcon;

    [HideInInspector] public bool isBossRoomDoor = false;

    private BoxCollider2D doorTrigger;
    private bool isOpen = false;
    private bool previouslyOpened = false;
    private Animator animator;

    private void Awake()
    {
        // disable door collider by default
        doorCollider.enabled = false;

        // Get Components
        animator = GetComponent<Animator>();
        doorTrigger = GetComponent<BoxCollider2D>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        CheckTagForCollider(collision);
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        CheckTagForCollider(collision);
    }

    private void OnEnable()
    {
        // when parent gameObject is disabled
        // (when player moves far enough away from this room)
        // animator have to get reset
        animator.SetBool(Settings.open, isOpen);    
    }

    /// <summary>
    /// Open door
    /// </summary>
    public void OpenDoor()
    {
        if (!isOpen)
        {
            isOpen = true;
            previouslyOpened = true;
            doorCollider.enabled = false;
            doorTrigger.enabled = false;

            // Set open parameter in animator
            animator.SetBool(Settings.open, true);

            // play door open sounds
            SoundEffectManager.Instance.PlaySoundEffect(GameResources.Instance.doorOpenCloseSoundEffect);
        }
    }

    /// <summary>
    /// Lock Door
    /// </summary>
    public void LockDoor()
    {
        isOpen = false;
        doorCollider.enabled = true;
        doorTrigger.enabled = false;

        // Set open Parameter to false
        animator.SetBool(Settings.open, false);
    }

    /// <summary>
    ///  UnlockDoor
    /// </summary>
    public void UnlockDoor()
    {
        if (isOpen) return;
        doorCollider.enabled = false;
        doorTrigger.enabled = true;

        if(previouslyOpened == true)
        {
            isOpen = false;
            OpenDoor();
        }
    }

    /// <summary>
    /// Check collider tag
    /// </summary>
    private void CheckTagForCollider(Collider2D collision)
    {
        if (collision.tag == Settings.playerTag || collision.tag == Settings.playerWeapon)
        {
            OpenDoor();

            doorColliderWithTeleportIcon.enabled = false;
        }
    }

    #region Validation
#if UNITY_EDITOR
    private void OnValidate()
    {
        HelperUtilities.ValidateCheckNullValue(this, nameof(doorCollider), doorCollider);
    }
#endif
    #endregion Validation

}
