using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Player))]
[DisallowMultipleComponent]
public class PlayerControl : MonoBehaviour
{
    #region Tooltip
    [Tooltip("MovenmentDetailsSO contains movement details such as speed")]
    #endregion Tooltip
    public MovementDetailsSO movementDetail;

    private Player player;
    private ReloadWeapon reloadWeapon;
    private bool leftMouseDownPreviousFrame = false;
    private int currentWeaponIndex = 1;
    private float moveSpeed;
    private Coroutine playerRollCoroutine;
    private WaitForFixedUpdate waitForFixedUpdate;
    [HideInInspector] public bool isPlayerRolling = false;
    private bool isPlayerMovementDisabled = false;
    private bool isChangingWeapon = false;
    private bool isProcessCoroutine = false;
    private bool isStart = true;
    private float playerRollCooldownTimer = 0f;
    private float playerTeleportCooldownTimer = 0f;
    private float playerWeaponChangeTimer = 0f;
    private Weapon previousWeapon;
    private Coroutine playerWeaponCoroutine;

    private Vector3 weaponDirection;
    private float weaponAngleDegrees, playerAngleDegrees;
    private AimDirection playerAimDirection;

    private GameObject teleportObject = null;


    private void Awake()
    {
        player = GetComponent<Player>();
        reloadWeapon = GetComponent<ReloadWeapon>();
        moveSpeed = movementDetail.GetMoveSpeed();
    }

    private void Start()
    {
        // Create waitForFixedupdate for coroutine
        waitForFixedUpdate = new WaitForFixedUpdate();

        // Set Starting Weapon
        SetStartingWeapon();
        
        // Set player animating speed
        SetPlayerAnimationSpeed();

        previousWeapon = player.activeWeapon.GetCurrentWeapon();

        isStart = false;
    }

    

    /// <summary>
    /// Set Starating Weapon
    /// </summary>
    private void SetStartingWeapon()
    {
        int index = 1;

        foreach(Weapon weapon in player.weaponList)
        {
            if(weapon.weaponDetails == player.playerDetails.startingWeapon)
            {
                SetWeaponByIndex(index);
                break;
            }
            index++;
        }
    }


    /// <summary>
    /// Set Player Animation's Speed
    /// </summary>
    private void SetPlayerAnimationSpeed()
    {
        // Set animator speed to match moveSpeed
        player.animator.speed = moveSpeed / Settings.baseSpeedForPlayerAnimations;
    }

    private void Update()
    {
        // if player movement disabled then return
        if (isPlayerMovementDisabled)
            return;

        // if player is rolling, block other Input process
        if (isPlayerRolling) return;

        // Set weapon changing delay from current wapon detail's swapping sound effect length
        SetSwappingTime();

        // Process player movement Input
        MovementInput();

        // Process player weapon Input
        WeaponInput();

        ItemInput();

        PlayerRollCooldownTimer();
    }

    
    /// <summary>
    /// Disable the player movement
    /// </summary>
    public void DisablePlayer()
    {
        isPlayerMovementDisabled = true;
        player.idleEvent.CallIdleEvent();
    }

    /// <summary>
    /// Enable the player movement
    /// </summary>
    public void EnablePlayer()
    {
        isPlayerMovementDisabled = false;
    }

    /// <summary>
    /// Set weapon changing delay from current wapon detail's swapping sound effect length
    /// </summary>
    private void SetSwappingTime()
    {
        if(player.activeWeapon.GetCurrentWeapon().weaponDetails.weaponSwapSoundEffect != null)
        {
            player.playerDetails.weaponChangingDelay = player.activeWeapon.GetCurrentWeapon().weaponDetails.weaponSwapSoundEffect.soundEffectClip.length;
        }
    }

    /// <summary>
    /// Process player movement Input
    /// </summary>
    private void MovementInput()
    {
        // Get movement Input
        float horizontalMovement = Input.GetAxisRaw("Horizontal");
        float verticalMovement = Input.GetAxisRaw("Vertical");
        bool isRightMouseButtonDown = Input.GetMouseButtonDown(1);

        // Create a direction parameter based on Input values
        Vector2 direction = new Vector2(horizontalMovement, verticalMovement);

        // distance for diagonal movement
        if(direction.x != 0f && direction.y != 0f)
        {
            direction *= 0.7f;
        }

        // if there is movement move or roll
        if (direction != Vector2.zero)
        {
            if (!isRightMouseButtonDown)
            {
                player.movementByVelocityEvent.CallOnMovementByVelocity(direction, moveSpeed);
            }
            // player roll if not cooling down
            else if (playerRollCooldownTimer <= 0f && player.playerDetails.playerCharacterName != Settings.CharacterName.magician)
            {
                PlayerRoll((Vector3)direction);
                return;
            }
        }
        else
        {
            player.idleEvent.CallIdleEvent();
        }

        // If its magiacian character, Process Teleport with right mouse button
        if (playerTeleportCooldownTimer <= 0f && player.playerDetails.playerCharacterName == Settings.CharacterName.magician)
        {
            ProcessTeleport();

            //Room currentRoom = GameManager.Instance.GetCurrentRoom();

            //if (currentRoom.roomNodeType.isCorridor)
            //{
            //    Destroy(teleportObject);
            //}
            //else
            //{
            //    ProcessTeleport();
            //}
        }
        

    }

    /// <summary>
    /// Process Teleport
    /// </summary>
    private void ProcessTeleport()
    {
        // when player hold down right click
        if (Input.GetMouseButton(1))
        {
            // get prefab object
            GameObject teleportPrefab = Resources.Load<GameObject>("TeleportPointObject");

            // instantiate object
            InstantiateTeleportObject(teleportPrefab);

            // get aim direction for flip Icon
            Vector3 iconDir = teleportObject.transform.position - transform.position;
            Teleport teleport = teleportObject.GetComponent<Teleport>();

            // Process teleport object
            teleport.ProcessTeleportObject(iconDir);
        }
        DoTeleport();
        
    }
    private void InstantiateTeleportObject(GameObject teleportPrefab)
    {
        if (teleportObject != null) return;
        if (teleportPrefab == null) return;

        // instantiate object
        teleportObject = Instantiate(teleportPrefab, transform);
        // set position bcs of pivot
        teleportObject.transform.position += Vector3.up;
    }

    /// <summary>
    /// Teleport cool down method
    /// </summary>
    public void TeleportCoolDown()
    {
        playerTeleportCooldownTimer = movementDetail.teleportCooldownTime;
        StartCoroutine(TelportColldownCoroutine(playerTeleportCooldownTimer));
    }

    /// <summary>
    /// Teleport player position and destroy target object to teleport
    /// </summary>
    private void DoTeleport()
    {
        if (teleportObject == null) return;
        if (!Input.GetMouseButtonUp(1)) return;

        transform.position = teleportObject.transform.position;
        Destroy(teleportObject);
        playerTeleportCooldownTimer = movementDetail.teleportCooldownTime;
        StartCoroutine(TelportColldownCoroutine(playerTeleportCooldownTimer));
    }

    /// <summary>
    /// Cool down coroutine for teleport
    /// </summary>
    private IEnumerator TelportColldownCoroutine(float playerTeleportCooldownTimer)
    {
        while(playerTeleportCooldownTimer > 0f)
        {
            playerTeleportCooldownTimer -= Time.deltaTime;
            yield return null;
        }

        this.playerTeleportCooldownTimer = 0f;
    }

    /// <summary>
    /// Process player Weapon Input
    /// </summary>
    private void WeaponInput()
    {
        //Vector3 weaponDirection;
        //float weaponAngleDegrees, playerAngleDegrees;
        //AimDirection playerAimDirection;

        // Aim weapon input
        AimWeaponInput(out weaponDirection, out weaponAngleDegrees, out playerAngleDegrees, out playerAimDirection);

        // Check weapon can fire and reload
        CheckWeaponForFireAndReload(weaponDirection, weaponAngleDegrees, playerAngleDegrees, playerAimDirection);
        
        // Switch weapon input
        SwitchWeaponInput();
    }

    /// <summary>
    /// Check weapon can fire
    /// </summary>
    private void CheckWeaponForFireAndReload(Vector3 weaponDirection, float weaponAngleDegrees, float playerAngleDegrees, AimDirection playerAimDirection)
    {
        if (player.activeWeapon.GetCurrentWeapon().isWeaponReloading)
        {
            ReloadWeaponInput();
            return; 
        }

        // not on swapping
        if (!isChangingWeapon)
        {
            // Fire weapon input
            FireWeaponInput(weaponDirection, weaponAngleDegrees, playerAngleDegrees, playerAimDirection);
            // Reload weapon input
            ReloadWeaponInput();
        }
        else if (!isProcessCoroutine)
        {
            // Stop coroutine
            StopWeaponCoroutine();
            playerWeaponCoroutine = StartCoroutine(IEFireAndRloadWeaponInput());
        }
    }

    /// <summary>
    /// If there is the coroutine, Then stop First fire weapon coroutine after weapon swapping
    /// </summary>
    private void StopWeaponCoroutine()
    {
        if (playerWeaponCoroutine != null)
        {
            StopCoroutine(playerWeaponCoroutine);
        }
    }

    /// <summary>
    /// Fire wepon input coroutine after swapping weapon for weapon changing delay
    /// </summary>
    private IEnumerator IEFireAndRloadWeaponInput()
    {
        // this parameter prevents to overlap on Update Method
        isProcessCoroutine = true;

        // wait for swapping delay
        yield return new WaitForSeconds(player.playerDetails.weaponChangingDelay);

        // after swapping
        // fire weapon input
        FireWeaponInput(weaponDirection, weaponAngleDegrees, playerAngleDegrees, playerAimDirection);
        // reload weapon input
        ReloadWeaponInput();

        isProcessCoroutine = false;
        isChangingWeapon = false;
    }

    private void AimWeaponInput(out Vector3 weaponDirection, out float weaponAngleDegrees, 
                                out float playerAngleDegrees, out AimDirection playerAimDirection)
    {
        // Get Mouse world position using HelperUtilities' method
        Vector3 mouseWorldPosition = HelperUtilities.GetMouseWorldPosition();

        // Calculate direction vector of mouse cursor from weapon shoot position
        weaponDirection = (mouseWorldPosition - player.activeWeapon.GetShootPosition());

        // Calculate direction vector of mouse cursor from player position
        Vector3 playerDirection = (mouseWorldPosition - transform.position);
        
        // Get player cursor and weapon cursor angle
        playerAngleDegrees = HelperUtilities.GetAngleFromVector(playerDirection);
        weaponAngleDegrees = HelperUtilities.GetAngleFromVector(weaponDirection);

        // Get Aim Direction using HelperUtilities' method
        // Can get Aim direction if we get player angle degrees
        playerAimDirection = HelperUtilities.GetAimDirection(playerAngleDegrees);


        player.aimWeaponEvent.CallAimWeaponEvent(playerAimDirection, playerAngleDegrees, weaponAngleDegrees, weaponDirection);
    }


    /// <summary>
    /// Fire Weapon Input using weapon direction and angle and player aim direction and angle
    /// </summary>
    private void FireWeaponInput(Vector3 weaponDirection, float weaponAngleDegrees, float playerAngleDegrees, AimDirection playerAimDirection)
    {
        // Get Left Click
        if (Input.GetMouseButton(0))
        {
            // Call fire waepon event
            player.fireWeaponEvent.CallFireWeaponEvent(true, leftMouseDownPreviousFrame, playerAimDirection, playerAngleDegrees, weaponAngleDegrees, weaponDirection);
            leftMouseDownPreviousFrame = true;
        }
        else
        {
            leftMouseDownPreviousFrame = false;
        }
    }


    /// <summary>
    /// Reload Weapon Input
    /// </summary>
    private void ReloadWeaponInput()
    {
        Weapon currentWeapon = player.activeWeapon.GetCurrentWeapon();

        if (currentWeapon == null) return;

        
        // if current weapon is reloading
        if (currentWeapon.isWeaponReloading) 
        {
            // is there mouse right button down?
            CheckLeftMouseClickingForReloading(currentWeapon);
            return; 
        }

        if(currentWeapon.weaponDetails.weaponName != "Shotgun")
        {
            // if remaining ammo is less than clip capacity and not infinite ammo
            if (currentWeapon.weaponRemainingAmmo < currentWeapon.weaponDetails.weaponClipAmmoCapacity
                && !currentWeapon.weaponDetails.hasInfiniteAmmo) return;
        }

        if (currentWeapon.weaponClipRemainingAmmo == currentWeapon.weaponDetails.weaponClipAmmoCapacity) return;

        if (Input.GetKeyDown(KeyCode.R))
        {
            // Call ReloadWeaponEvent
            player.reloadWeaponEvent.CallReloadWeapon(currentWeapon, 0);
        }

    }

    /// <summary>
    /// is there mouse right button down?
    /// </summary>
    private void CheckLeftMouseClickingForReloading(Weapon currentWeapon)
    {
        // if current weapon is reloading and right mouse button clicked
        if (currentWeapon.weaponDetails.weaponName != "Shotgun") return;
        if (!Input.GetMouseButtonDown(0)) return;
        if (currentWeapon.weaponClipRemainingAmmo == 0) return;

        StartCoroutine(playerWeaponChangeCoroutine());
        player.weaponStatusUI?.SetReloadingBarColor(Color.green);
        StopReloading();
        reloadWeapon.weaponReloadedEvent.CallWeaponReloaded(currentWeapon);
    }


    /// <summary>
    /// Player Roll Cooldown Timer
    /// </summary>
    private void PlayerRollCooldownTimer()
    {
        if(playerRollCooldownTimer >= 0f)
        {
            playerRollCooldownTimer -= Time.deltaTime;

        }
    }

    /// <summary>
    /// Player Roll
    /// </summary>
    private void PlayerRoll(Vector3 direction)
    {
        playerRollCoroutine = StartCoroutine(PlayerRollCoroutine(direction));
    }

    /// <summary>
    /// Player Roll Coroutine
    /// </summary>
    private IEnumerator PlayerRollCoroutine(Vector3 direction)
    {
        // minDistance used to decide when to exit coroutine loop
        float minDistance = 0.2f;

        isPlayerRolling = true;

        Vector3 targetPosition = player.transform.position + (Vector3)direction * movementDetail.rollDistance;

        // Until that distance to target Position to be minDistance
        while(Vector3.Distance(player.transform.position, targetPosition) > minDistance)
        {
            // Call MovementToPositionEvent
            player.movementToPositionEvent.CallOnMovementToPosition(targetPosition, player.transform.position, 
                                                                    movementDetail.rollSpeed, direction, isPlayerRolling);
            // yield and wait for fixed update
            yield return waitForFixedUpdate;
        }

        isPlayerRolling = false;

        // Init Cooldown Timer
        playerRollCooldownTimer = movementDetail.rollCooldownTime;
        // if that distance is less than minDistance, player places at targetPosition
        player.transform.position = targetPosition;
    }

    /// <summary>
    /// Switch weapon input
    /// </summary>
    private void SwitchWeaponInput()
    {
        // Switch weapon if mouse scroll down
        if (Input.mouseScrollDelta.y < 0f)
        {
            PreviousWeapon();
        }

        if(Input.mouseScrollDelta.y > 0f)
        {
            NextWeapon();
        }

        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            SetWeaponByIndex(1);
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            SetWeaponByIndex(2);
        }
        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            SetWeaponByIndex(3);
        }
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            SetWeaponByIndex(4);
        }
        if (Input.GetKeyDown(KeyCode.Alpha5))
        {
            SetWeaponByIndex(5);
        }
        if (Input.GetKeyDown(KeyCode.Alpha6))
        {
            SetWeaponByIndex(6);
        }
        if (Input.GetKeyDown(KeyCode.Alpha7))
        {
            SetWeaponByIndex(7);
        }
        if (Input.GetKeyDown(KeyCode.Alpha8))
        {
            SetWeaponByIndex(8);
        }
        if (Input.GetKeyDown(KeyCode.Alpha9))
        {
            SetWeaponByIndex(9);
        }
        if (Input.GetKeyDown(KeyCode.Alpha0))
        {
            SetWeaponByIndex(10);
        }
        if (Input.GetKeyDown(KeyCode.Minus))
        {
            SetCurrentWeaponToFirstInTheList();
        }

    }

    private void PreviousWeapon()
    {
        currentWeaponIndex--;

        if (currentWeaponIndex < 1)
        {
            currentWeaponIndex = player.weaponList.Count;
        }

        SetWeaponByIndex(currentWeaponIndex);
    }

    private void NextWeapon()
    {
        currentWeaponIndex++;

        if (currentWeaponIndex > player.weaponList.Count)
        {
            currentWeaponIndex = 1;
        }

        SetWeaponByIndex(currentWeaponIndex);
    }

    /// <summary>
    /// Set current weapon to be first in player weapon list
    /// </summary>
    private void SetCurrentWeaponToFirstInTheList()
    {
        // Create new temporary list
        List<Weapon> tempWeaponList = new List<Weapon>();

        // Add current weapon first in temporary list
        Weapon currentWeapon = player.weaponList[currentWeaponIndex - 1];
        currentWeapon.weaponListPosition = 1;
        tempWeaponList.Add(currentWeapon);

        // loop through existing weapon list and add
        int index = 2;

        foreach(Weapon weapon in player.weaponList)
        {
            if (weapon == currentWeapon) continue;

            tempWeaponList.Add(weapon);
            weapon.weaponListPosition = index;
            index++;
        }

        // Assign new list
        player.weaponList = tempWeaponList;

        // Set current weapon
        SetWeaponByIndex(currentWeaponIndex);
    }


    /// <summary>
    /// Set weapon by index
    /// </summary>
    private void SetWeaponByIndex(int index)
    {
        if (playerWeaponChangeTimer > 0f) return;
        if (index - 1 >= player.weaponList.Count) return;

        previousWeapon = player.activeWeapon.GetCurrentWeapon();
        currentWeaponIndex = index;
        player.setActiveWeaponEvent.CallSetActiveWeaponEvent(player.weaponList[index - 1]);

        if (previousWeapon != player.activeWeapon.GetCurrentWeapon() && previousWeapon.isWeaponReloading)
        {
            StopReloading();
        }

        if (isStart) return;

        StartCoroutine(playerWeaponChangeCoroutine());
    }

    private IEnumerator playerWeaponChangeCoroutine()
    {
        isChangingWeapon = true;

        if (player.activeWeapon.GetCurrentWeapon().weaponDetails.weaponSwapSoundEffect != null)
        {
            SoundEffectManager.Instance.PlaySoundEffect(player.activeWeapon.GetCurrentWeapon().weaponDetails.weaponSwapSoundEffect);
        }

        while (playerWeaponChangeTimer <= player.playerDetails.weaponChangingDelay)
        {
            playerWeaponChangeTimer += Time.deltaTime;
            yield return null;
        }

        playerWeaponChangeTimer = 0f;
    }

    private void OnCollisionEnter2D(Collision2D collision)
     {
        // If player collided something , stop roll coroutine
        StopPlayerRollCoroutine();
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        // If player collided something , stop roll coroutine
        StopPlayerRollCoroutine();
    }

    private void StopPlayerRollCoroutine()
    {
        if(playerRollCoroutine != null)
        {
            StopCoroutine(playerRollCoroutine);
            isPlayerRolling = false;
        }
    }

    /// <summary>
    /// Stop reloading when there is changing weapon or left click
    /// </summary>
    private void StopReloading()
    {
        reloadWeapon.StopReloadWeaponCoroutine();
        SoundEffectManager.Instance.StopSoundEffectsOnList();

        foreach (Weapon weapon in player.weaponList)
        {
            reloadWeapon.resetReloadingParameters(weapon);
        }
    }

    /// <summary>
    /// Input for item interactive
    /// </summary>
    private void ItemInput()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            float usingItemRadius = 3.0f;

            Collider2D[] colliderArray = Physics2D.OverlapCircleAll(player.GetPlayerPosition(), usingItemRadius);

            foreach(Collider2D collider in colliderArray)
            {
                IUseable item =  collider.GetComponent<IUseable>();

                item?.UseItem();
            }
        }
    }



    #region Validation
#if UNITY_EDITOR
    private void OnValidate()
    {
        HelperUtilities.ValidateCheckNullValue(this, nameof(movementDetail), movementDetail);
    }
#endif
    #endregion Validation
}
