using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="MovementDetails_", menuName = "Scriptable Objects/Movement/MovementDetails")]
public class MovementDetailsSO : ScriptableObject
{
    #region Header Movement Details
    [Space(10)]
    [Header("Movement Details")]
    #endregion Header
    #region Tooltip
    [Tooltip("Minimum move speed. GetMoveSpeed Method get random value between minimum and maximum")]
    #endregion
    public float minMoveSpeed = 8f;
    #region Tooltip
    [Tooltip("Maximum move speed. GetMoveSpeed Method get random value between minimum and maximum")]
    #endregion
    public float maxMoveSpeed = 8f;
    #region Tooltip
    [Tooltip("its Roll Speed, if there is Roll Movement")]
    #endregion Tooltip
    public float rollSpeed;
    #region Tooltip
    [Tooltip("its rollDistance if there is Roll Movement")]
    #endregion Tooltip
    public float rollDistance;
    #region Tooltip
    [Tooltip("its a Roll Cool Down Time if there is Roll Movement")]
    #endregion Tooltip
    public float rollCooldownTime;
    #region Tooltip
    [Tooltip("its a Teleport Cool Down Time if there is Teleport Movement")]
    #endregion Tooltip
    public float teleportCooldownTime;
    #region Tooltip
    [Tooltip("its a Teleport maximum distance if there is Teleport Movement")]
    #endregion Tooltip
    public float maxTeleportDistance;



    /// <summary>
    /// Get a random value between minimum and maximum
    /// </summary>
    public float GetMoveSpeed()
    {
        if (minMoveSpeed == maxMoveSpeed)
        {
            return minMoveSpeed;
        }
        else
        {
            return Random.Range(minMoveSpeed, maxMoveSpeed);
        }
    }

    #region Validation
#if UNITY_EDITOR
    private void OnValidate()
    {
        HelperUtilities.ValidateCheckPositiveRange(this, nameof(minMoveSpeed), minMoveSpeed, nameof(maxMoveSpeed), maxMoveSpeed, false);

        if(rollSpeed != 0f || rollDistance != 0f || rollCooldownTime != 0f)
        {
            HelperUtilities.ValidateCheckPositiveValue(this ,nameof(rollDistance), rollDistance, false);
            HelperUtilities.ValidateCheckPositiveValue(this, nameof(rollSpeed), rollSpeed, false);
            HelperUtilities.ValidateCheckPositiveValue(this, nameof(rollCooldownTime), rollCooldownTime, false);
        }
    }
#endif
    #endregion Validation

}
