using Cinemachine.Utility;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Video;

public class Teleport : MonoBehaviour
{
    private PlayerControl playerControl;
    private Room currentRoom;

    //private CircleCollider2D circleCollider;
    //private List<RaycastHit2D> blockList = new List<RaycastHit2D>();

    void Awake()
    {
        playerControl = GetComponentInParent<PlayerControl>();
        //circleCollider = GetComponent<CircleCollider2D>();
    }

    #region Unusing Raycast method
    //private void TestRaycastTeleport(Vector3 cursorPoint)
    //{
    //    RaycastHit2D[] rayHits;

    //    float distanceToMousePoint = Vector3.Distance(playerControl.transform.position, cursorPoint);

    //    if (distanceToMousePoint > playerControl.movementDetail.maxTeleportDistance)
    //    {
    //        rayHits = Physics2D.RaycastAll(playerControl.transform.position, cursorPoint, playerControl.movementDetail.maxTeleportDistance);
    //    }
    //    else
    //    {
    //        rayHits = Physics2D.RaycastAll(playerControl.transform.position, cursorPoint, distanceToMousePoint);
    //    }

    //    if (rayHits.Length == 0) return;

    //    rayHits = rayHits.OrderBy(h => h.distance).ToArray();

    //    foreach (RaycastHit2D hit in rayHits)
    //    {
    //        if (hit.transform.gameObject.layer == 13)
    //        {
    //            blockList.Add(hit);
    //        }
    //    }

    //    if (blockList.Count == 0) return;

    //    Vector3 tempVector = (cursorPoint - playerControl.transform.position).normalized;
    //    float distance = Vector2.Distance(blockList[blockList.Count - 1].point, playerControl.transform.position);

    //    if (distance > playerControl.movementDetail.maxTeleportDistance)
    //    {
    //        distance = playerControl.movementDetail.maxTeleportDistance;
    //    }

    //    tempVector *= distance;

    //    tempVector += playerControl.transform.position;

    //    transform.position = tempVector;

    //}
    #endregion Unusing Raycast method

    /// <summary>
    /// Process teleport
    /// </summary>
    public void ProcessTeleportObject(Vector3 iconDir)
    {
        currentRoom = GameManager.Instance.GetCurrentRoom();
        Grid grid = currentRoom.instantiatedRoom.grid;
        int[,] currentRoomMoveableGrid = currentRoom.instantiatedRoom.astarMovementPenalty;

        MoveObjectToMousePoint();
        
        // world to cell
        Vector3Int teleportGridPosition = grid.WorldToCell(transform.position);
        Vector3Int playerGridPosition = grid.WorldToCell(playerControl.transform.position);

        // parallelMove to (0, 0) with left bottom position
        ParallelMove(ref teleportGridPosition, ref playerGridPosition);
                
        if (CheckUnmoveablePosition(currentRoomMoveableGrid, teleportGridPosition))
        {
            // generate into moveable grid index
            GenerateIntoMoveableGrid(ref teleportGridPosition, playerGridPosition, currentRoomMoveableGrid);
        }

        // parallel move back original grid position
        ParallelMoveback(ref teleportGridPosition, ref playerGridPosition);

        // cell to world
        transform.position = grid.CellToWorld(teleportGridPosition);

        // update image
        FlipTeleportIcon(iconDir.x);

        #region Unusing room upper and lower bounds method
        //if (currentRoom.roomNodeType.isEntrance)
        //{
        //    if (transform.position.x < currentRoom.lowerBounds.x + 4)
        //    {
        //        transform.position = new Vector2(currentRoom.lowerBounds.x + 4, transform.position.y);
        //    }

        //    if (transform.position.y < currentRoom.lowerBounds.y + 3)
        //    {
        //        transform.position = new Vector2(transform.position.x, currentRoom.lowerBounds.y + 3);
        //    }


        //    if (transform.position.x > currentRoom.upperBounds.x - 3)
        //    {
        //        transform.position = new Vector2(currentRoom.upperBounds.x - 3, transform.position.y);
        //    }

        //    if (transform.position.y > currentRoom.upperBounds.y - 5)
        //    {
        //        transform.position = new Vector2(transform.position.x, currentRoom.upperBounds.y - 5);
        //    }
        //}
        //else
        //{
        //    if (transform.position.x < currentRoom.lowerBounds.x + 6)
        //    {
        //        transform.position = new Vector2(currentRoom.lowerBounds.x + 6, transform.position.y);
        //    }

        //    if (transform.position.y < currentRoom.lowerBounds.y + 5)
        //    {
        //        transform.position = new Vector2(transform.position.x, currentRoom.lowerBounds.y + 5);
        //    }


        //    if (transform.position.x > currentRoom.upperBounds.x - 5)
        //    {
        //        transform.position = new Vector2(currentRoom.upperBounds.x - 5, transform.position.y);
        //    }

        //    if (transform.position.y > currentRoom.upperBounds.y - 7)
        //    {
        //        transform.position = new Vector2(transform.position.x, currentRoom.upperBounds.y - 7);
        //    }
        //}
        #endregion Unusing room upper and lower bounds method

        #region Unusing raycast method
        //if (cursorPoint.x < currentRoom.lowerBounds.x + 2 || cursorPoint.y < currentRoom.lowerBounds.y + 2
        //    || cursorPoint.x > currentRoom.upperBounds.x - 2 || cursorPoint.y > currentRoom.upperBounds.y - 2)
        //{
        //    Test(cursorPoint);
        //    return;
        //}
        #endregion Unusing raycast method

        #region Unusing Velocity method
        //FixTeleportObjectPosition();

        //if (isCollide) return;

        //// update position
        //UpdatePositionForTeleport();
        #endregion Unusing Velocity method
    }

    /// <summary>
    /// ParallelMove to (0, 0) with left bottom position
    /// </summary>
    private void ParallelMove(ref Vector3Int teleportGridPosition, ref Vector3Int playerGridPosition)
    {
        // parallel move
        teleportGridPosition.x -= currentRoom.templateLowerBounds.x;
        teleportGridPosition.y -= currentRoom.templateLowerBounds.y;
        playerGridPosition.x -= currentRoom.templateLowerBounds.x;
        playerGridPosition.y -= currentRoom.templateLowerBounds.y;
    }

    /// <summary>
    /// Parallel move back original grid position
    /// </summary>
    private void ParallelMoveback(ref Vector3Int teleportGridPosition, ref Vector3Int playerGridPosition)
    {
        // parallel move
        teleportGridPosition.x += currentRoom.templateLowerBounds.x;
        teleportGridPosition.y += currentRoom.templateLowerBounds.y;
        playerGridPosition.x += currentRoom.templateLowerBounds.x;
        playerGridPosition.y += currentRoom.templateLowerBounds.y;
    }

    /// <summary>
    /// Check teleport grid position is unmoveable position for condition
    /// </summary>
    private bool CheckUnmoveablePosition(int[,] currentRoomMoveableGrid, Vector3Int teleportGridPosition)
    {
        if(teleportGridPosition.x < 0 || teleportGridPosition.y < 0)
        {
            return true;
        }

        if(teleportGridPosition.x > currentRoom.templateUpperBounds.x - currentRoom.templateLowerBounds.x
            || teleportGridPosition.y > currentRoom.templateUpperBounds.y - currentRoom.templateLowerBounds.y)
        {
            return true;
        }

        if (currentRoomMoveableGrid[teleportGridPosition.x, teleportGridPosition.y] != 1)
        {
            return true;
        }

        return false;

    }

    #region Unusing Velocity methods
    //private void FixTeleportObjectPosition()
    //{
    //    // Maximum Distance
    //    if ((HelperUtilities.GetMouseWorldPosition() - playerControl.transform.position).magnitude > playerControl.movementDetail.maxTeleportDistance)
    //    {
    //        transform.position = (HelperUtilities.GetMouseWorldPosition() - playerControl.transform.position).normalized * playerControl.movementDetail.maxTeleportDistance;

    //        transform.position += playerControl.transform.position;
    //    }
    //    else
    //    {
    //        transform.position = HelperUtilities.GetMouseWorldPosition();
    //    }

    //    // prevent shaking Icon
    //    //if ((HelperUtilities.GetMouseWorldPosition() - transform.position).magnitude <= 0.5f)
    //    //{
    //    //    transform.position = HelperUtilities.GetMouseWorldPosition();
    //    //}

    //}


    ///// <summary>
    ///// Update rigidbody velocity
    ///// </summary>
    //private void UpdatePositionForTeleport()
    //{
    //    // this object and mouse position vector (direction of rigidbody velocity)
    //    Vector3 teleportDirection = HelperUtilities.GetMouseWorldPosition() - transform.position;

    //    //Rigidbody2D teleportRigidbody2D = teleportObject.GetComponent<Rigidbody2D>();
    //    //teleportRigidbody2D.velocity = Vector3.zero;
    //    //teleportRigidbody2D.velocity = ((Vector2)teleportDirection).normalized * 20f;

    //    transform.position = Vector3.Lerp(transform.position, HelperUtilities.GetMouseWorldPosition(), 0.05f);
    //}
    #endregion Unusing Velocity methods

    /// <summary>
    /// Move this gameobject to mouse point
    /// and re-fix with  max distance
    /// </summary>
    private void MoveObjectToMousePoint()
    {
        transform.position = HelperUtilities.GetMouseWorldPosition();

        // Maximum Distance
        if ((transform.position - playerControl.transform.position).magnitude > playerControl.movementDetail.maxTeleportDistance)
        {
            transform.position = (transform.position - playerControl.transform.position).normalized * playerControl.movementDetail.maxTeleportDistance;

            transform.position += playerControl.transform.position;
        }
    }

    /// <summary>
    /// Second generate teleport grid position into moveable grid with min distance
    /// </summary>
    private void GenerateIntoMoveableGrid(ref Vector3Int teleportGridPosition, Vector3Int playerGridPosition, int[,] currentRoomMoveableGrid)
    {
        if (teleportGridPosition == playerGridPosition) return;

        float x;
        float y;

        // Get incline for linear function
        float gapOfGridXPositions = teleportGridPosition.x - playerGridPosition.x;
        float gapOfGridYPositions = teleportGridPosition.y - playerGridPosition.y;
        float incline = gapOfGridYPositions / gapOfGridXPositions;

        // Set direction to decrease value
        if (Mathf.Abs(gapOfGridXPositions) > Mathf.Abs(gapOfGridYPositions))
        {
            // linear function
            x = teleportGridPosition.x - Mathf.Sign(gapOfGridXPositions);
            y = incline * x + teleportGridPosition.y - incline * teleportGridPosition.x;
        }
        else
        {
            // linear function
            y = teleportGridPosition.y - Mathf.Sign(gapOfGridYPositions);
            x = teleportGridPosition.x + (y - teleportGridPosition.y) / incline;
        }
        
        teleportGridPosition = new Vector3Int(Mathf.RoundToInt(x), Mathf.RoundToInt(y), 0);

        // if there is not able to move grid, then repeat this method
        if (CheckUnmoveablePosition(currentRoomMoveableGrid, teleportGridPosition))
        {
            GenerateIntoMoveableGrid(ref teleportGridPosition, playerGridPosition, currentRoomMoveableGrid);
        }
    }

    /// <summary>
    /// Flip X sprite image
    /// </summary>
    private void FlipTeleportIcon(float xPos)
    {
        SpriteRenderer teleportSpriteRenderer = GetComponentInChildren<SpriteRenderer>();

        if (xPos < 0)
        {
            teleportSpriteRenderer.flipX = true;
        }
        else
        {
            teleportSpriteRenderer.flipX = false;
        }
    }

    
}
