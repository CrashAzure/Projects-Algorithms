using System.Collections;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

[RequireComponent(typeof(HealthEvent))]
[DisallowMultipleComponent]
public class Health : MonoBehaviour
{
    #region Header References
    [Space(10)]
    [Header("References")]
    #endregion
    #region Tooltip
    [Tooltip("Populate with the HealthBar component on the HealthBar gameobject")]
    #endregion
    [SerializeField] private HealthBar healthBar;
    private int startingHealth;
    private int currentHealth;
    private HealthEvent healthEvent;
    private Player player;
    private Coroutine immunityCoroutine;
    private bool isImmuneAfterHit = false;
    private float immunityTime = 0f;
    private SpriteRenderer spriteRenderer = null;
    private const float spriteFlashInterval = 0.2f;
    private WaitForSeconds WaitForSecondsSpriteFlashInterval = new WaitForSeconds(spriteFlashInterval);

    [HideInInspector] public Coroutine beHitEffectCoroutine;
    [HideInInspector] public bool isPlayerDead = false;


    [HideInInspector] public bool isDamageable = true;
    [HideInInspector] public Enemy enemy;

    private void Awake()
    {
        //Load compnents
        healthEvent = GetComponent<HealthEvent>();
    }

    private void Start()
    {
        // Trigger a health event for UI update
        CallHealthEvent(0);

        // Attempt to load enemy / player components
        player = GetComponent<Player>();
        enemy = GetComponent<Enemy>();


        // Get player / enemy hit immunity details
        if (player != null)
        {
            if (player.playerDetails.isImmuneAfterHit)
            {
                isImmuneAfterHit = true;
                immunityTime = player.playerDetails.hitImmunityTime;
                spriteRenderer = player.spriteRenderer;
            }
        }
        else if (enemy != null)
        {
            if (enemy.enemyDetails.isImmuneAfterHit)
            {
                isImmuneAfterHit = true;
                immunityTime = enemy.enemyDetails.hitImmunityTime;
                spriteRenderer = enemy.spriteRendererArray[0];
            }
        }

        // Enable the health bar if required
        if (enemy != null && enemy.enemyDetails.isHealthBarDisplayed == true && healthBar != null)
        {
            healthBar.EnableHealthBar();
        }
        else if (healthBar != null)
        {
            healthBar.DisableHealthBar();
        }
    }

    /// <summary>
    /// Public method called when damage is taken
    /// </summary>
    public void TakeDamage(int damageAmount)
    {
        bool isRolling = false;

        if (player != null)
            isRolling = player.playerControl.isPlayerRolling;

        if (isDamageable && !isRolling)
        {
            currentHealth -= damageAmount;
            CallHealthEvent(damageAmount);

            if (player != null && !isPlayerDead)
            {
                beHitEffectCoroutine = StartCoroutine(BeHitEffectCoroutine(1f, true));
                StartCoroutine(PostProcessingCoroutine(Color.red, 0.7f, 0.5f));
            }

            if (enemy != null)
            {
                beHitEffectCoroutine = StartCoroutine(BeHitEffectCoroutine(1f, false));
            }

            PostHitImmunity();

            // Set health bar as the percentage of health remaining
            if (healthBar != null)
            {
                healthBar.SetHealthBarValue((float)currentHealth / (float)startingHealth);
            }
        }
    }

    /// <summary>
    /// Post processing coroutine for effect
    /// </summary>
    private IEnumerator PostProcessingCoroutine(Color color, float intensity, float maintenanceTime)
    {
        Vignette vignette = GameManager.Instance.GetVignette();

        if (!vignette.IsActive())
        {
            vignette.active = true;
            vignette.intensity = new ClampedFloatParameter(0f, 0f, 1f);
            vignette.color = new ColorParameter(Color.black);
        }

        vignette.color = new ColorParameter(color);
        vignette.intensity = new ClampedFloatParameter(intensity, 0f, 1f);

        yield return new WaitForSeconds(maintenanceTime);

        vignette.intensity = new ClampedFloatParameter(0f, 0f, 1f);
        vignette.color = new ColorParameter(Color.black);
        vignette.active = false;
    }

    private IEnumerator BeHitEffectCoroutine(float effectDelay, bool isPlayer)
    {
        SpriteRenderer sprite;
        SpriteRenderer[] otherSprites;

        if (isPlayer)
        {
            sprite = player.GetComponent<SpriteRenderer>();
            otherSprites = player.GetComponentsInChildren<SpriteRenderer>();
        }
        else
        {
            sprite = enemy.GetComponent<SpriteRenderer>();
            otherSprites = enemy.GetComponentsInChildren<SpriteRenderer>();
        }

        sprite.color = new Color(0.8f, 0.2f, 0.2f, 1f);

        if(otherSprites.Length > 0)
        {
            foreach (SpriteRenderer spriteRenderer in otherSprites)
            {
                if (spriteRenderer == null
                    || spriteRenderer.gameObject.layer != Settings.Layers.enemy
                    || spriteRenderer.gameObject.layer != Settings.Layers.enemyWeapon) continue;

                spriteRenderer.color = new Color(0.8f, 0.2f, 0.2f, 1f);
            }

            yield return new WaitForSeconds(effectDelay);

            sprite.color = new Color(1f, 1f, 1f, 1f);

            foreach (SpriteRenderer spriteRenderer in otherSprites)
            {
                if (spriteRenderer == null
                    || spriteRenderer.gameObject.layer != Settings.Layers.enemy
                    || spriteRenderer.gameObject.layer != Settings.Layers.enemyWeapon) continue;

                spriteRenderer.color = new Color(1f, 1f, 1f, 1f);
            }
        }
        
    }

    /// <summary>
    /// Indicate a hit and give some post hit immunity
    /// </summary>
    private void PostHitImmunity()
    {
        // Check if gameobject is active - if not return
        if (gameObject.activeSelf == false)
            return;

        // If there is post hit immunity then
        if (isImmuneAfterHit)
        {
            if (immunityCoroutine != null)
                StopCoroutine(immunityCoroutine);

            // flash red and give period of immunity
            immunityCoroutine = StartCoroutine(PostHitImmunityRoutine(immunityTime, spriteRenderer));
        }

    }

    /// <summary>
    /// Coroutine to indicate a hit and give some post hit immunity
    /// </summary>
    private IEnumerator PostHitImmunityRoutine(float immunityTime, SpriteRenderer spriteRenderer)
    {
        int iterations = Mathf.RoundToInt(immunityTime / spriteFlashInterval / 2f);

        isDamageable = false;

        while (iterations > 0)
        {
            spriteRenderer.color = Color.red;

            yield return WaitForSecondsSpriteFlashInterval;

            spriteRenderer.color = Color.white;

            yield return WaitForSecondsSpriteFlashInterval;

            iterations--;

            yield return null;

        }

        isDamageable = true;

    }

    private void CallHealthEvent(int damageAmount)
    {
        // Trigger health event
        healthEvent.CallHealthChangedEvent(((float)currentHealth / (float)startingHealth), currentHealth, damageAmount);
    }


    /// <summary>
    /// Set starting health 
    /// </summary>
    public void SetStartingHealth(int startingHealth)
    {
        this.startingHealth = startingHealth;
        currentHealth = startingHealth;
    }

    /// <summary>
    /// Get the starting health
    /// </summary>
    public int GetStartingHealth()
    {
        return startingHealth;
    }

    /// <summary>
    /// Increase health by specified percent
    /// </summary>
    public void AddHealth(int healthPercent)
    {
        int healthIncrease = Mathf.RoundToInt((startingHealth * healthPercent) / 100f);

        int totalHealth = currentHealth + healthIncrease;

        if (totalHealth > startingHealth)
        {
            currentHealth = startingHealth;
        }
        else
        {
            currentHealth = totalHealth;
        }

        CallHealthEvent(0);
    }

}