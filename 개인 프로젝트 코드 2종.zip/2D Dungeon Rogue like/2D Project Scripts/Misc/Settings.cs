using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design.Serialization;
using UnityEngine;

public static class Settings
{
    public struct CharacterName
    {
        public const string magician = "The Magician";
        public const string soldier = "The Soldier";
        public const string scientist = "The Scientist";
        public const string ninja = "The Ninja";
    }

    public struct Layers
    {
        public const int player = 10;
        public const int room = 12;
        public const int enemy = 15;
        public const int playerWeapon = 18;
        public const int enemyWeapon = 19;
        public const int playerTeleportIcon = 21;
    }

    #region Units
    public const float pixelsPerUnit = 16f;
    public const float tileSizePixels = 16f;
    #endregion Units

    #region Dungeon Build Settings
    public const int maxDungeonRebuildAttemptsForRoomGraph = 1000;
    public const int maxDungeonBuildAttempts = 10;
    #endregion Dungeon Build Settings

    #region ROOM SETTINGS
    public const float fadeInTime = 0.5f; // time to fadde in that room
    public const int maxChildCorridors = 3;
    public const float doorUnlockDelay = 1f;
    #endregion ROOM SETTINGS

    #region Animator Parameters
    // Animator parameters - Player
    public static int aimUp = Animator.StringToHash("aimUp");
    public static int aimDown = Animator.StringToHash("aimDown");
    public static int aimUpRight = Animator.StringToHash("aimUpRight");
    public static int aimUpLeft = Animator.StringToHash("aimUpLeft");
    public static int aimRight = Animator.StringToHash("aimRight");
    public static int aimLeft = Animator.StringToHash("aimLeft");
    public static int isIdle = Animator.StringToHash("isIdle");
    public static int isMoving = Animator.StringToHash("isMoving");
    public static int rollUp = Animator.StringToHash("rollUp");
    public static int rollRight = Animator.StringToHash("rollRight");
    public static int rollLeft = Animator.StringToHash("rollLeft");
    public static int rollDown = Animator.StringToHash("rollDown");
    public static int flipUp = Animator.StringToHash("flipUp");
    public static int flipRight = Animator.StringToHash("flipRight");
    public static int flipLeft = Animator.StringToHash("flipLeft");
    public static int flipDown = Animator.StringToHash("flipDown");
    public static int use = Animator.StringToHash("use");
    public static float baseSpeedForPlayerAnimations = 8f;

    // Animator parameters - Enemy
    public static float baseSpeedForEnemyAnimations = 3f;


    // Animator parameters - Door
    public static int open = Animator.StringToHash("open");

    // Animator parameters - DamageableDecoration
    public static int destroy = Animator.StringToHash("destroy");
    public static string stateDestroyed = "Destroyed";
    #endregion

    #region GameObject Tags
    public const string playerTag = "Player";
    public const string playerWeapon = "playerWeapon";
    #endregion GameObject Tags

    #region AUDIO
    public const float musicFadeOutTime = 0.5f;  // Defualt Music Fade Out Transition
    public const float musicFadeInTime = 0.5f;  // Default Music Fade In Transition
    #endregion

    #region Firing Control
    /// <summary>
    /// if the target distance is less than this then aim angle will be used, else weapon aim angle will be used 
    /// </summary>
    public const float useAimAngleDistance = 3.5f;
    #endregion

    #region ASTAR PATHFINDING PARAMETERS
    public const int defaultAStarMovementPenalty = 40;
    public const int preferredPathAStarMovementPenalty = 1;
    public const int targetFrameRateToSpreadPathfindingOver = 60;
    public const float playerMoveDistanceToRebuildPath = 3f;
    public const float enemyPathRebuildCooldown = 2f;
    #endregion

    #region ENEMY PARAMETERS
    public const int defaultEnemyHealth = 20;
    #endregion

    #region UI PARAMETERS
    public const float uiHeartSpacing = 16f;
    public const float uiAmmoIconSpacing = 4f;
    #endregion

    #region CONTACT DAMAGE PARAMETERS
    public const float contactDamageCollisionResetDelay = 0.5f;
    #endregion

    #region HIGHSCORES
    public const int numberOfHighScoresToSave = 100;
    #endregion
}

