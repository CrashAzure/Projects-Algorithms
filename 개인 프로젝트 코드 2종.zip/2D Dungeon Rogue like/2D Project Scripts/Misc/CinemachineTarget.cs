using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

[RequireComponent(typeof(CinemachineTargetGroup))]
public class CinemachineTarget : MonoBehaviour
{
    private CinemachineTargetGroup cinemachineTargetGroup;
    private GameObject cursorObjectOnWolrdPosition;

    private void Awake()
    {
        // Load Component
        cinemachineTargetGroup = GetComponent<CinemachineTargetGroup>();
        cursorObjectOnWolrdPosition = new GameObject("CursorPositionOnWorld");
    }

    private void Start()
    {
        SetCinemachineTargetGroup();
    }
    private void Update()
    {
        cursorObjectOnWolrdPosition.transform.position = HelperUtilities.GetMouseWorldPosition();
    }

    /// <summary>
    /// Set Cinemachine Camera Target Group
    /// </summary>
    private void SetCinemachineTargetGroup()
    {
        // Create plaeyr target for camera follow
        CinemachineTargetGroup.Target cinemachineGroupTarget_player
                                            = new CinemachineTargetGroup.Target { weight = 2f, radius = 2.5f, target = GameManager.Instance.GetPlayer().transform };
        // Create cursor target for camera follow
        CinemachineTargetGroup.Target cinemachineGroupTarget_cursor
                                            = new CinemachineTargetGroup.Target { weight = 1f, radius = 1f, target = cursorObjectOnWolrdPosition.transform };

        // Create Target Array
        CinemachineTargetGroup.Target[] cinemachineTargetArray = new CinemachineTargetGroup.Target[] { cinemachineGroupTarget_player, cinemachineGroupTarget_cursor };
        //CinemachineTargetGroup.Target[] cinemachineTargetArray = new CinemachineTargetGroup.Target[] { cinemachineGroupTarget_player };

        // Set Target Group Array
        cinemachineTargetGroup.m_Targets = cinemachineTargetArray;

        //cinemachineTargetGroup.AddMember(cinemachineGroupTarget_player.target, cinemachineGroupTarget_player.weight, cinemachineGroupTarget_player.radius);
    }
}
