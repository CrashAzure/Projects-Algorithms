using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(ReloadWeaponEvent))]
[RequireComponent(typeof(WeaponReloadedEvent))]
[RequireComponent(typeof(SetActiveWeaponEvent))]
[DisallowMultipleComponent]
public class ReloadWeapon : MonoBehaviour
{
    private ReloadWeaponEvent reloadWeaponEvent;
    private SetActiveWeaponEvent setActiveWeaponEvent;
    private Coroutine reloadWeaponCoroutine;

    [HideInInspector]
    public WeaponReloadedEvent weaponReloadedEvent;

    private void Awake()
    {
        // Get Components
        reloadWeaponEvent = GetComponent<ReloadWeaponEvent>();
        weaponReloadedEvent = GetComponent<WeaponReloadedEvent>();
        setActiveWeaponEvent = GetComponent<SetActiveWeaponEvent>();
    }

    private void OnEnable()
    {
        // Subscribe each event
        reloadWeaponEvent.OnReloadWeapon += ReloadWeapon_OnReloadWeapon;
        setActiveWeaponEvent.OnSetActiveWeapon += SetActiveWeapon_OnSetActiveWeapon;
    }

    private void OnDisable()
    {
        // Unsubscribe each event
        reloadWeaponEvent.OnReloadWeapon -= ReloadWeapon_OnReloadWeapon;
        setActiveWeaponEvent.OnSetActiveWeapon -= SetActiveWeapon_OnSetActiveWeapon;
    }

    /// <summary>
    /// Handle ReloadWeaponEvent
    /// </summary>
    private void ReloadWeapon_OnReloadWeapon(ReloadWeaponEvent reloadWeaponEvent, ReloadWeaponEventArgs reloadWeaponEventArgs)
    {
        StartReloadWeapon(reloadWeaponEventArgs);
    }

    /// <summary>
    /// Start to reload weapon
    /// </summary>
    private void StartReloadWeapon(ReloadWeaponEventArgs reloadWeaponEventArgs)
    {
        // if reloadWeaponCoroutine is not null, it means there is already coroutine that is doing
        StopReloadWeaponCoroutine();

        if(reloadWeaponEventArgs.weapon.weaponDetails.weaponName == "Shotgun")
        {
            reloadWeaponCoroutine = StartCoroutine(ReloadOneByOneWeaponRoutine(reloadWeaponEventArgs.weapon, reloadWeaponEventArgs.topUpAmmoPercent));
        }
        else
        {
            reloadWeaponCoroutine = StartCoroutine(ReloadWeaponRoutine(reloadWeaponEventArgs.weapon, reloadWeaponEventArgs.topUpAmmoPercent));
        }
    }

    public void StopReloadWeaponCoroutine()
    {
        if (reloadWeaponCoroutine != null)
        {
            StopCoroutine(reloadWeaponCoroutine);
        }
    }

    /// <summary>
    /// Reload weapon coroutine
    /// </summary>
    private IEnumerator ReloadWeaponRoutine(Weapon weapon, int topUpAmmoPercent)
    {
        // Play reload sound if its not null
        //if(weapon.weaponDetails.weaponReloadingSoundEffect != null)
        if (weapon.weaponDetails.weaponReloadingEffectList.Count == 0)
        {
            SoundEffectManager.Instance.PlaySoundEffect(weapon.weaponDetails.weaponReloadingSoundEffect);
        }
        else
        {
            SetReloadTime(weapon);

            SoundEffectManager.Instance.PlaySoundEffect(weapon.weaponDetails.weaponReloadingEffectList);
        }

        // Set weapon as reloading
        weapon.isWeaponReloading = true;

        // Update reload progress timer
        while(weapon.weaponReloadTimer < weapon.weaponDetails.weaponReloadTime)
        {
            weapon.weaponReloadTimer += Time.deltaTime;
            yield return null;
        }

        // if total ammo is to be increased then update
        UpdateTotalAmmoIncreased(weapon, topUpAmmoPercent);

        // if weapon has infinite ammo then just refil clip
        if (weapon.weaponDetails.hasInfiniteAmmo)
        {
            weapon.weaponClipRemainingAmmo= weapon.weaponDetails.weaponClipAmmoCapacity;
        }
        // if weaponRemaingAmmo is enough to fully refil clip
        // then refil fully clip
        else if(weapon.weaponRemainingAmmo >= weapon.weaponDetails.weaponClipAmmoCapacity)
        {
            weapon.weaponClipRemainingAmmo = weapon.weaponDetails.weaponClipAmmoCapacity;
        }
        // if its not enough to fully refil clip
        // then just refil the clip with remaining ammo
        else
        {
            weapon.weaponClipRemainingAmmo = weapon.weaponRemainingAmmo;
        }

        resetReloadingParameters(weapon);
        weaponReloadedEvent.CallWeaponReloaded(weapon);
    }

    private IEnumerator ReloadOneByOneWeaponRoutine(Weapon weapon, int topUpAmmoPercent)
    {
        // Play reload sound if its not null
        //if(weapon.weaponDetails.weaponReloadingSoundEffect != null)

        SetReloadTime(weapon);

        // Set weapon as reloading
        weapon.isWeaponReloading = true;

        // if total ammo is to be increased then update
        UpdateTotalAmmoIncreased(weapon, topUpAmmoPercent);

        while (weapon.weaponClipRemainingAmmo < weapon.weaponDetails.weaponClipAmmoCapacity
            && weapon.weaponClipRemainingAmmo != weapon.weaponRemainingAmmo)
        {
            // Reload a shell sound
            SoundEffectManager.Instance.PlaySoundEffect(weapon.weaponDetails.weaponReloadingEffectList[0]);

            weapon.weaponClipRemainingAmmo++;


            weaponReloadedEvent.CallWeaponReloaded(weapon);
            yield return new WaitForSeconds(weapon.weaponDetails.weaponReloadingEffectList[0].soundEffectClip.length);
        }

        // Release sound
        SoundEffectManager.Instance.PlaySoundEffect(weapon.weaponDetails.weaponReloadingEffectList[1]);

        resetReloadingParameters(weapon);
        weaponReloadedEvent.CallWeaponReloaded(weapon);


    }

    /// <summary>
    /// Update totla ammo if its to be increased
    /// </summary>
    private void UpdateTotalAmmoIncreased(Weapon weapon, int topUpAmmoPercent)
    {
        // if total ammo is to be increased then update
        if (topUpAmmoPercent != 0)
        {
            // topUpAmmoPercent / 100f = realTopUpAmmoPercent
            int ammoIncrease = Mathf.RoundToInt((weapon.weaponDetails.weaponAmmoCapacity * topUpAmmoPercent) / 100f);

            int totalAmmo = weapon.weaponRemainingAmmo * ammoIncrease;

            if (totalAmmo > weapon.weaponDetails.weaponAmmoCapacity)
            {
                weapon.weaponRemainingAmmo = weapon.weaponDetails.weaponAmmoCapacity;
            }
            else
            {
                weapon.weaponRemainingAmmo = totalAmmo;
            }
        }
    }

    /// <summary>
    /// Handle SetActiveWeaponEvent
    /// </summary>
    private void SetActiveWeapon_OnSetActiveWeapon(SetActiveWeaponEvent setActiveWeaponEvent, SetActiveWeaponEventArgs setActiveWeaponEventArgs)
    {
        if (setActiveWeaponEventArgs.weapon.isWeaponReloading)
        {
            if(reloadWeaponCoroutine != null)
            {
                StopCoroutine(reloadWeaponCoroutine);
            }

            reloadWeaponCoroutine = StartCoroutine(ReloadWeaponRoutine(setActiveWeaponEventArgs.weapon, 0));
        }
    }

    private void SetReloadTime(Weapon weapon)
    {
        float weaponReloadTime = 0f;

        if(weapon.weaponDetails.weaponName == "Shotgun")
        {
            float oneReloadingTime = weapon.weaponDetails.weaponReloadingEffectList[0].soundEffectClip.length;

            weaponReloadTime = oneReloadingTime * (weapon.weaponDetails.weaponClipAmmoCapacity - weapon.weaponClipRemainingAmmo - 1);
        }

        foreach (SoundEffectSO reloadingSound in weapon.weaponDetails.weaponReloadingEffectList)
        {
            weaponReloadTime += reloadingSound.soundEffectClip.length;
        }

        weapon.weaponDetails.weaponReloadTime = weaponReloadTime;
    }

    public void resetReloadingParameters(Weapon weapon)
    {
        // Reset Timer
        weapon.weaponReloadTimer = 0f;
        // Set weapon as not reloading
        weapon.isWeaponReloading = false;
    }
}
