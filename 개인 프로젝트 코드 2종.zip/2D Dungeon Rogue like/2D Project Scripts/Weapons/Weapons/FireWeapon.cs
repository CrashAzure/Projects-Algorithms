
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

[RequireComponent(typeof(ActiveWeapon))]
[RequireComponent(typeof(FireWeaponEvent))]
[RequireComponent(typeof(ReloadWeaponEvent))]
[RequireComponent(typeof(WeaponFiredEvent))]
[DisallowMultipleComponent]
public class FireWeapon : MonoBehaviour
{
    private float firePrechargeTimer = 0f;
    private float fireRateCoolDownTimer = 0f;
    private ActiveWeapon activeWeapon;
    private FireWeaponEvent fireWeaponEvent;
    private WeaponFiredEvent weaponFiredEvent;
    private ReloadWeaponEvent reloadWeaponEvent;

    private void Awake()
    {
        // Get Components
        activeWeapon = GetComponent<ActiveWeapon>();
        fireWeaponEvent = GetComponent<FireWeaponEvent>();
        weaponFiredEvent = GetComponent<WeaponFiredEvent>();
        reloadWeaponEvent = GetComponent<ReloadWeaponEvent>();
    }

    private void OnEnable()
    {
        // Subscribe
        fireWeaponEvent.OnFireWeapon += FireWeapon_OnFireWeapon;
        //weaponFiredEvent.OnWeaponFired += WeaponFired_OnWeaponFired;
    }

    private void OnDisable()
    {
        // Unsubscribe
        fireWeaponEvent.OnFireWeapon -= FireWeapon_OnFireWeapon;
        //weaponFiredEvent.OnWeaponFired -= WeaponFired_OnWeaponFired;
    }

    private void Update()
    {
        // Decrease cooldown timer
        fireRateCoolDownTimer -= Time.deltaTime;
    }

    /// <summary>
    /// Handle fire weapon Event
    /// </summary>
    private void FireWeapon_OnFireWeapon(FireWeaponEvent fireWeaponEvent, FireWeaponEventArgs fireWeaponEventArgs)
    {
        WeaponFire(fireWeaponEventArgs);
    }

    /// <summary>
    /// Fire Weapon
    /// </summary>
    private void WeaponFire(FireWeaponEventArgs fireWeaponEventArgs)
    {
        // Handle weapon precharge timer
        WeaponPrecharge(fireWeaponEventArgs);

        if (!fireWeaponEventArgs.fire) return;

        // Test if weapon is ready to fire
        if (IsWeaponReadyToFire())
        {
            FireAmmo(fireWeaponEventArgs.aimAngle, fireWeaponEventArgs.weaponAimAngle, fireWeaponEventArgs.weaponAimDirectionVector);

            ResetCoolDownTimer();
            ResetPrechargeTimer();
        }
    }

    /// <summary>
    /// Handle Weapon Precharge
    /// </summary>
    private void WeaponPrecharge(FireWeaponEventArgs fireWeaponEventArgs)
    {
        // if fire button clicked previous frame
        if (fireWeaponEventArgs.firePreviousFrame)
        {
            // then decrease precharge timer
            firePrechargeTimer -= Time.deltaTime;
        }
        else
        {
            // else reset precharge timer
            ResetPrechargeTimer();
        }
    }

    /// <summary>
    /// Return true if the weapon is ready to fire
    /// </summary>
    private bool IsWeaponReadyToFire()
    {
        // Return false, if no remaining ammo and no infinity ammo
        if (activeWeapon.GetCurrentWeapon().weaponRemainingAmmo <= 0 && !activeWeapon.GetCurrentWeapon().weaponDetails.hasInfiniteAmmo)
            return false;

        // Return false while reloading
        if (activeWeapon.GetCurrentWeapon().isWeaponReloading)
            return false;

        // Return false weapon is cooling down or isnt precharged
        if (fireRateCoolDownTimer > 0f || firePrechargeTimer > 0f)
            return false;

        // Return false, if no remaing clip and no infinity clips
        if (!activeWeapon.GetCurrentWeapon().weaponDetails.hasInfiniteClipCapacity && activeWeapon.GetCurrentWeapon().weaponClipRemainingAmmo <= 0)
        {
            // Call Reload Weapon Event

            reloadWeaponEvent.CallReloadWeapon(activeWeapon.GetCurrentWeapon(), 0);
            return false;
        }


        // Ready to fire
        return true;
    }

    /// <summary>
    /// Set up ammo using an ammo gameobject and component from object pool
    /// </summary>
    private void FireAmmo(float aimAngle, float weaponAimAngle, Vector3 weaponAimDirectionVector)
    {
        AmmoDetailsSO currentAmmo = activeWeapon.GetCurrentAmmo();

        if(currentAmmo != null)
        {
            // Fire ammo coroutine
            StartCoroutine(FireAmmoRoutine(currentAmmo, aimAngle, weaponAimAngle, weaponAimDirectionVector));
        }
    }

    /// <summary>
    /// Coroutine for spawning multiple ammos per a shot
    /// </summary>
    private IEnumerator FireAmmoRoutine(AmmoDetailsSO currentAmmo, float aimAngle, float weaponAimAngle, Vector3 weaponAimDirectionVector)
    {
        int ammoCounter = 0;

        // Get random ammo per a shot
        int ammoPerShot = Random.Range(currentAmmo.ammoSpawnAmountMin, currentAmmo.ammoSpawnAmountMax);

        // Get random interval between ammo
        float ammoSpawnInterval;
        if(ammoPerShot > 0)
        {
            ammoSpawnInterval = Random.Range(currentAmmo.ammoSpawnIntervalMin, currentAmmo.ammoSpawnIntervalMax);
        }
        else
        {
            ammoSpawnInterval = 0;
        }

        while(ammoCounter < ammoPerShot)
        {
            ammoCounter++;

            // Get ammo random prefab from array
            GameObject ammoPrefab = currentAmmo.ammoPrefabArray[Random.Range(0, currentAmmo.ammoPrefabArray.Length)];

            // Get random speed value
            float ammoSpeed = Random.Range(currentAmmo.ammoSpeedMin, currentAmmo.ammoSpeedMax);

            // Get gameobject with IFireable component
            IFireable ammo = (IFireable)PoolManager.Instance.ReuseComponent(ammoPrefab, activeWeapon.GetShootPosition(), Quaternion.identity);

            // Initialise ammo
            ammo.InitialiseAmmo(currentAmmo, aimAngle, weaponAimAngle, ammoSpeed, weaponAimDirectionVector);

            // Wait for ammo per shot timegap
            yield return new WaitForSeconds(ammoSpawnInterval);
        }
        
        // Reduce ammo clip count and ammo count if not infinite clip capacity
        if (!activeWeapon.GetCurrentWeapon().weaponDetails.hasInfiniteClipCapacity)
        {
            activeWeapon.GetCurrentWeapon().weaponClipRemainingAmmo--;
            activeWeapon.GetCurrentWeapon().weaponRemainingAmmo--;
        }

        // Call WeaponFiredEvent
        weaponFiredEvent.CallOnWeaponFired(activeWeapon.GetCurrentWeapon());

        // Display weapon shoot effect
        WeaponShootEffect(aimAngle);

        // Weapon fired sound effect
        WeaponSoundEffect();
    }


    /// <summary>
    /// Reset cooldown timer
    /// </summary>
    private void ResetCoolDownTimer()
    {
        fireRateCoolDownTimer = activeWeapon.GetCurrentWeapon().weaponDetails.weaponFireRate;
    }

    /// <summary>
    /// Reset Precharge Timer
    /// </summary>
    private void ResetPrechargeTimer()
    {
        /// Reset Precharge Timer
        firePrechargeTimer = activeWeapon.GetCurrentWeapon().weaponDetails.weaponPrechargeTime;
    }

    /// <summary>
    /// Weapon fired sound effect
    /// </summary>
    private void WeaponSoundEffect()
    {
        if(activeWeapon.GetCurrentWeapon().weaponDetails.weaponFiringSoundEffect != null)
        {
            SoundEffectManager.Instance.PlaySoundEffect(activeWeapon.GetCurrentWeapon().weaponDetails.weaponFiringSoundEffect);
        }
    }

    /// <summary>
    /// Display weapon shoot effect
    /// </summary>
    private void WeaponShootEffect(float aimAngle)
    {
        // is there weapon shoot effect and its prefab?
        if (activeWeapon.GetCurrentWeapon().weaponDetails.weaponShootEffect != null
            && activeWeapon.GetCurrentWeapon().weaponDetails.weaponShootEffect.weaponShootEffectPrefab != null)
        {
            // Get weapon shoot effect from object pool
            Weapon currentWeapon = activeWeapon.GetCurrentWeapon();
            WeaponShootEffect weaponShootEffect = (WeaponShootEffect)PoolManager.Instance.ReuseComponent(
                currentWeapon.weaponDetails.weaponShootEffect.weaponShootEffectPrefab,
                activeWeapon.GetShootEffectPosition(),
                Quaternion.identity
                );

            // Set shoot effect
            weaponShootEffect.SetShootEffect(currentWeapon.weaponDetails.weaponShootEffect, aimAngle);

            // Set game object active true (bcs its from object pool)
            weaponShootEffect.gameObject.SetActive(true);
        }
    }
}


