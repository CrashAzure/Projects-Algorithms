using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public class SwingableWeaponAnimation : MonoBehaviour
{
    [SerializeField] private Player player;
    private void Update()
    {
        // if this weapon is not able to swing
        if (!player.activeWeapon.GetCurrentWeapon().weaponDetails.isSwing) 
        {
            // initialize rotation
            transform.localRotation = Quaternion.identity;
            return; 
        }

        if (Input.GetMouseButton(0))
        {
            // Rotate -90 degrees z axis
            transform.localEulerAngles = new Vector3(0f, 0f, -90f);
        }
        else if (Input.GetMouseButtonUp(0))
        {
            // initialize rotation
            transform.localRotation = Quaternion.identity;
        }

    }
}
