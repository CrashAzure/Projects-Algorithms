using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

public class WeaponAnimation : MonoBehaviour
{
    private Player player;
    private Enemy enemy;
    private FireWeaponEvent fireWeaponEvent;
    private Weapon prevWeapon;

    private bool hasCoroutine = false;
    private bool isSwing = false;


    private void Awake()
    {
        player = GetComponentInParent<Player>();
        enemy = GetComponentInParent<Enemy>();
        fireWeaponEvent = GetComponentInParent<FireWeaponEvent>();

        if(player != null)
        {
            prevWeapon = player.activeWeapon.GetCurrentWeapon();
        }
    }

    private void OnEnable()
    {
        // Subscribe
        fireWeaponEvent.OnFireWeapon += FireWeapon_OnFireWeapon;
    }

    private void OnDisable()
    {
        // Unsubscribe
        fireWeaponEvent.OnFireWeapon -= FireWeapon_OnFireWeapon;
    }

    private void Update()
    {
        // for player
        if (player == null) return;

        isSwing = player.activeWeapon.GetCurrentWeapon().weaponDetails.isSwing;

        SwingPlayerWeapon(isSwing);
    }


    /// <summary>
    /// for enemy
    /// </summary>
    private void FireWeapon_OnFireWeapon(FireWeaponEvent fireWeaponEvent, FireWeaponEventArgs fireWeaponEventArgs)
    {
        
        if (fireWeaponEventArgs.fire && enemy != null && !hasCoroutine)
        {
            isSwing = enemy.enemyDetails.enemyWeapon.isSwing;

            StartCoroutine(EnemyAttackCoroutine(1.0f));
        }
    }

    /// <summary>
    /// Swing player weapon
    /// </summary>
    private void SwingPlayerWeapon(bool isSwing)
    {
        if (!isSwing) return;

        // hold down left click
        if (Input.GetMouseButton(0))
        {
            // Rotate -90 degrees z axis
            transform.localEulerAngles = new Vector3(0f, 0f, -90f);
        }

        // left mouse button up
        if (Input.GetMouseButtonUp(0))
        {
            // initialize rotation
            transform.localRotation = Quaternion.identity;
        }

        // if player changed weapon
        if (prevWeapon != player.activeWeapon.GetCurrentWeapon())
        {
            prevWeapon = player.activeWeapon.GetCurrentWeapon();
            // initialize rotation
            transform.localRotation = Quaternion.identity;
        }
    }

    private IEnumerator EnemyAttackCoroutine(float delayTime)
    {
        hasCoroutine = true;

        // Rotate -90 degrees z axis
        transform.localEulerAngles = new Vector3(0f, 0f, -90f);

        yield return new WaitForSeconds(delayTime);

        // initialize rotation
        transform.localRotation = Quaternion.identity;

        hasCoroutine = false;
    }
}
