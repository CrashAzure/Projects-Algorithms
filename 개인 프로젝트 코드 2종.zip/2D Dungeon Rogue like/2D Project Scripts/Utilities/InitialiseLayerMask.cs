using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Settings;


public class InitialiseLayerMask : MonoBehaviour
{
    private int uiLayer, ignoreAmmoLayer, camera1Layer
                , camera2Layer, playerLayer, miniMapLayer
                , roomLayer, wallLayer, playerAmmoLayer
                , enemyLayer, enemyAmmoLayer, environmentLayer
                , playerWeaponLayer, enemyWeaponLayer, camera3Layer
                , playerTeleportIconLayer;

    private void Awake()
    {
        SetLayers();

        InitialiseLayerCollisionMask();
    }

    /// <summary>
    /// Set Layers using layers' name
    /// </summary>
    private void SetLayers()
    {
        uiLayer = LayerMask.NameToLayer("UI");
        ignoreAmmoLayer = LayerMask.NameToLayer("IgnoreAmmo");
        camera1Layer = LayerMask.NameToLayer("Camera 1");
        camera2Layer = LayerMask.NameToLayer("Camera 2");
        playerLayer = LayerMask.NameToLayer("Player");
        miniMapLayer = LayerMask.NameToLayer("MiniMap");
        roomLayer = LayerMask.NameToLayer("Room");
        wallLayer = LayerMask.NameToLayer("Wall");
        playerAmmoLayer = LayerMask.NameToLayer("PlayerAmmo");
        enemyLayer = LayerMask.NameToLayer("Enemy");
        enemyAmmoLayer = LayerMask.NameToLayer("EnemyAmmo");
        environmentLayer = LayerMask.NameToLayer("Environment");
        playerWeaponLayer = LayerMask.NameToLayer("PlayerWeapon");
        enemyWeaponLayer = LayerMask.NameToLayer("EnemyWeapon");
        camera3Layer = LayerMask.NameToLayer("Camera 3");
        playerTeleportIconLayer = LayerMask.NameToLayer("PlayerTeleportIcon");
    }

    /// <summary>
    /// Initialise layers collision mask
    /// </summary>
    private void InitialiseLayerCollisionMask()
    {
        Physics2D.SetLayerCollisionMask(uiLayer, 1 << uiLayer);
        Physics2D.SetLayerCollisionMask(ignoreAmmoLayer, 1 << playerLayer);

        Physics2D.SetLayerCollisionMask(playerLayer, (1 << environmentLayer)
                                                    + (1 << enemyAmmoLayer)
                                                    + (1 << enemyLayer)
                                                    + (1 << wallLayer)
                                                    + (1 << roomLayer));

        Physics2D.SetLayerCollisionMask(roomLayer, (1 << playerTeleportIconLayer)
                                                    + (1 << enemyLayer));

        Physics2D.SetLayerCollisionMask(wallLayer, (1 << playerTeleportIconLayer)
                                                    + (1 << playerWeaponLayer)
                                                    + (1 << enemyLayer)
                                                    + (1 << playerAmmoLayer));

        Physics2D.SetLayerCollisionMask(playerAmmoLayer, (1 << playerTeleportIconLayer)
                                                    + (1 << environmentLayer)
                                                    + (1 << enemyLayer));

        Physics2D.SetLayerCollisionMask(enemyLayer, (1 << playerTeleportIconLayer)
                                                    + (1 << enemyLayer));

        Physics2D.SetLayerCollisionMask(enemyAmmoLayer, 1 << playerTeleportIconLayer);

        Physics2D.SetLayerCollisionMask(environmentLayer, 1 << playerTeleportIconLayer);

        Physics2D.SetLayerCollisionMask(enemyWeaponLayer, 1 << playerTeleportIconLayer);

        Physics2D.SetLayerCollisionMask(playerTeleportIconLayer, 1 << playerTeleportIconLayer);
    }
}