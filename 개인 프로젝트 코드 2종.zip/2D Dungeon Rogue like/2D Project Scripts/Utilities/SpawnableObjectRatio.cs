[System.Serializable]
public class SpawnableObjectRatio<T>
{
    public T dungeonObject;
    public int ratio;
}