using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Callbacks;
using UnityEngine;

public class RoomNodeGraphEditor : EditorWindow
{
    private GUIStyle roomNodeStyle;
    private GUIStyle roomNodeSelectedStyle;
    private static RoomNodeGraphSO currentRoomNodeGraph;

    private Vector2 graphOffset;
    private Vector2 graphDrag; // it will be delta value

    private RoomNodeSO currentRoomNode = null;
    private RoomNodeTypeListSO roomNodeTypeList;

    // Node layout values
    private float nodeWidth = 160f;

    private float nodeHeight = 75f;
    private float nodePadding = 25f;
    private float nodeBorder = 12f;
    private static float nodeFontSize = 5f;

    // Connecting line values
    private float connectingLineArrowSize = 5f;

    private float connectingLineWidth = 3f;

    // Grid Spacing
    private static float gridLarge = 100f;

    private static float gridSmall = 25f;
    private const float maxGridSize = 1000f;
    private const float minGridSize = 50f;

    [MenuItem("Room Node Graph Editor", menuItem = "Window/Dungeon Editor/Room Node Graph Editor")]
    private static void OpenWindow()
    {
        GetWindow<RoomNodeGraphEditor>("Room Node Graph Editor");
    }

    private void OnEnable()
    {
        // Subscribe to the inspector selection changed event
        // when dectected in inspector's selected or active, call this Selection.selectionChanged
        // selectionChanged has delegate parameter so we have to remove () like method grammar
        // bcs it will get the parameter to be method
        Selection.selectionChanged += InspectorSelectionChanged;

        // Define Default Node layout style
        roomNodeStyle = new GUIStyle();
        roomNodeStyle.normal.textColor = Color.white;
        roomNodeStyle.normal.background = EditorGUIUtility.Load("node1") as Texture2D;
        roomNodeStyle.padding = new RectOffset((int)nodePadding, (int)nodePadding, (int)nodePadding, (int)nodePadding);
        roomNodeStyle.border = new RectOffset((int)nodeBorder, (int)nodeBorder, (int)nodeBorder, (int)nodeBorder);
        roomNodeStyle.fontSize = (int)nodeFontSize;

        roomNodeSelectedStyle = new GUIStyle();
        roomNodeSelectedStyle.normal.textColor = Color.white;
        roomNodeSelectedStyle.normal.background = EditorGUIUtility.Load("node1 on") as Texture2D;
        roomNodeSelectedStyle.padding = new RectOffset((int)nodePadding, (int)nodePadding, (int)nodePadding, (int)nodePadding);
        roomNodeSelectedStyle.border = new RectOffset((int)nodeBorder, (int)nodeBorder, (int)nodeBorder, (int)nodeBorder);
        roomNodeSelectedStyle.fontSize = (int)nodeFontSize;

        // load Room node types
        roomNodeTypeList = GameResources.Instance.roomNodeTypeList;
    }

    // When this object cant be used or disable, this method will be called
    private void OnDisable()
    {
        // Unsubscribe to the inspector selection changed event
        Selection.selectionChanged -= InspectorSelectionChanged;

        //if (currentRoomNodeGraph != null)
        //{
        //    PlayerPrefs.SetFloat(currentRoomNodeGraph.name + "_gridSmall", gridSmall);
        //    PlayerPrefs.SetFloat(currentRoomNodeGraph.name + "_gridLarge", gridLarge);
        //    PlayerPrefs.SetFloat(currentRoomNodeGraph.name + "_nodeFontSize", nodeFontSize);
        //}

        PlayerPrefs.DeleteAll();
    }

    /// <summary>
    /// Open the room node graph editor window if a room node graph scriptable object asset is double clicked in the inspector
    /// </summary>
    [OnOpenAsset(0)]
    public static bool OnDoubleClickAsset(int instanceID, int line)
    {
        RoomNodeGraphSO roomNodeGraph = EditorUtility.InstanceIDToObject(instanceID) as RoomNodeGraphSO;

        if (roomNodeGraph != null)
        {
            OpenWindow();
            currentRoomNodeGraph = roomNodeGraph;

            if (PlayerPrefs.GetFloat(currentRoomNodeGraph.name + "_gridLarge") != 0f)
            {
                gridLarge = PlayerPrefs.GetFloat(currentRoomNodeGraph.name + "_gridLarge");
                gridSmall = PlayerPrefs.GetFloat(currentRoomNodeGraph.name + "_gridSmall");
                nodeFontSize = PlayerPrefs.GetFloat(currentRoomNodeGraph.name + "_nodeFontSize");
            }

            return true;
        }
        return false;
    }

    /// <summary>
    /// Draw Editor GUI
    /// </summary>
    private void OnGUI()
    {
        if (currentRoomNodeGraph != null)
        {
            // Draw Grid
            DrawBackgroundGrid(gridSmall, 0.2f, Color.gray);
            DrawBackgroundGrid(gridLarge, 0.2f, Color.gray);

            // Draw line if being dragged
            DrawDraggedLine();

            // Process Event
            ProcessEvents(Event.current);

            // Draw Connections between Room Nodes
            DrawRoomConnections();

            // Draw Room Nodes
            DrawRoomNodes();
        }

        if (GUI.changed)
        {
            Repaint();
        }
    }

    /// <summary>
    /// Draw a background grid for the room node graph editor
    /// </summary>
    private void DrawBackgroundGrid(float gridSize, float gridOpacity, Color gridColor)
    {
        // CeilToInt return smallest Integer from value
        int verticalLineCount = Mathf.CeilToInt((position.width * gridSize) / gridSize);
        int horizontalLineCount = Mathf.CeilToInt((position.height * gridSize) / gridSize);

        Handles.color = new Color(gridColor.r, gridColor.g, gridColor.b, gridOpacity);

        graphOffset += graphDrag * 0.5f;

        // We will use the Handles.DrawLine method
        // this method gets the parameters being Vector3
        // so we have to change the type of value to Vector3
        Vector3 gridOffset = new Vector3(graphOffset.x % gridSize, graphOffset.y % gridSize, 0f);

        for (int i = 0; i < verticalLineCount; i++)
        {
            Handles.DrawLine(new Vector3(gridSize * i, -gridSize, 0f) + gridOffset
                , new Vector3(gridSize * i, position.height + gridSize, 0f) + gridOffset, 0f);
        }

        for (int i = 0; i < horizontalLineCount; i++)
        {
            Handles.DrawLine(new Vector3(-gridSize, gridSize * i, 0f) + gridOffset
                , new Vector3(position.width + gridSize, gridSize * i, 0f) + gridOffset);
        }

        // init Handles.color to white
        Handles.color = Color.white;
    }

    private void DrawDraggedLine()
    {
        if (currentRoomNodeGraph.linePosition != Vector2.zero)
        {
            // Draw Line from node to line position
            Handles.DrawBezier(currentRoomNodeGraph.roomNodeToDrawLineFrom.rect.center, currentRoomNodeGraph.linePosition,
                currentRoomNodeGraph.roomNodeToDrawLineFrom.rect.center, currentRoomNodeGraph.linePosition, Color.white, null, connectingLineWidth);
        }
    }

    private void ProcessEvents(Event currentEvent)
    {
        // Reset Graph Drag
        graphDrag = Vector2.zero;

        if (currentRoomNode == null || currentRoomNode.isLeftClickDragging == false)
        {
            currentRoomNode = IsMouseOverRoomNode(currentEvent);
        }

        if (currentRoomNode == null || currentRoomNodeGraph.roomNodeToDrawLineFrom != null)
        {
            ProcessRoomNodeGraphEvents(currentEvent);
        }
        else
        {
            currentRoomNode.ProcessEvents(currentEvent);
        }
    }

    /// <summary>
    /// Check which a room node is mouse over
    /// while checking in roomNodeList, if one of nodes is over mouse position return that Node
    /// no node is over mouse, return null
    /// </summary>
    private RoomNodeSO IsMouseOverRoomNode(Event currentEvent)
    {
        for (int i = currentRoomNodeGraph.roomNodeList.Count - 1; i >= 0; i--)
        {
            if (currentRoomNodeGraph.roomNodeList[i].rect.Contains(currentEvent.mousePosition))
            {
                return currentRoomNodeGraph.roomNodeList[i];
            }
        }

        return null;
    }

    /// <summary>
    /// Process Room Node Graph Events
    /// </summary>
    private void ProcessRoomNodeGraphEvents(Event currentEvent)
    {
        switch (currentEvent.type)
        {
            // Mouse Down Events
            case EventType.MouseDown:
                ProcessMouseDownEvent(currentEvent);
                break;
            // Mouse Up Events
            case EventType.MouseUp:
                ProcessMouseUpEvent(currentEvent);
                break;
            // Mouse Drag Events
            case EventType.MouseDrag:
                ProcessMouseDragEvent(currentEvent);
                break;
            //// Mouse Scroll Wheel Event
            //case EventType.ScrollWheel:
            //    ProcessScrollMovedEvent(currentEvent);
            //    break;

            default:
                break;
        }
    }

    private void ProcessScrollMovedEvent(Event currentEvent)
    {
        if (currentEvent.delta.y < 0)
        {
            ProcessScrollUpEvent(currentEvent);
        }
        else if (currentEvent.delta.y > 0)
        {
            ProcessScrollDownEvent(currentEvent);
        }
    }

    /// <summary>
    /// Process Scroll Up Event
    /// Zoom in
    /// </summary>
    private void ProcessScrollUpEvent(Event currentEvent)
    {
        if (gridLarge >= maxGridSize) return;
        gridLarge *= 1.1f;
        gridSmall *= 1.1f;

        nodePadding *= 1.05f;
        nodeBorder *= 1.05f;
        roomNodeStyle.padding = new RectOffset((int)nodePadding, (int)nodePadding, (int)nodePadding, (int)nodePadding);
        roomNodeStyle.border = new RectOffset((int)nodeBorder, (int)nodeBorder, (int)nodeBorder, (int)nodeBorder);
        roomNodeSelectedStyle.padding = new RectOffset((int)nodePadding, (int)nodePadding, (int)nodePadding, (int)nodePadding);
        roomNodeSelectedStyle.border = new RectOffset((int)nodeBorder, (int)nodeBorder, (int)nodeBorder, (int)nodeBorder);

        graphOffset *= 1.05f;

        nodeFontSize *= 1.1f;
        roomNodeStyle.fontSize = (int)nodeFontSize;
        roomNodeSelectedStyle.fontSize = (int)nodeFontSize;

        foreach (RoomNodeSO roomNode in currentRoomNodeGraph.roomNodeList)
        {
            roomNode.rect.center *= 1.1f;
            roomNode.rect.width *= 1.05f;
            roomNode.rect.height *= 1.05f;

            EditorUtility.SetDirty(roomNode);
        }

        GUI.changed = true;
    }

    /// <summary>
    /// Process Scroll Down Event
    /// Zoom out
    /// </summary>
    /// <param name="currentEvent"></param>
    private void ProcessScrollDownEvent(Event currentEvent)
    {
        if (gridLarge <= minGridSize) return;

        gridLarge /= 1.1f;
        gridSmall /= 1.1f;

        graphOffset /= 1.05f;

        nodeWidth /= 1.1f;
        nodeHeight /= 1.1f;

        nodePadding /= 1.1f;
        nodeBorder /= 1.1f;
        roomNodeStyle.padding = new RectOffset((int)nodePadding, (int)nodePadding, (int)nodePadding, (int)nodePadding);
        roomNodeStyle.border = new RectOffset((int)nodeBorder, (int)nodeBorder, (int)nodeBorder, (int)nodeBorder);
        roomNodeSelectedStyle.padding = new RectOffset((int)nodePadding, (int)nodePadding, (int)nodePadding, (int)nodePadding);
        roomNodeSelectedStyle.border = new RectOffset((int)nodeBorder, (int)nodeBorder, (int)nodeBorder, (int)nodeBorder);

        nodeFontSize /= 1.1f;
        roomNodeStyle.fontSize = (int)nodeFontSize;
        roomNodeSelectedStyle.fontSize = (int)nodeFontSize;

        foreach (RoomNodeSO roomNode in currentRoomNodeGraph.roomNodeList)
        {
            roomNode.rect.center /= 1.1f;
            roomNode.rect.width /= 1.1f;
            roomNode.rect.height /= 1.1f;
            EditorUtility.SetDirty(roomNode);
        }

        GUI.changed = true;
    }

    /// <summary>
    /// Process Mouse Up events on the room node graph
    /// </summary>
    private void ProcessMouseUpEvent(Event currentEvent)
    {
        // if releasing theright mouse button and currently dragging a line
        if (currentEvent.button == 1 && currentRoomNodeGraph.roomNodeToDrawLineFrom != null)
        {
            // Check if over a room node
            RoomNodeSO roomNode = IsMouseOverRoomNode(currentEvent);

            if (roomNode != null)
            {
                // if SO set it as a child of the parent room node if it can be added
                if (currentRoomNodeGraph.roomNodeToDrawLineFrom.AddChildRoomNodeIDToRoomNode(roomNode.id))
                {
                    // Set parent ID in child room node
                    roomNode.AddParentRoomNodeIDToRoomNode(currentRoomNodeGraph.roomNodeToDrawLineFrom.id);
                }
            }

            ClearLineDrag();
        }
    }

    /// <summary>
    /// Process Mouse Down events on the room node graph (not over a node)
    /// </summary>
    private void ProcessMouseDownEvent(Event currentEvent)
    {
        // Process right click mouse down on graph event
        if (currentEvent.button == 1)
        {
            ShowContextMenu(currentEvent.mousePosition);
        }
        // Process left click mouse down on graph event
        else if (currentEvent.button == 0)
        {
            ClearLineDrag();
            ClearAllSelectedRoomNodes();
        }
    }

    /// <summary>
    /// Process Right Mouse Drag Event
    /// Draw Line
    /// </summary>
    private void ProcessRightMouseDragEvent(Event currentEvent)
    {
        if (currentRoomNodeGraph.roomNodeToDrawLineFrom != null)
        {
            DragConnectingLine(currentEvent.delta);
            GUI.changed = true;
        }
    }

    /// <summary>
    /// Process Left Mouse Drag Event
    /// Drag room node graph
    /// </summary>
    private void ProcessLeftMouseDragEvent(Vector2 dragDelta)
    {
        graphDrag = dragDelta;

        for (int i = 0; i < currentRoomNodeGraph.roomNodeList.Count; i++)
        {
            currentRoomNodeGraph.roomNodeList[i].DragNode(dragDelta);
        }

        GUI.changed = true;
    }

    /// <summary>
    /// Porcess Mouse Drag Event
    /// </summary>
    private void ProcessMouseDragEvent(Event currentEvent)
    {
        // if it is right button, Process Right Mouse Drag Event
        if (currentEvent.button == 1)
        {
            ProcessRightMouseDragEvent(currentEvent);
        }
        else if (currentEvent.button == 0)
        {
            ProcessLeftMouseDragEvent(currentEvent.delta);
        }
    }

    /// <summary>
    /// Clear selection from all room nodes
    /// </summary>
    private void ClearAllSelectedRoomNodes()
    {
        foreach (RoomNodeSO roomNode in currentRoomNodeGraph.roomNodeList)
        {
            if (roomNode.isSelected)
            {
                roomNode.isSelected = false;
                GUI.changed = true;
            }
        }
    }

    /// <summary>
    /// Select All Room Nodes
    /// </summary>
    private void SelectAllRoomNodes()
    {
        foreach (RoomNodeSO roomNode in currentRoomNodeGraph.roomNodeList)
        {
            roomNode.isSelected = true;
        }
        GUI.changed = true;
    }

    /// <summary>
    /// Show Context Menu
    /// </summary>
    private void ShowContextMenu(Vector2 mousePosition)
    {
        // GenericMenu lets you create custom menus or dropdown menus
        GenericMenu menu = new GenericMenu();

        menu.AddItem(new GUIContent("Create Room Node"), false, CreateRoomNode, mousePosition);

        menu.AddSeparator("");
        menu.AddItem(new GUIContent("Select All Room Nodes"), false, SelectAllRoomNodes);

        menu.AddSeparator("");
        menu.AddItem(new GUIContent("Delete Selected Room Node Links"), false, DeletSelectedRoomNodeLinks);
        menu.AddItem(new GUIContent("Delete Selected Room Node"), false, DeletSelectedRoomNode);
        menu.ShowAsContext();
    }

    /// <summary>
    /// Create a room node at the mouse position(Default when it is isNone)
    /// </summary>
    private void CreateRoomNode(object mousePositionObject)
    {
        if (currentRoomNodeGraph.roomNodeList.Count == 0)
        {
            CreateRoomNode(new Vector2(200f, 200f), roomNodeTypeList.list.Find(x => x.isEntrance));
        }

        CreateRoomNode(mousePositionObject, roomNodeTypeList.list.Find(x => x.isNone));
    }

    /// <summary>
    /// Create a room node at the mouse position in other case
    /// overloaded to also pass in RoomNodeType
    /// </summary>
    private void CreateRoomNode(object mousePositionObject, RoomNodeTypeSO roomNodeType)
    {
        // cast to vector2
        Vector2 mousePosition = (Vector2)mousePositionObject;

        // add room node scriptable object asset
        RoomNodeSO roomNode = ScriptableObject.CreateInstance<RoomNodeSO>();

        // add room node to current room node graph room node list
        currentRoomNodeGraph.roomNodeList.Add(roomNode);

        // set room node values
        roomNode.Initialise(new Rect(mousePosition, new Vector2(nodeWidth, nodeHeight)), currentRoomNodeGraph, roomNodeType);

        // add room node to room node graph scriptable object asset database
        AssetDatabase.AddObjectToAsset(roomNode, currentRoomNodeGraph);

        // writes unsaved assets' changes on disk
        AssetDatabase.SaveAssets();

        // Refresh graph node dictionary
        currentRoomNodeGraph.OnValidate();
    }

    /// <summary>
    /// Delete Selected Room Nodes
    /// </summary>
    private void DeletSelectedRoomNode()
    {
        Queue<RoomNodeSO> roomNodeDeletionQueue = new Queue<RoomNodeSO>();

        int entranceRoomNodeCount = 0;
        // loop through all nodes
        foreach (RoomNodeSO roomNode in currentRoomNodeGraph.roomNodeList)
        {
            if (roomNode.roomNodeType.isEntrance) entranceRoomNodeCount++;
            // if node is selected without Entrance
            if (roomNode.isSelected && (entranceRoomNodeCount > 1 || !roomNode.roomNodeType.isEntrance))
            {
                // then Enqueue that node
                roomNodeDeletionQueue.Enqueue(roomNode);

                // loop through child room node IDs
                foreach (string childRoomNodeID in roomNode.childRoomNodeIDList)
                {
                    // Get child room node
                    RoomNodeSO childRoomNode = currentRoomNodeGraph.GetRoomNode(childRoomNodeID);

                    if (childRoomNode != null)
                    {
                        // Remove parent room node id from child node
                        childRoomNode.RemoveParentRoomNodeIDFromRoomNode(roomNode.id);
                    }
                }

                foreach (string parentRoomNodeID in roomNode.parentRoomNodeIDList)
                {
                    // Get Parent Room Node
                    RoomNodeSO parentRoomNode = currentRoomNodeGraph.GetRoomNode(parentRoomNodeID);

                    if (parentRoomNode != null)
                    {
                        // Remove child room node from parent room node
                        parentRoomNode.RemoveChildRoomNodeIDFromRoomNode(roomNode.id);
                    }
                }
            }
        }

        // Delete queue room nodes
        while (roomNodeDeletionQueue.Count > 0)
        {
            // Get room node to delete from queue
            RoomNodeSO roomNodeToDelete = roomNodeDeletionQueue.Dequeue();

            // Remove node from Dictionary
            currentRoomNodeGraph.roomNodeDictionary.Remove(roomNodeToDelete.id);

            // Remove node from list
            currentRoomNodeGraph.roomNodeList.Remove(roomNodeToDelete);

            // Remove node from Asset Database
            DestroyImmediate(roomNodeToDelete, true);

            // Save asset database
            AssetDatabase.SaveAssets();
        }
    }

    /// <summary>
    /// Delete Selected Room Nodes' Links
    /// </summary>
    private void DeletSelectedRoomNodeLinks()
    {
        // Check all room nodes
        foreach (RoomNodeSO roomNode in currentRoomNodeGraph.roomNodeList)
        {
            // Selected node and having child node
            if (roomNode.isSelected && roomNode.childRoomNodeIDList.Count > 0)
            {
                // all child nodes
                for (int i = roomNode.childRoomNodeIDList.Count - 1; i >= 0; i--)
                {
                    // Get Child Room Node
                    RoomNodeSO childRoomNode = currentRoomNodeGraph.GetRoomNode(roomNode.childRoomNodeIDList[i]);

                    // if the child node is selected
                    if (childRoomNode != null && childRoomNode.isSelected)
                    {
                        // Remove Child Room Node ID from parent node
                        roomNode.RemoveChildRoomNodeIDFromRoomNode(childRoomNode.id);
                        // Remove Parent Room Node ID from child node
                        childRoomNode.RemoveParentRoomNodeIDFromRoomNode(roomNode.id);
                    }
                }
            }
        }

        // Clear all selected room nodes
        ClearAllSelectedRoomNodes();
    }

    /// <summary>
    /// Drag Connecting Line from room node
    /// </summary>
    private void DragConnectingLine(Vector2 delta)
    {
        currentRoomNodeGraph.linePosition += delta;
    }

    /// <summary>
    /// Clear Line for Drag
    /// </summary>
    private void ClearLineDrag()
    {
        currentRoomNodeGraph.roomNodeToDrawLineFrom = null;
        currentRoomNodeGraph.linePosition = Vector2.zero;
        GUI.changed = true;
    }

    /// <summary>
    /// Draw room Nodes in the graph window
    /// </summary>
    private void DrawRoomNodes()
    {
        foreach (RoomNodeSO roomNode in currentRoomNodeGraph.roomNodeList)
        {
            if (roomNode.isSelected)
            {
                roomNode.Draw(roomNodeSelectedStyle);
            }
            else
            {
                roomNode.Draw(roomNodeStyle);
            }
        }

        GUI.changed = true;
    }

    /// <summary>
    /// Draw connections in the graph window between room nodes
    /// </summary>
    private void DrawRoomConnections()
    {
        // Loop through child room nodes
        foreach (RoomNodeSO roomNode in currentRoomNodeGraph.roomNodeList)
        {
            if (roomNode.childRoomNodeIDList.Count > 0)
            {
                // Loop through child room nodes
                foreach (string childRoomNodeID in roomNode.childRoomNodeIDList)
                {
                    // get child room node from dictionary
                    if (currentRoomNodeGraph.roomNodeDictionary.ContainsKey(childRoomNodeID))
                    {
                        DrawConnectionLine(roomNode, currentRoomNodeGraph.roomNodeDictionary[childRoomNodeID]);
                        GUI.changed = true;
                    }
                }
            }
        }
    }

    /// <summary>
    /// Draw Connection Line between the parent room node and child room node
    /// </summary>
    private void DrawConnectionLine(RoomNodeSO parentRoomNode, RoomNodeSO childRoomNode)
    {
        // get line start and end postion
        Vector2 startPosition = parentRoomNode.rect.center;
        Vector2 endPosition = childRoomNode.rect.center;

        Vector2 dirVector = endPosition - startPosition;
        Vector2 centerPoint = (startPosition + endPosition) / 2f;
        Vector2 arrowHeadPoint = centerPoint + dirVector.normalized * connectingLineArrowSize;
        Vector2 arrowTailPoint1 = centerPoint + new Vector2(-dirVector.y, dirVector.x).normalized * connectingLineArrowSize;
        Vector2 arrowTailPoint2 = centerPoint - new Vector2(-dirVector.y, dirVector.x).normalized * connectingLineArrowSize;

        // Draw Line
        Handles.DrawBezier(startPosition, endPosition, startPosition, endPosition, Color.white, null, connectingLineWidth);
        // Draw Arrow
        Handles.DrawBezier(arrowTailPoint1, arrowHeadPoint, arrowTailPoint1, arrowHeadPoint, Color.white, null, connectingLineWidth);
        Handles.DrawBezier(arrowTailPoint2, arrowHeadPoint, arrowTailPoint2, arrowHeadPoint, Color.white, null, connectingLineWidth);

        GUI.changed = true;
    }

    /// <summary>
    ///  Selection Changed in the inspector
    /// </summary>
    private void InspectorSelectionChanged()
    {
        // Selection.activeObject means what object set active on inspector
        // we can casting to use "as" keyword to RoomNodeGraphSO
        // currentRoomNodeGraph = what object set active on inspector
        RoomNodeGraphSO roomNodeGraph = Selection.activeObject as RoomNodeGraphSO;

        if (roomNodeGraph != null)
        {
            currentRoomNodeGraph = roomNodeGraph;
            GUI.changed = true;
        }
    }
}