using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

// This Node will be made on Custom Editor
// so we dont need to define using CreateAssetMenu
public class RoomNodeSO : ScriptableObject
{
    [HideInInspector] public string id;
    [HideInInspector] public List<string> parentRoomNodeIDList = new List<string>();
    [HideInInspector] public List<string> childRoomNodeIDList = new List<string>();
    [HideInInspector] public RoomNodeGraphSO roomNodeGraph;
    public RoomNodeTypeSO roomNodeType;
    [HideInInspector] public RoomNodeTypeListSO roomNodeTypeList;
    [HideInInspector] public List<UnityEngine.Object> isSelectedObjectList = new List<UnityEngine.Object>();

    #region Editor Code

    // following code should only be run in the Unity Editor
#if UNITY_EDITOR
    [HideInInspector] public Rect rect;
    [HideInInspector] public bool isLeftClickDragging = false;
    [HideInInspector] public bool isSelected = false;

    /// <summary>
    /// Initialise node
    /// </summary>
    public void Initialise(Rect rect, RoomNodeGraphSO nodeGraph, RoomNodeTypeSO roomNodeType)
    {
        this.rect = rect;
        this.id = Guid.NewGuid().ToString();
        this.name = "RoomNode";
        this.roomNodeGraph = nodeGraph;
        this.roomNodeType = roomNodeType;

        // Load room node type list
        roomNodeTypeList = GameResources.Instance.roomNodeTypeList;
    }

    /// <summary>
    /// Draw Nodes with nodestyle
    /// </summary>
    public void Draw(GUIStyle nodeStyle)
    {
        // Draw Node Box Using BeginArea
        GUILayout.BeginArea(rect, nodeStyle);

        // Start Region To Detect Popup Selection Changes
        EditorGUI.BeginChangeCheck();

        // if the room node has a parent or is of type entrance then display a label else display a popup
        if (parentRoomNodeIDList.Count > 0 || roomNodeType.isEntrance)
        {
            // Display a label that cant be changed
            EditorGUILayout.LabelField(roomNodeType.roomNodeTypeName);
        }
        else
        {
            // Display a popup using the RoomNodeType name values that can be selected from
            // default to the currently set roomNodeType
            int selected = roomNodeTypeList.list.FindIndex(x => x == roomNodeType);

            int selection = EditorGUILayout.Popup("", selected, GetRoomNodeTypesToDisplay());

            roomNodeType = roomNodeTypeList.list[selection];

            // if the room type selection has changed making child connections potentially invalid
            if (roomNodeTypeList.list[selected].isCorridor && !roomNodeTypeList.list[selection].isCorridor || !roomNodeTypeList.list[selected].isCorridor
                && roomNodeTypeList.list[selection].isCorridor || !roomNodeTypeList.list[selected].isBossRoom && roomNodeTypeList.list[selection].isBossRoom)
            {
                // if a room node typ has been changed and it already has children then delete the parent child links since we need to revalidate
                if (childRoomNodeIDList.Count > 0)
                {
                    // all child nodes
                    for (int i = childRoomNodeIDList.Count - 1; i >= 0; i--)
                    {
                        // Get Child Room Node
                        RoomNodeSO childRoomNode = roomNodeGraph.GetRoomNode(childRoomNodeIDList[i]);

                        // if the child node is selected
                        if (childRoomNode != null)
                        {
                            // Remove Child Room Node ID from parent node
                            RemoveChildRoomNodeIDFromRoomNode(childRoomNode.id);
                            // Remove Parent Room Node ID from child node
                            childRoomNode.RemoveParentRoomNodeIDFromRoomNode(id);
                        }
                    }
                }
            }
        }

        if (EditorGUI.EndChangeCheck())
        {
            EditorUtility.SetDirty(this);
        }

        GUILayout.EndArea();
    }

    private string[] GetRoomNodeTypesToDisplay()
    {
        string[] roomArray = new string[roomNodeTypeList.list.Count];

        for (int i = 0; i < roomNodeTypeList.list.Count; i++)
        {
            //if (roomNodeTypeList.list[i].roomNodeTypeName != "Entrance")
            roomArray[i] = roomNodeTypeList.list[i].roomNodeTypeName;
        }

        return roomArray;
    }

    /// <summary>
    /// Switch each other which MouseEvent called
    /// MouseDown, MouseUp, MouseDrag
    /// I can call the type using EventType
    /// </summary>
    public void ProcessEvents(Event currentEvent)
    {
        switch (currentEvent.type)
        {
            case EventType.MouseDown:
                ProcessMouseDownEvent(currentEvent);
                break;

            case EventType.MouseUp:
                ProcessMouseUpEvent(currentEvent);
                break;

            case EventType.MouseDrag:
                ProcessMouseDragEvent(currentEvent);
                break;

            //case EventType.ScrollWheel:
            //    ProcessScrollMovedEvent(currentEvent);
            //    break;

            default:
                break;
        }
    }

    private void ProcessScrollMovedEvent(Event currentEvent)
    {
        if (currentEvent.delta.y < 0)
        {
            ProcessScrollUpEvent(currentEvent);
        }
        else if (currentEvent.delta.y > 0)
        {
            ProcessScrollDownEvent(currentEvent);
        }
    }

    /// <summary>
    /// Process Scroll Up Event
    /// Zoom in
    /// </summary>
    private void ProcessScrollUpEvent(Event currentEvent)
    {
        Debug.Log(currentEvent.delta);
    }

    /// <summary>
    /// Process Scroll Down Event
    /// Zoom out
    /// </summary>
    /// <param name="currentEvent"></param>
    private void ProcessScrollDownEvent(Event currentEvent)
    {
        Debug.Log(currentEvent.delta);
    }

    /// <summary>
    /// When the MouseDown called
    /// </summary>
    /// <param name="currentEvent"></param>
    private void ProcessMouseDownEvent(Event currentEvent)
    {
        // left click down
        if (currentEvent.button == 0)
        {
            ProcessLeftClickDownEvent();
        }
        // right click down
        else if (currentEvent.button == 1)
        {
            ProcessRightClickDownEvent(currentEvent);
        }
    }

    /// <summary>
    /// When the MouseUp called
    /// </summary>
    private void ProcessMouseUpEvent(Event currentEvent)
    {
        // left click up
        if (currentEvent.button == 0)
        {
            ProcessLeftClickUpEvent();
        }
    }

    /// <summary>
    /// When the MouseDrag called
    /// </summary>
    private void ProcessMouseDragEvent(Event currentEvent)
    {
        if (currentEvent.button == 0)
        {
            ProcessLeftMouseDragEvent(currentEvent);
        }
    }

    /// <summary>
    /// Process  Left Click Down Event
    /// </summary>
    private void ProcessLeftClickDownEvent()
    {
        // Returns the actual object selection
        // we can check the Node selection in Unity Editor bcs of this code
        Selection.activeObject = this;

        // Select node in Toggle way
        if (isSelected == false)
        {
            isSelected = true;
            isSelectedObjectList.Add(this);
        }
        else
        {
            isSelected = false;
            isSelectedObjectList.Remove(this);
        }

        if (isSelectedObjectList.Count != 0)
        {
            foreach (UnityEngine.Object selectedObject in isSelectedObjectList)
            {
                Selection.activeObject = selectedObject;
            }
        }
    }

    /// <summary>
    /// Process Right Click Down Event
    /// </summary>
    private void ProcessRightClickDownEvent(Event currentEvent)
    {
        roomNodeGraph.SetNodeToDrawConnectionLineFrom(this, currentEvent.mousePosition);
    }

    /// <summary>
    /// Process Left Click Up Event
    /// </summary>
    private void ProcessLeftClickUpEvent()
    {
        if (isLeftClickDragging)
        {
            isLeftClickDragging = false;
        }
    }

    /// <summary>
    /// Process Left Mouse Dragging Event
    /// </summary>
    private void ProcessLeftMouseDragEvent(Event currentEvent)
    {
        isLeftClickDragging = true;

        // Event.delta == how much changed compare with last Event
        DragNode(currentEvent.delta);
        GUI.changed = true;
    }

    /// <summary>
    /// Dragging Node
    /// </summary>
    public void DragNode(Vector2 delta)
    {
        rect.position += delta;
        // Set Dirty
        // Dirty means somethings are happened in this asset
        EditorUtility.SetDirty(this);
    }

    /// <summary>
    /// if the end point is on the room node
    /// Add ChildID on the Child Node List
    /// </summary>
    /// <returns> if it will add node on list return true else false </returns>
    public bool AddChildRoomNodeIDToRoomNode(string childID)
    {
        if (IsChildRoomValid(childID))
        {
            childRoomNodeIDList.Add(childID);
            return true;
        }

        return false;
    }

    /// <summary>
    /// Check the child node can be validly added to the parent node
    /// </summary>
    /// <returns>return true if it can otherwise return false</returns>
    private bool IsChildRoomValid(string childID)
    {
        bool isConnectedBossNodeAlready = false;
        // Check if there is there already a connected boss room in the node graph
        foreach (RoomNodeSO roomNode in roomNodeGraph.roomNodeList)
        {
            if (roomNode.roomNodeType.isBossRoom && roomNode.parentRoomNodeIDList.Count > 0)
            {
                isConnectedBossNodeAlready = true;
            }
        }

        // if the child node has a tyoe of boss room and there is already a connected boss room node then return false
        if (roomNodeGraph.GetRoomNode(childID).roomNodeType.isBossRoom && isConnectedBossNodeAlready)
            return false;

        // if the child node has a type of none then return false
        if (roomNodeGraph.GetRoomNode(childID).roomNodeType.isNone)
            return false;

        // if the child node has already same child ID then return false
        if (childRoomNodeIDList.Contains(childID))
            return false;

        // if this node ID and the child ID are the same return false
        if (id == childID)
            return false;

        // if this childID is already in the parentID list then return false
        if (parentRoomNodeIDList.Contains(childID))
            return false;

        // if this childID already has a parent then return false
        if (roomNodeGraph.GetRoomNode(childID).parentRoomNodeIDList.Count > 0)
            return false;

        // if child is a corridor and this node is a corridor return false
        if (roomNodeGraph.GetRoomNode(childID).roomNodeType.isCorridor && roomNodeType.isCorridor)
            return false;

        // if child is not a corridor and this node is not a corridor return false
        // I mean when it tries to connect room and room
        if (!roomNodeGraph.GetRoomNode(childID).roomNodeType.isCorridor && !roomNodeType.isCorridor)
            return false;

        // if parent node already has child nodes(Corridors) more than Settings.maxChildCorridors then return false
        if (roomNodeGraph.GetRoomNode(childID).roomNodeType.isCorridor && childRoomNodeIDList.Count >= Settings.maxChildCorridors)
            return false;

        // if the child room is an entrance type then return false
        // Entrance cant be child node and also cant have parent node
        if (roomNodeGraph.GetRoomNode(childID).roomNodeType.isEntrance)
            return false;

        // if the parent node is a corridor and child node is room node
        // and the parent node already has a child node then return false
        // corridor node can have only one room node(child node)
        if (!roomNodeGraph.GetRoomNode(childID).roomNodeType.isCorridor && childRoomNodeIDList.Count > 0)
            return false;

        return true;
    }

    /// <summary>
    /// if the end point is on the room node
    /// Add ParentID on the child Node List
    /// </summary>
    /// <returns> if it will add node on list return true else false </returns>
    public bool AddParentRoomNodeIDToRoomNode(string parentID)
    {
        parentRoomNodeIDList.Add(parentID);
        return true;
    }

    /// <summary>
    /// Remvoe childID from the nodes
    /// </summary>
    /// <returns> retunrs true if the node has been removed, return false otherwise</returns>
    public bool RemoveChildRoomNodeIDFromRoomNode(string childID)
    {
        // if the node contains the child ID then remove it
        if (childRoomNodeIDList.Contains(childID))
        {
            childRoomNodeIDList.Remove(childID);
            return true;
        }
        return false;
    }

    /// <summary>
    /// Remove parentID from nodes
    /// </summary>
    /// <returns>return true if the node has been removed</returns>
    public bool RemoveParentRoomNodeIDFromRoomNode(string parentID)
    {
        // if the node contaings parentID then remove it
        if (parentRoomNodeIDList.Contains(parentID))
        {
            parentRoomNodeIDList.Remove(parentID);
            return true;
        }
        return false;
    }

#endif

    #endregion Editor Code
}