using UnityEngine;

[CreateAssetMenu(fileName = "RoomNodeType_", menuName = "Scriptable Objects/Dungeon/Room Node Type")]
public class RoomNodeTypeSO : ScriptableObject
{
    public string roomNodeTypeName;

    #region Header
    [Header("RoomNodeTypes can be visible in Editor")]
    public bool displayInNodeGraphEditor = true;
    #endregion Header

    #region Header
    [Header("One of Type should be Corridor")]
    public bool isCorridor;
    #endregion Header

    #region Header
    [Header("One of Type should be CorridorNS")]
    public bool isCorridorNS;
    #endregion Header

    #region Header
    [Header("One of Type should be CorridorEW")]
    public bool isCorridorEW;
    #endregion Header


    #region Header
    [Header("One of Type should be Entrance")]
    public bool isEntrance;
    #endregion Header

    #region Header
    [Header("One of Type should be BossRoom")]
    public bool isBossRoom;
    #endregion Header

    #region Header
    [Header("One of Type should be (Unassigned)")]
    public bool isNone;
    #endregion Header

    #region Validation

#if UNITY_EDITOR

    // On Validate will be called when value chages are detected on inspector.
    // In this case, When Scriptable Object's Value is changed, this method will be called
    private void OnValidate()
    {
        HelperUtilities.ValidateCheckEmptyString(this, nameof(roomNodeTypeName), roomNodeTypeName);
    }

#endif

    #endregion Validation

}