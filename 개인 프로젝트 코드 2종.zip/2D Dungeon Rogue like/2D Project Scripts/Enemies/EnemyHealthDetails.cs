
[System.Serializable]
public struct EnemyHealthDetails
{
    public DungeonLevelSO dungeonLevel;
    public int enemyHealthAmount;
}

