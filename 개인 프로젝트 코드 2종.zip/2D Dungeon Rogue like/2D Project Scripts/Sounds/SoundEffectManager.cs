using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
public class SoundEffectManager : SingletonMonobehaviour<SoundEffectManager>
{
    public int soundsVolume = 8;
    private int count = 0;
    private SoundEffect sound;
    private List<SoundEffect> soundEffectList = new List<SoundEffect>();
    private Coroutine playCoroution;
    private bool isStop = false;

    private void Start()
    {
        SetSoundsVolume(soundsVolume);
    }

    /// <summary>
    /// Play sound effect
    /// </summary>
    public void PlaySoundEffect(SoundEffectSO soundEffect)
    {
        // Get SoundeEffect object from object pool
        SoundEffect sound = (SoundEffect)PoolManager.Instance.ReuseComponent(soundEffect.soundPrefab, Vector3.zero, Quaternion.identity);

        if (sound == null) return;

        sound.SetSound(soundEffect);

        sound.gameObject.SetActive(true);

        StartCoroutine(DisableSound(sound, soundEffect.soundEffectClip.length));
    }

    /// <summary>
    /// Play sound effect for List
    /// </summary>
    public void PlaySoundEffect(List<SoundEffectSO> soundEffects)
    {
        playCoroution = StartCoroutine(PlaySounds(soundEffects));

        foreach(SoundEffect sound in soundEffectList)
        {
            StartCoroutine(DisableSound(sound, sound.audioSource.clip.length)) ;
        }
    }

    /// <summary>
    /// Stop sound list
    /// </summary>
    public void StopSoundEffectsOnList()
    {
        isStop = true;

        foreach (SoundEffect sound in soundEffectList)
        {
            sound.gameObject.SetActive(false);
        }

        if(playCoroution != null)
        {
            StopCoroutine(playCoroution);
        }

        soundEffectList.Clear();

        isStop = false;
    }

    /// <summary>
    /// Increase sounds volume
    /// </summary>
    public void IncreaseSoundsVolume()
    {
        int maxSoundsVolume = 20;

        if (soundsVolume >= maxSoundsVolume) return;

        soundsVolume += 1;

        SetSoundsVolume(soundsVolume); ;
    }

    /// <summary>
    /// Decrease sounds volume
    /// </summary>
    public void DecreaseSoundsVolume()
    {
        if (soundsVolume == 0) return;

        soundsVolume -= 1;

        SetSoundsVolume(soundsVolume);
    }

    /// <summary>
    /// Disable sound effect gameObject after it played returning it to object pool
    /// </summary>
    private IEnumerator DisableSound(SoundEffect sound, float soundLength)
    {
        yield return new WaitForSeconds(soundLength);
        sound.gameObject.SetActive(false);
    }

    /// <summary>
    /// Play sound effects from soundEffects list
    /// </summary>
    private IEnumerator PlaySounds(List<SoundEffectSO> soundEffects)
    {
        count = 0;
        
        while (count < soundEffects.Count && !isStop)
        {
            SetSoundEffectFromObjectPool(soundEffects);
            yield return new WaitForSeconds(soundEffects[count].soundEffectClip.length);
            soundEffectList.Remove(sound);
            sound.gameObject.SetActive(false);
            count++;
        }

        isStop = false;
        soundEffectList.Clear();
        count = 0;
    }

    private void SetSoundEffectFromObjectPool(List<SoundEffectSO> soundEffects)
    {
        if (count >= soundEffects.Count)
        {
            count = 0;
            return;
        }

        // Get SoundeEffect object from object pool
        sound = (SoundEffect)PoolManager.Instance.ReuseComponent(soundEffects[count].soundPrefab, Vector3.zero, Quaternion.identity);

        sound.SetSound(soundEffects[count]);

        sound.gameObject.SetActive(true);

        soundEffectList.Add(sound);
    }

    /// <summary>
    /// Set sounds volume
    /// </summary>
    private void SetSoundsVolume(int sooundsVolume)
    {
        float muteDecibels = -80f;

        if (soundsVolume == 0)
        {
            GameResources.Instance.soundsMasterMixerGroup.audioMixer.SetFloat("soundsVolume", muteDecibels);
        }
        else
        {
            GameResources.Instance.soundsMasterMixerGroup.audioMixer.SetFloat("soundsVolume", HelperUtilities.LinearToDecibels(soundsVolume));
        }
    }
}