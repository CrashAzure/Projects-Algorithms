using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PressAnyKey : MonoBehaviour
{
    private UIHelper uiHelper;
    private float delayInput = 3.0f;

    private void Awake()
    {
        uiHelper = FindObjectOfType<UIHelper>();
        
    }
    // Update is called once per frame
    void Update()
    {
        if(delayInput >= 0f)
        {
            delayInput -= Time.deltaTime;
            return;
        }

        if (Input.anyKeyDown)
        {
            uiHelper.soundEffectManager.PlaySoundEffect(GameResources.Instance.doorOpenCloseSoundEffect);

            SceneManager.LoadScene("MainMenuScene");

            if (uiHelper.gameObject.activeSelf)
            {
                uiHelper.gameObject.SetActive(false);
            }
        }
    }
}
