using JetBrains.Annotations;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class Flash : MonoBehaviour
{
    [HideInInspector] public bool isTitleScene;
    private Image flashImage;

    [SerializeField] private float flashCycleTime = 4.0f;
    private float flashTimer = 0f;
    private bool isFlash = true;
    private Vector4 flashVector4 =  new Vector4(255f, 255f, 255f, 255f);
    private Vector4 nonFlashVector4 = new Vector4(255f, 255f, 255f, 0f);

    private Coroutine flashCoroutine;


    // Start is called before the first frame update
    void Start()
    {
        flashImage = GetComponent<Image>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!isTitleScene) return;

        if(flashTimer <= flashCycleTime)
        {
            flashTimer += Time.deltaTime;
            return;
        }

        if (isFlash)
        {
            ProcessFlashCoroutine();
        }

        flashTimer = 0f;
    }

    /// <summary>
    /// Process flash coroutine
    /// </summary>
    private void ProcessFlashCoroutine()
    {
        if (flashCoroutine != null)
        {
            StopCoroutine(flashCoroutine);
        }

        flashCoroutine = StartCoroutine(FlashCoroutine());
    }

    /// <summary>
    /// Delay time for flash out at other class
    /// </summary>
    public void ProcessFlashCoroutine(float delayTime)
    {
        if (flashCoroutine != null)
        {
            StopCoroutine(flashCoroutine);
        }

        flashCoroutine = StartCoroutine(FlashCoroutine(delayTime));
    }

    private IEnumerator FlashCoroutine()
    {
        isFlash = false;

        flashImage.color = flashVector4;
        yield return new WaitForSeconds(0.05f);
        flashImage.color = nonFlashVector4;

        if(Random.Range(0f,1f) >= 0.5f)
        {
            yield return new WaitForSeconds(0.05f);
            flashImage.color = flashVector4;
            yield return new WaitForSeconds(0.05f);
            flashImage.color = nonFlashVector4;
        }

        isFlash = true;
    }

    private IEnumerator FlashCoroutine(float delayTime)
    {
        isFlash = false;

        GetComponentInParent<Canvas>().sortingOrder = 700;
        flashImage.color = flashVector4;
        yield return new WaitForSeconds(delayTime);
        flashImage.color = nonFlashVector4;
        GetComponentInParent<Canvas>().sortingOrder = 0;

        isFlash = true;
    }
}
