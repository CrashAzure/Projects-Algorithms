using System.Collections.Generic;

[System.Serializable]
public class HighScores
{
    public List<Score> scoreList = new List<Score>();
}
