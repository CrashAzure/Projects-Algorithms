using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;

public class WeaponStatusUI : MonoBehaviour
{
    #region Header OBJECT REFERENCES
    [Space(10)]
    [Header("OBJECT REFERENCES")]
    #endregion Header OBJECT REFERENCES
    #region Tooltip
    [Tooltip("Populate with image component on the child WeaponImage gameobject")]
    #endregion Tooltip
    [SerializeField] private Image weaponImage;
    #region Tooltip
    [Tooltip("Populate with the Transform from the child AmmoHolder gameobject")]
    #endregion Tooltip
    [SerializeField] private Transform ammoHolderTransform;
    #region Tooltip
    [Tooltip("Populate with the TextMeshPro-Text component on the child ReloadText gameobject")]
    #endregion Tooltip
    [SerializeField] private TextMeshProUGUI reloadText;
    #region Tooltip
    [Tooltip("Populate with the TextMeshPro-Text component on the child AmmoRemainingText gameobject")]
    #endregion Tooltip
    [SerializeField] private TextMeshProUGUI ammoRemainingText;
    #region Tooltip
    [Tooltip("Populate with the TextMeshPro-Text component on the child WeaponNameText gameobject")]
    #endregion Tooltip
    [SerializeField] private TextMeshProUGUI weaponNameText;
    #region Tooltip
    [Tooltip("Populate with the RectTransform of the child gameobject ReloadBar")]
    #endregion Tooltip
    [SerializeField] private Transform reloadBar;
    #region Tooltip
    [Tooltip("Populate with the Image component of the child gameobject BarImage")]
    #endregion Tooltip
    [SerializeField] private Image barImage;

    private Player player;
    private List<GameObject> ammoIconList = new List<GameObject>();
    private Coroutine reloadWeaponCoroutine;
    private Coroutine blinkingReloadTextCoroutine;

    private void Awake()
    {
        // Get Player from GameManager Instance
        player = GameManager.Instance.GetPlayer();
    }

    private void OnEnable()
    {
        // Subscribe set active weapon event
        player.setActiveWeaponEvent.OnSetActiveWeapon += SetActiveWeapon_OnSetActiveWeapon;

        // Subscribe weapon fired event
        player.weaponFiredEvent.OnWeaponFired += WeaponFired_OnWeaponFired;

        // Subscribe reload weapon event
        player.reloadWeaponEvent.OnReloadWeapon += ReloadWeapon_OnReloadWeapon;

        // Subscribe weapon reloaded event
        player.weaponReloadedEvent.OnWeaponReloaded += WeaponReloaded_OnWeaponReloaded;
    }

    private void OnDisable()
    {
        // Unsubscribe set active weapon event
        player.setActiveWeaponEvent.OnSetActiveWeapon -= SetActiveWeapon_OnSetActiveWeapon;

        // Unsubscribe weapon fired event
        player.weaponFiredEvent.OnWeaponFired -= WeaponFired_OnWeaponFired;

        // Unsubscribe reload weapon event
        player.reloadWeaponEvent.OnReloadWeapon -= ReloadWeapon_OnReloadWeapon;

        // Unsubscribe weapon reloaded event
        player.weaponReloadedEvent.OnWeaponReloaded -= WeaponReloaded_OnWeaponReloaded;
    }

    private void Start()
    {
        // Update active weapon status on UI
        SetActiveWeapon(player.activeWeapon.GetCurrentWeapon());
    }


    /// <summary>
    /// Handle SetActiveWeaponEvent
    /// </summary>
    private void SetActiveWeapon_OnSetActiveWeapon(SetActiveWeaponEvent setActiveWeaponEvent, SetActiveWeaponEventArgs setActiveWeaponEventArgs)
    {
        SetActiveWeapon(setActiveWeaponEventArgs.weapon);
    }

    /// <summary>
    ///  Handle WeaponFiredEvent
    /// </summary>
    private void WeaponFired_OnWeaponFired(WeaponFiredEvent weaponFiredEvent, WeaponFiredEventArgs weaponFiredEventArgs)
    {
        WeaponFired(weaponFiredEventArgs.weapon);
    }

    /// <summary>
    /// Weapon fired
    /// </summary>
    private void WeaponFired(Weapon weapon)
    {
        UpdateAmmoText(weapon);
        UpdateAmmoLoadedIcons(weapon);
        UpdateReloadText(weapon);
    }

    /// <summary>
    /// Handle ReloadWeaponEvent
    /// </summary>
    private void ReloadWeapon_OnReloadWeapon(ReloadWeaponEvent reloadWeaponEvent, ReloadWeaponEventArgs reloadWeaponEventArgs)
    {
        if(reloadWeaponEventArgs.weapon.weaponDetails.weaponName == "Shotgun")
        {
            SetReloadingBarColor(Color.red);
        }
        else
        {
            UpdateWeaponReloadBar(reloadWeaponEventArgs.weapon);
        }
        
    }



    /// <summary>
    /// Handle WeaponReloadedEvent
    /// </summary>
    private void WeaponReloaded_OnWeaponReloaded(WeaponReloadedEvent weaponReloadedEvent, WeaponReloadedEventArgs weaponReloadedEventArgs)
    {
        WeaponReloaded(weaponReloadedEventArgs.weapon);
    }

    /// <summary>
    /// Weapon reloaded
    /// </summary>
    private void WeaponReloaded(Weapon weapon)
    {
        // if weapon reloaded is current weapon
        if(player.activeWeapon.GetCurrentWeapon() == weapon)
        {
            UpdateAmmoText(weapon);
            UpdateAmmoLoadedIcons(weapon);
            UpdateReloadText(weapon);
            if (weapon.weaponDetails.weaponName != "Shotgun")
            {
                StopBlinkingReloadText();
                ResetWeaponReloadBar();
            }
            else if(weapon.weaponClipRemainingAmmo >= weapon.weaponRemainingAmmo
                || weapon.weaponClipRemainingAmmo == weapon.weaponDetails.weaponClipAmmoCapacity)
            {
                StopBlinkingReloadText();
                ResetWeaponReloadBar();
            }
        }
    }

    /// <summary>
    /// Set active weapon on UI
    /// </summary>
    private void SetActiveWeapon(Weapon weapon)
    {
        UpdateActiveWeaponImage(weapon.weaponDetails);
        UpdateActiveWeaponName(weapon);
        UpdateAmmoText(weapon);
        UpdateAmmoLoadedIcons(weapon);

        // if set weapon is reloading then update reload bar
        if (weapon.isWeaponReloading)
        {
            UpdateWeaponReloadBar(weapon);
        }
        else
        {
            ResetWeaponReloadBar();
        }

        UpdateReloadText(weapon);
    }

    /// <summary>
    /// Update active weapon image
    /// </summary>
    private void UpdateActiveWeaponImage(WeaponDetailsSO weaponDetails)
    {
        weaponImage.sprite = weaponDetails.weaponSprite;
    }

    /// <summary>
    /// Update active weapon name
    /// </summary>
    private void UpdateActiveWeaponName(Weapon weapon)
    {
        weaponNameText.text = "<" + weapon.weaponListPosition + "> " + weapon.weaponDetails.weaponName.ToUpper();
    }

    /// <summary>
    /// Update ammo text
    /// </summary>
    private void UpdateAmmoText(Weapon weapon)
    {
        if (weapon.weaponDetails.hasInfiniteAmmo)
        {
            ammoRemainingText.text = "INFINITE AMMO";
        }
        else
        {
            ammoRemainingText.text = "<" + weapon.weaponRemainingAmmo.ToString() + " / "+ weapon.weaponDetails.weaponAmmoCapacity.ToString() + ">";
        }
        
    }

    /// <summary>
    /// Update ammo loaded icons
    /// </summary>
    private void UpdateAmmoLoadedIcons(Weapon weapon)
    {
        ClearAmmoLoadedIcons();

        for(int i = 0; i < weapon.weaponClipRemainingAmmo; i++)
        {
            // Instantiate ammo icon prefab
            GameObject ammoIcon = Instantiate(GameResources.Instance.ammoIconPrefab, ammoHolderTransform);
            int ammoIconLineCount = i / 10;
            int ammoIconLastLineCount = i % 10;
            float ammoIconXPosition = ammoIconLineCount * 6f;

            ammoIcon.GetComponent<RectTransform>().anchoredPosition = new Vector2(ammoIconXPosition, Settings.uiAmmoIconSpacing * ammoIconLastLineCount);

            ammoIconList.Add(ammoIcon);
        }
    }

    /// <summary>
    /// Clear ammo loaded icons
    /// </summary>
    private void ClearAmmoLoadedIcons()
    {
        // Loop through icon gameobjects in ammoIconList
        // and destroy it
        foreach(GameObject ammoIcon in ammoIconList)
        {
            Destroy(ammoIcon);
        }

        ammoIconList.Clear();
    }

    /// <summary>
    /// Update waepon reload progress bar
    /// </summary>
    private void UpdateWeaponReloadBar(Weapon weapon)
    {
        if (weapon.weaponDetails.hasInfiniteClipCapacity)
            return;

        StopReloadWeaponCoroutine();
        UpdateReloadText(weapon);

        reloadWeaponCoroutine = StartCoroutine(UpdateWeaponReloadBarRoutine(weapon));
    }

    /// <summary>
    /// Stop reload weapon progress bar coroutine
    /// </summary>
    private void StopReloadWeaponCoroutine()
    {
        // stop any active weapon reload bar on UI
        if(reloadWeaponCoroutine != null)
        {
            StopCoroutine(reloadWeaponCoroutine);
        }
    }

    /// <summary>
    /// Update weapon reload bar coroutine
    /// </summary>
    private IEnumerator UpdateWeaponReloadBarRoutine(Weapon weapon)
    {
        // set reload bar to red
        SetReloadingBarColor(Color.red);

        // Animate weapon reload bar
        while (weapon.isWeaponReloading)
        {
            // update reloadbar
            float barFill = weapon.weaponReloadTimer / weapon.weaponDetails.weaponReloadTime;

            // update bar fill
            reloadBar.transform.localScale = new Vector3(barFill, 1f, 1f);

            yield return null;
        }
    }

    /// <summary>
    /// Reset weapon reload bar
    /// </summary>
    private void ResetWeaponReloadBar()
    {
        // Stop reload weapon coroutine
        StopReloadWeaponCoroutine();

        // reset bar image to green
        SetReloadingBarColor(Color.green);

        // set reloadBar localScale to 1f, 1f, 1f
        reloadBar.transform.localScale = new Vector3(1f, 1f, 1f);
    }

    /// <summary>
    /// Update reload text
    /// </summary>
    private void UpdateReloadText(Weapon weapon)
    {
        if((!weapon.weaponDetails.hasInfiniteClipCapacity)&&(weapon.weaponClipRemainingAmmo <= 0 || weapon.isWeaponReloading))
        {
            // set barImage color to red
            SetReloadingBarColor(Color.red);

            StopBlinkingReloadTextCoroutine();

            blinkingReloadTextCoroutine = StartCoroutine(StartBlinkingReloadTextRoutine());
        }
        else
        {
            StopBlinkingReloadText();
        }
    }

    /// <summary>
    /// Stop blinking reload text coroutine
    /// </summary>
    private void StopBlinkingReloadTextCoroutine()
    {
        if(blinkingReloadTextCoroutine != null)
        {
            StopCoroutine(blinkingReloadTextCoroutine);
        }
    }

    /// <summary>
    /// Stop coroutine and reset reload text
    /// </summary>
    private void StopBlinkingReloadText()
    {
        StopBlinkingReloadTextCoroutine();

        reloadText.text = "";
    }

    /// <summary>
    /// Start blinking reload text
    /// </summary>
    private IEnumerator StartBlinkingReloadTextRoutine()
    {
        while (true)
        {
            reloadText.text = "RELOADING";
            yield return new WaitForSeconds(0.3f);
            reloadText.text = "";
            yield return new WaitForSeconds(0.3f);
        }
    }

    /// <summary>
    /// Set Reloading bar color
    /// </summary>
    public void SetReloadingBarColor(Color color)
    {
        barImage.color = color;
    }

    #region Validation
#if UNITY_EDITOR

    private void OnValidate()
    {
        HelperUtilities.ValidateCheckNullValue(this, nameof(weaponImage), weaponImage);
        HelperUtilities.ValidateCheckNullValue(this, nameof(ammoHolderTransform), ammoHolderTransform);
        HelperUtilities.ValidateCheckNullValue(this, nameof(reloadText), reloadText);
        HelperUtilities.ValidateCheckNullValue(this, nameof(ammoRemainingText), ammoRemainingText);
        HelperUtilities.ValidateCheckNullValue(this, nameof(weaponNameText), weaponNameText);
        HelperUtilities.ValidateCheckNullValue(this, nameof(reloadBar), reloadBar);
        HelperUtilities.ValidateCheckNullValue(this, nameof(barImage), barImage);
    }

#endif
    #endregion Validation
}
