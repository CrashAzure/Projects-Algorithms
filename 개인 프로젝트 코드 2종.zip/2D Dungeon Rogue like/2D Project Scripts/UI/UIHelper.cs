using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Remoting.Messaging;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UIHelper : MonoBehaviour
{
    [HideInInspector]
    public SoundEffectManager soundEffectManager;
    [HideInInspector]
    public AspectRatioFitter aspectRatioFitter;
    private CanvasGroup canvasGroup;
    private CharacterSelectorUI characterSelectorUI;
    private MainMenuUI mainMenuUI;
    [HideInInspector] public Flash flashUI;

    #region Header
    [Header("Fade Image")]
    #endregion Header
    #region Tooltip
    [Tooltip("Populate image for fade in and out")]
    #endregion
    [SerializeField] private Image image;
    private TextMeshProUGUI textMeshPro;
    
    private Coroutine fadeCoroutine;
    private Coroutine writeCoroutine;
    private Coroutine playCoroutine;

    [Space(10)]
    #region Header
    [Header("Wall List")]
    #endregion Header
    #region Tooltip
    [Tooltip("Populate wall sprites for select effect")]
    #endregion
    [SerializeField] private List<Sprite> wallList = new List<Sprite>();

    private List<RaycastResult> rayList = new List<RaycastResult>();
    private int prevRayCount = 0;
    private RaycastResult prevRay = new RaycastResult();
    private RaycastResult selectorRay = new RaycastResult();

    private void Awake()
    {
        // Get Components
        canvasGroup = GetComponent<CanvasGroup>();
        aspectRatioFitter = GetComponentInChildren<AspectRatioFitter>();
        textMeshPro = GetComponentInChildren<TextMeshProUGUI>();
        flashUI = FindObjectOfType<Flash>();
        soundEffectManager = FindObjectOfType<SoundEffectManager>();

        // Initialise fade UI Components
        InitialiseFadeUI();
    }

    void Start()
    {
        // start fade coroutine
        FadeLoading(1f, 0f, 3.0f, 2.0f, Color.black);
    }

    private void Update()
    {
        if (canvasGroup.alpha > 0.5f) return;
        if (playCoroutine != null) return;
        if (EventSystem.current == null) return;

        CheckCharacterSelectorUI();

        if (characterSelectorUI == null) return;

        PointerEventData pointer = new PointerEventData(EventSystem.current);

        SetEventdata(ref pointer);

        if (rayList.Count == 0) return;

        CheckStateRayForUI(pointer);
    }

    /// <summary>
    /// is there CharacterSelectorUI?
    /// </summary>
    private void CheckCharacterSelectorUI()
    {
        if (characterSelectorUI == null)
        {
            characterSelectorUI = FindObjectOfType<CharacterSelectorUI>();
        }

        if (FindObjectOfType<CharacterSelectorUI>() == null)
        {
            characterSelectorUI = null;
        }
    }

    /// <summary>
    /// Set event data's values
    /// </summary>
    private void SetEventdata(ref PointerEventData eventData)
    {
        eventData.position = Input.mousePosition;

        if (Input.GetMouseButton(0))
        {
            eventData.clickCount = 1;
        }
        else
        {
            eventData.clickCount = 0;
        }

        EventSystem.current.RaycastAll(eventData, rayList);
    }

    /// <summary>
    /// Checck ray condition for ui
    /// </summary>
    private void CheckStateRayForUI(PointerEventData eventData)
    {
        CheckRaycastResult();

        CheckEnterAndExit(eventData);

        CheckClickAndFocus(eventData);
    }

    /// <summary>
    /// Check click or focus status
    /// </summary>
    private void CheckClickAndFocus(PointerEventData eventData)
    {
        if (!IsCharacterSelector(selectorRay)) return;

        if (rayList.Count == 0) return;

        if (eventData.clickCount > 0)
        {
            OnPointerClick(eventData);
        }

        //if (prevRayCount == rayList.Count)
        //{
        //    OnFocusUI();
        //}

    }

    private void CheckEnterAndExit(PointerEventData eventData)
    {
        if (prevRayCount == rayList.Count) return;
        if (characterSelectorUI == null) return;

        if (prevRayCount > rayList.Count)
        {
            OnPointerExit(eventData);
        }

        if (rayList.Count > prevRayCount)
        {
            prevRay = selectorRay;
            OnPointerEnter(eventData);
        }

        prevRayCount = rayList.Count;
    }

    /// <summary>
    /// When mouse pointer enter something of UI, call this
    /// </summary>
    public void OnPointerEnter(PointerEventData eventData)
    {
        if(!IsCharacterSelector(selectorRay)) return;

        // Check selector ray index
        int index = GetIndexForSelector(selectorRay);
        
        // Get sprite array at selector rist
        SpriteRenderer[] spriteArray = characterSelectorUI.characterSelectorList[index].GetComponentsInChildren<SpriteRenderer>();

        // Loop through sprite array
        foreach (SpriteRenderer sprite in spriteArray)
        {
            // Set color to gray
            sprite.color = new Color(0.4f, 0.4f, 0.4f, sprite.color.a);
        }
    }

    /// <summary>
    /// When mouse pointer exit something of UI, call this
    /// </summary>
    public void OnPointerExit(PointerEventData eventData)
    {
        if (!IsCharacterSelector(prevRay)) return;

        // Check prev ray index
        int index = GetIndexForSelector(prevRay);

        // Get sprite array at selector rist
        SpriteRenderer[] spriteArray = characterSelectorUI.characterSelectorList[index].GetComponentsInChildren<SpriteRenderer>();

        // Loop through sprite array
        foreach (SpriteRenderer sprite in spriteArray)
        {
            // Set color to normal color
            sprite.color = new Color(1f, 1f, 1f, sprite.color.a);
        }
    }

    /// <summary>
    /// When mouse click something of UI, call this
    /// </summary>
    public void OnPointerClick(PointerEventData eventData)
    {
        if (characterSelectorUI == null || !IsCharacterSelector(selectorRay)) return;
        

        // Set parameters for click
        flashUI.ProcessFlashCoroutine(0.2f);
        mainMenuUI = FindObjectOfType<MainMenuUI>();
        int index = GetIndexForSelector(selectorRay);

        // Set active mask for wall animation
        FindObjectOfType<Mask>(true).gameObject.SetActive(true);

        // Get rigidbody2D array
        Rigidbody2D[] rigidbody2DArray = FindObjectsOfType<Rigidbody2D>();

        // Loop through rigidbody 2d array
        foreach (Rigidbody2D rigidbody in rigidbody2DArray)
        {
            if (rigidbody.gameObject.name == "Wall" + (index + 1).ToString()) continue;
            if (rigidbody.gameObject.name == "Collider") continue;

            rigidbody.GetComponent<Image>().sprite = wallList[index];
            rigidbody.gravityScale = 30f;
        }

        playCoroutine = StartCoroutine(ProcessPlayGame(2f, index));
    }

    /// <summary>
    /// Check ray cast result
    /// </summary>
    private void CheckRaycastResult()
    {
        // Loop through ray list for check selector ray
        foreach(RaycastResult raycast in rayList)
        {
            if (IsCharacterSelector(raycast))
            {
                selectorRay = raycast;
                return;
            }
        }
        selectorRay = new RaycastResult();
    }

    private IEnumerator ProcessPlayGame(float delayTime, int index)
    {
        yield return new WaitForSeconds(delayTime);

        characterSelectorUI?.SetCurrentPlayer(index);
        mainMenuUI?.PlayGame();
    }

    /// <summary>
    /// When mouse position is on something of UI, call this
    /// </summary>
    public void OnFocusUI()
    {
        if (characterSelectorUI != null && IsCharacterSelector(rayList[0]))
        {
            int index = GetIndexForSelector(rayList[0]);

            SpriteRenderer[] spriteArray = characterSelectorUI.characterSelectorList[index].GetComponentsInChildren<SpriteRenderer>();

            foreach (SpriteRenderer sprite in spriteArray)
            {
                sprite.color = new Color(0.4f, 0.4f, 0.4f, sprite.color.a);
            }
        }
    }

    /// <summary>
    /// if its Charactor seletor button, then return true;
    /// </summary>
    private bool IsCharacterSelector(RaycastResult raycast)
    {
        if(raycast.isValid)
        {
            return ((raycast.gameObject.name == "ButtonForSelector1"
                  || raycast.gameObject.name == "ButtonForSelector2"
                  || raycast.gameObject.name == "ButtonForSelector3"
                  || raycast.gameObject.name == "ButtonForSelector4"));
        }

        return false;
        
    }

    /// <summary>
    /// Get index for selector UI
    /// </summary>
    private int GetIndexForSelector(RaycastResult raycast)
    {
        if(raycast.gameObject.name == "ButtonForSelector1")
        {
            return 0;
        }
        if (raycast.gameObject.name == "ButtonForSelector2")
        {
            return 1;
        }
        if (raycast.gameObject.name == "ButtonForSelector3")
        {
            return 2;
        }
        if (raycast.gameObject.name == "ButtonForSelector4")
        {
            return 3;
        }

        return 100;
    }


    /// <summary>
    /// Initialise fade UI
    /// </summary>
    public void InitialiseFadeUI()
    {
        if (!gameObject.activeSelf)
        {
            gameObject.SetActive(true);
        }

        if (!aspectRatioFitter.gameObject.activeSelf)
        {
            aspectRatioFitter.gameObject.SetActive(true);
        }

        canvasGroup.alpha = 1f;
        image.color = Color.black;
    }

    /// <summary>
    /// Set text in fade ui
    /// </summary>
    public void SetTextFadeUI(string inputText)
    {
        textMeshPro.text = inputText;
    }

    /// <summary>
    /// Start Fade coroutine
    /// </summary>
    public void FadeLoading(float startFadeAlpha, float targetFadeAlpha, float delaySeconds, float fadeSeconds, Color backgroundColor)
    {
        // Clear coroutines
        InitialiseCoroutine();

        if (!aspectRatioFitter.gameObject.activeSelf)
        {
            aspectRatioFitter.gameObject.SetActive(true);
        }

        fadeCoroutine = StartCoroutine(FadeLoadingCoroutine(startFadeAlpha, targetFadeAlpha, delaySeconds, fadeSeconds, backgroundColor));
        writeCoroutine = StartCoroutine(WriteTextCoroutine(delaySeconds + fadeSeconds, textMeshPro.text, result => textMeshPro.text = result, 3));
    }


    /// <summary>
    /// Fade coroutine with fade UI's canvasGroup alpha value
    /// </summary>
    private IEnumerator FadeLoadingCoroutine(float startFadeAlpha, float targetFadeAlpha, float delaySeconds, float fadeSeconds, Color backgroundColor)
    {
        yield return new WaitForSeconds(delaySeconds);

        float time = 0;
                
        image.color = backgroundColor;

        while (time <= fadeSeconds)
        {
            time += Time.deltaTime;
            
            canvasGroup.alpha = Mathf.Lerp(startFadeAlpha, targetFadeAlpha, time / fadeSeconds);

            yield return null;
        }

        aspectRatioFitter.gameObject.SetActive(false);
    }

    /// <summary>
    /// Write text coroutine
    /// </summary>
    public IEnumerator WriteTextCoroutine(float processTime, string fullText, Action<string> targetText, int targetIndex, float delayTime = 0f, bool isRepeat = true)
    {
        // delay this coroutine if delaytime is not zero
        if(delayTime != 0f)
        {
            yield return new WaitForSeconds(delayTime);
        }

        float writeTimer = 0;
        int writeIndex = targetIndex;
        float time = 0;

        // Return here for process time
        while(time <= processTime)
        {
            time += Time.deltaTime;
            writeTimer += Time.deltaTime;

            WriteText(targetIndex, processTime, fullText, targetText, ref writeTimer, ref writeIndex, isRepeat);

            yield return null;
        }
    }

    /// <summary>
    /// Write Text once a cycle
    /// </summary>
    private void WriteText(int targetIndex, float processTime, string fullText, Action<string> targetText, ref float writeTimer, ref int writeIndex, bool isRepeat = true)
    {
        float writingSpeed = 0.2f;

        // Fit writing speed using process time and text length
        if (!isRepeat)
        {
            writingSpeed = processTime / fullText.Length;
            writingSpeed *= 0.7f;
        }

        // Check cycle with caculated writing speed
        if (writeTimer <= writingSpeed) return;

        // Only one process if we dont wanna repeat this
        // else keep going
        if (writeIndex < 0)
        {
            if (!isRepeat) return;

            writeIndex = targetIndex;
        }

        // Set result value of one coroutine cycle to delegate
        targetText(fullText.Substring(0, fullText.Length - writeIndex));

        if(!isRepeat)
        {
            soundEffectManager.PlaySoundEffect(GameResources.Instance.typingSound);
        }
        

        // Initialise timer
        writeTimer = 0;
        // Update index
        writeIndex--;

    }

    /// <summary>
    /// if there is fade coroutine, stop fade coroutine
    /// </summary>
    private void InitialiseCoroutine()
    {
        if (fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
        }

        if (writeCoroutine != null)
        {
            StopCoroutine(writeCoroutine);
        }
    }
}
