using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundEffects : MonoBehaviour
{
    [SerializeField]
    private AudioClip rainningSound;
    [SerializeField]
    private AudioClip windStormSound;
    [HideInInspector]
    public SetAudio audioEffect;
    [SerializeField]
    private AudioSource backgroundMusic;
    private void Update()
    {
        if (audioEffect != null && audioEffect.gameObject.activeSelf)
        {
            audioEffect.transform.position = GameController.Instance.mainCameraController.transform.position;
        }
    }

    public void SetAudio(EffectType type)
    {
        GameObject soundPrefab = Resources.Load<GameObject>("Audio");
        audioEffect = (SetAudio)PoolManager.Instance.ReuseComponent(soundPrefab,
                                                              GameController.Instance.mainCameraController.transform.position
                                                              + GameController.Instance.mainCameraController.transform.forward * 0.1f,
                                                              Quaternion.identity);

        //if(type== EffectType.Rain)
        //{
        //    audioEffect.SetAudioSource(rainningSound);
        //    StartCoroutine(HelperUtilities.LerpCoroutine(0f, 0.3f, 5f, a => audioEffect.SetVolume(a)));
        //    audioEffect.SetPitch(0.8f);
        //}
        //else if(type == EffectType.Freezing)
        //{
        //    audioEffect.SetAudioSource(windStormSound);
        //    audioEffect.SetVolume(1f);
        //    audioEffect.SetPitch(1f);
        //}
        //audioEffect.InitMixer();
        //audioEffect.SetLoop(true);
        //audioEffect.gameObject.SetActive(true);
        //audioEffect.Play(true);

        if (type == EffectType.Rain)
        {
            backgroundMusic.clip = rainningSound;
            StartCoroutine(HelperUtilities.LerpCoroutine(0f, 0.6f, 5f, a => backgroundMusic.volume = a));
            backgroundMusic.pitch = 0.8f;
        }
        else if (type == EffectType.Blizzard)
        {
            backgroundMusic.volume = 1f;
            backgroundMusic.clip = windStormSound;
            backgroundMusic.pitch = 1f;
        }

        backgroundMusic.Play();
    }

    public void DisableAudio()
    {
        backgroundMusic.Stop();
        //if (audioEffect == null) return;
        //audioEffect.SetLoop(false);
        //audioEffect.ReturnMixer();
        //audioEffect.InitAudioSource();
        //audioEffect.gameObject.SetActive(false);
        //audioEffect = null;
    }
}
