using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RigContainer : Container
{
    public RigType rigtype;

    public override void Awake()
    {
        base.Awake();

        UpdateContainerDetail();
    }

    public override void Start()
    {
        base.Start();
        SetGridNodeList();
    }

    public override void UpdateContainerDetail()
    {
        string containerName = "";

        switch (rigtype)
        {
            case RigType.smallRig:
                containerName = "SR";
                break;
            case RigType.mediumRig:
                containerName = "MR";
                break;
            case RigType.largeRig:
                containerName = "LR";
                break;
        }

        FindContainerDetailOnList(containerName);
    }
}
