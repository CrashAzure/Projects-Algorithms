using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmorSlot : Container
{
    public override void Awake()
    {
        containerDetailList.AddRange(Resources.LoadAll<ContainerSO>("Containers"));

        if (transform.childCount != 0)
        {
            itemList.Add(GetComponentInChildren<Item>(true));
        }
    }

    public override void Start()
    {
        SetParentInventory();
    }
}
