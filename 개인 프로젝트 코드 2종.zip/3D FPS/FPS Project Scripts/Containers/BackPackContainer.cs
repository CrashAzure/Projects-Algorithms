using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackPackContainer : Container
{
    public BackPackType backpacktype;

    public override void Awake()
    {
        base.Awake();

        UpdateContainerDetail();
    }

    public override void Start()
    {
        base.Start();
        SetGridNodeList();
    }

    public override void UpdateContainerDetail()
    {
        if (backpacktype == BackPackType.None) return;
        string containerName = "";

        switch (backpacktype)
        {
            case BackPackType.smallBackPack:
                containerName = "SBP";
                break;
            case BackPackType.mediumBackPack:
                containerName = "MBP";
                break;
            case BackPackType.largeBackPack:
                containerName = "LBP";
                break;
        }

        FindContainerDetailOnList(containerName);
    }
}