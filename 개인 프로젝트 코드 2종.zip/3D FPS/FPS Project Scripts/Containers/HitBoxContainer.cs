using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitBoxContainer : MonoBehaviour
{
    [HideInInspector]
    public List<HitToBox> hitBoxList = new List<HitToBox>();

    private void Awake()
    {
        hitBoxList.AddRange(GetComponentsInChildren<HitToBox>());
    }
}
