using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public enum StashType
{
    None,
    Small,
    Medium,
    Large
}
public class Stash : Container
{
    public StashType stashType;
    private Item item;
    public override void Awake()
    {
        base.Awake();

        UpdateContainerDetail();

        item = GetComponent<Item>();
    }

    private void Update()
    {
        if (item.itemUIIcon.gameObject.activeSelf)
        {
            item.itemUIIcon.gameObject.SetActive(false);
        }
    }

    public override void Start()
    {
        if (gridList.Count > 0) return;
        base.Start();
        SetGridNodeList();
    }

    public override void Init()
    {
        base.Init();
        UpdateContainerDetail();
        SetGridNodeList();
        
    }

    public override void UpdateContainerDetail()
    {
        string containerName = "";

        switch (stashType)
        {
            case StashType.Small:
                containerName = "SS";
                break;
            case StashType.Medium:
                containerName = "MS";
                break;
            case StashType.Large:
                containerName = "LS";
                break;
        }

        FindContainerDetailOnList(containerName);
    }
}
