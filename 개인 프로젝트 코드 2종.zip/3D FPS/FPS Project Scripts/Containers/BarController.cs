using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;

public class BarController : MonoBehaviour, 
                            IBeginDragHandler,
                          IDragHandler

{
    private RectTransform parentRect;
    private RectTransform rect;
    private Vector2 gapWithCursor = Vector2.zero;
    private void Awake()
    {
        parentRect = transform.parent.GetComponent<RectTransform>();
        rect = GetComponent<RectTransform>();
    }

    private void Update()
    {
        if (parentRect.sizeDelta.x != rect.sizeDelta.x)
        {
            rect.sizeDelta = new Vector2(parentRect.sizeDelta.x, rect.sizeDelta.y);
        }
    }
    public void OnBeginDrag(PointerEventData eventData)
    {
        transform.parent.SetAsLastSibling();
        gapWithCursor = eventData.position - new Vector2(transform.parent.position.x, transform.parent.position.y);
    }

    public void OnDrag(PointerEventData eventData)
    {
        transform.parent.position = new Vector3(eventData.position.x, eventData.position.y, transform.position.z) - new Vector3(gapWithCursor.x, gapWithCursor.y, 0f);
    }

    
}
