using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using UnityEngine;


public class Container : MonoBehaviour
{
    #region Parameters
    [HideInInspector]
    public ContainerSO currentContainerDetail = null;
    [HideInInspector]
    public Inventory parentInventory;
    public List<Item> itemList = new List<Item>();
    [HideInInspector]
    public List<GridNode> gridList = new List<GridNode>();
    public List<ContainerSO> containerDetailList = new List<ContainerSO>();

    public bool isEquieped = false;
    public bool isDone = false;
    public ContainerType type;
    #endregion Parameters

    #region Unity
    public virtual void Awake()
    {
        if(containerDetailList.Count == 0)
        {
            containerDetailList.AddRange(Resources.LoadAll<ContainerSO>("Containers"));
        }
    }

    public virtual void Start()
    {
        SetParentInventory();
    }
    #endregion Unity

    #region Methods
    public void SetGridNodeList()
    {
        if (type == ContainerType.None) return;

        gridList.Clear();

        List<Vector2Int> sizeList = currentContainerDetail.gridSizeList;

        for (int i = 0; i < sizeList.Count; i++)
        {
            GridNode gridPrefab = Resources.Load<GridNode>("GridNode");
            //GridNode grid = (GridNode)PoolManager.Instance.ReuseComponent(gridPrefab.gameObject, Vector3.zero, Quaternion.identity);
            GridNode grid = Instantiate(gridPrefab);

            grid.container = this;

            grid.SetGridNodeInfo(sizeList[i]);
            gridList.Add(grid);
        }
    }

    public void SetParentInventory()
    {
        Inventory inventory = GetComponentInParent<Inventory>();
        parentInventory = inventory;
    }

    public (bool, Vector2Int, GridNode) ProcessCheckInventory(Item item)
    {
        foreach(var grid in gridList)
        {
            (bool, Vector2Int) result = grid.CheckGridNode(item);

            if(result.Item1)
            {
                return (result.Item1,result.Item2, grid);
            }
        }

        return (false, Vector2Int.zero, null);
    }

    public void ThrowOutItem(int index, Character character)
    {
        Transform targetTransform = character.headTransform;
        itemList[index].transform.SetParent(null);
        itemList[index].transform.position = targetTransform.position;

        if(itemList[index].rigidBody != null)
        {
            itemList[index].rigidBody.useGravity = true;
            itemList[index].rigidBody.velocity += new Vector3(targetTransform.forward.x, 0f, targetTransform.forward.z);
        }

        ItemUIIcon icon = itemList[index].itemUIIcon;
        
        if(icon.transform.parent.GetComponent<ArmorSlotUI>() == null)
        {
            icon.SetGridItemArray(0);
        }
        icon.isRotate = false;
        icon.transform.SetParent(itemList[index].transform);
        icon.gameObject.SetActive(false);
        icon.index = 0;
        itemList[index].gameObject.SetActive(true);
        itemList[index].transform.SetParent(null);

        icon.transform.localScale = Vector3.one;
        icon.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;

        itemList.RemoveAt(index);

        UpdateItemIndex();
    }

    public void UpdateItemIndex()
    {
        itemList.Clear();

        if (transform.childCount == 0) return;
        for(int i = 0; i < transform.childCount; i++)
        {
            if(transform.GetChild(i).GetComponent<Item>() != null)
            {
                itemList.Add(transform.GetChild(i).GetComponent<Item>());
            }
        }

        if (itemList.Count == 0) return;
        

        for(int i = 0; i < itemList.Count; i++)
        {
            itemList[i].itemUIIcon.index = i + 1;
            if (this as WeaponSlot == null
                && this as HelmetSlot == null
                && this as ArmorSlot == null)
            {
                itemList[i].itemUIIcon.SetGridItemArray(i + 1);
            }
        }
    }

    public virtual void UpdateContainerDetail()
    {
        
    }

    public void FindContainerDetailOnList(string containerName)
    {
        foreach (var containerDetail in containerDetailList)
        {
            if (containerDetail.containerName == containerName)
            {
                currentContainerDetail = containerDetail;
            }
        }
    }

    public void PutItem(Item item)
    {
        itemList.Add(item);
        item.transform.SetParent(transform, false);
        if(item.rigidBody != null)
            item.rigidBody.useGravity = false;
    }

    public virtual void Init()
    {
        if (containerDetailList.Count == 0)
        {
            containerDetailList.AddRange(Resources.LoadAll<ContainerSO>("Containers"));
        }

        SetParentInventory();
    }

    public void InitContainer(Character character)
    {
        int index = itemList.Count - 1;
        while(index >= 0)
        {
            ThrowOutItem(index, character);
            index--;
        }
    }
    #endregion Methods

}
