using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    #region Parameters
    [Space(10)]

    [HideInInspector]
    public WeaponController currentWeapon;

    [HideInInspector]
    public WeaponSlot[] slots;

    [HideInInspector]
    public ArmorSlot armorSlot;
    [HideInInspector]
    public HelmetSlot helmetSlot;
    [HideInInspector]
    public Container rigContainer;
    [HideInInspector]
    public Container backpackContainer;
    [HideInInspector]
    public Container pocketContainer;

    [HideInInspector]
    public Transform containers;

    public Transform backpackLocationTransform;
    public Transform rigLocationTransform;
    #endregion Parameters

    #region Unity

    private void Awake()
    {
        //InitializeTotalWeaponList();
        //// Initialize current weapon list
        //currentWeaponList = new bool[totalWeaponList.Count];
        //// Default weapon
        //currentWeaponList[currentWeaponIndex1] = true;
        //EnableWeapon(1);
        slots = GetComponentsInChildren<WeaponSlot>();
        armorSlot = GetComponentInChildren<ArmorSlot>();
        helmetSlot = GetComponentInChildren<HelmetSlot>();
        EnableWeapon();
        containers = transform.Find("Containers");
    }
    private void Start()
    {
        // Set Containers at first time
        SetContainers();
    }
    #endregion Unity

    #region Method

    /// <summary>
    /// Whenever I change containers, I will set containers with this method
    /// </summary>
    public void SetContainers()
    {
        rigContainer = null;
        backpackContainer = null;
        pocketContainer = null;

        Container[] containerArray = GetComponentsInChildren<Container>();
        List<Container> list = new List<Container>();

        if(containers.transform.childCount != 0)
        {
            for(int i = 0; i< containers.transform.childCount; i++)
            {
                list.Add(containers.transform.GetChild(i).GetComponent<Container>());
            }
        }
        else
        {
            return;
        }
        
        foreach(var container in list)
        {
            if(container.type == ContainerType.Rig)
            {
                rigContainer = container;
            }
            else if(container.type == ContainerType.BackPack)
            {
                backpackContainer = container;
            }
            else if(container.type == ContainerType.Pocket)
            {
                pocketContainer = container;
            }
        }
    }

    public void CheckSlots(WeaponSlotType type, Item item)
    {
        WeaponSlotType additional = WeaponSlotType.None;

        if(type == WeaponSlotType.Weapon1)
        {
            additional = WeaponSlotType.Weapon2;
        }
        if(type == WeaponSlotType.Weapon2)
        {
            additional = WeaponSlotType.Weapon1;
        }

        foreach (var slot in slots) 
        {
            if(slot.weaponSlotType == type || slot.weaponSlotType == additional)
            {
                if(slot.itemList.Count == 0)
                {
                    slot.PutItem(item);
                    item.itemUIIcon.rect.anchoredPosition = -item.itemUIIcon.icon.rectTransform.anchoredPosition;
                    item.gameObject.SetActive(false);
                    item.GetComponent<WeaponStatus>().SetWeaponStatus(true);
                    item.GetComponent<WeaponController>().SetDirty();
                    return;
                }
            }
        }
    }

    public bool EquipContainer(Item item)
    {
        Container container = item.GetComponentInParent<Container>();

        if(container == null)
        {
            container = item.GetComponent<Container>();
        }

        if (container.type == ContainerType.Rig)
        {
            if (rigContainer == null)
            {
                rigContainer = container;
                EquipContiner(container);
                return true;
            }
        }
        else if (container.type == ContainerType.BackPack)
        {
            if (backpackContainer == null)
            {
                backpackContainer = container;
                EquipContiner(container);
                return true;
            }
        }
        return false;
    }

    public bool EquipArmors(Item item)
    {
        Helmet helmet = item as Helmet;
        Armor armor = item as Armor;

        if(helmet != null)
        {
            if (helmetSlot.itemList.Count == 0)
            {
                EquipItem(helmet, helmetSlot);
                return true;
            }
        }

        if(armor != null)
        {
            if (armorSlot.itemList.Count == 0)
            {
                EquipItem(armor, armorSlot);
                return true;
            }
        }
        
        return false;
    }

    public bool CheckContainerCanEquip(Item item)
    {
        Container container = item.GetComponent<Container>();

        if (container.type == ContainerType.Rig)
        {
            if (rigContainer == null) return true;

        }
        else if (container.type == ContainerType.BackPack)
        {
            if (backpackContainer == null) return true;
        }
        return false;
    }

    private void EquipContiner(Container container)
    {
        container.isEquieped = true;

        foreach (var obj in container.GetComponentsInChildren<Transform>())
        {
            if(obj.GetComponent<ItemUIIcon>() == null)
            {
                obj.gameObject.layer = LayerMask.NameToLayer("Invisible");
            }
        }
        container.transform.SetParent(containers, false);
        container.GetComponent<Rigidbody>().isKinematic = true;
    }

    private void EquipItem(Item item, Container targetContainer)
    {
        foreach (var obj in item.GetComponentsInChildren<Transform>())
        {
            if (obj.GetComponent<ItemUIIcon>() == null)
            {
                obj.gameObject.layer = LayerMask.NameToLayer("Invisible");
            }
        }
        item.transform.SetParent(targetContainer.transform, false);
        
        targetContainer.UpdateItemIndex();
        item.GetComponent<Rigidbody>().isKinematic = true;
        item.itemUIIcon.rect.localRotation = Quaternion.identity;
        item.itemUIIcon.transform.position -= Vector3.forward * item.itemUIIcon.transform.position.z;
    }


    /// <summary>
    /// Enable weapon
    /// </summary>
    public void EnableWeapon()
    {
        #region UnUsed
        //int num = 0;

        //foreach(var weapon in totalWeaponList)
        //{
        //    if (!weapon.gameObject.activeSelf) continue;
        //    weapon.gameObject.SetActive(false);
        //    weapon.transform.position = Vector3.zero;
        //}

        //switch (index)
        //{
        //    case 0:
        //        num = currentWeaponIndex0;
        //        break;
        //    case 1:
        //        num = currentWeaponIndex1;
        //        break;
        //    case 2:
        //        num = currentWeaponIndex2;
        //        break;
        //}

        //if (currentWeaponIndex0 != -1 && currentWeaponList[currentWeaponIndex0])
        //{
        //    totalWeaponList[currentWeaponIndex0].gameObject.SetActive(true);
        //    SetCam(currentWeaponIndex0);
        //     totalWeaponList[currentWeaponIndex0].localPosition = Vector3.down * 1000f;
        //}


        //if (currentWeaponIndex1 != -1 && currentWeaponList[currentWeaponIndex1])
        //{
        //    totalWeaponList[currentWeaponIndex1].gameObject.SetActive(true);
        //    SetCam(currentWeaponIndex1);
        //    totalWeaponList[currentWeaponIndex1].localPosition = Vector3.down * 1000f;
        //}

        //if (currentWeaponIndex2 != -1 && currentWeaponList[currentWeaponIndex2])
        //{
        //    totalWeaponList[currentWeaponIndex2].gameObject.SetActive(true);
        //    SetCam(currentWeaponIndex2);
        //    totalWeaponList[currentWeaponIndex2].localPosition = Vector3.down * 1000f;
        //}
        ////totalWeaponList[num].gameObject.SetActive(true);
        //SetCam(num, true);
        //totalWeaponList[num].localPosition = Vector3.zero;
        #endregion

        EnableWeaponAtStart();

        foreach (WeaponSlot slot in slots)
        {
            slot.GetComponentInChildren<WeaponController>()?.gameObject.SetActive(false);
        }

        if(currentWeapon != null)
        {
            currentWeapon.gameObject.SetActive(true);
        }
    }

    private void EnableWeaponAtStart()
    {
        if (currentWeapon != null) return;

        WeaponSlot tempSlot = null;

        foreach (WeaponSlot slot in slots)
        {
            WeaponController tempWeapon = slot.GetComponentInChildren<WeaponController>(true);
            if (tempWeapon == null) continue;

            if (tempSlot == null || tempSlot.weaponSlotType >= slot.weaponSlotType)
            {
                tempSlot = slot;
                currentWeapon = tempWeapon;
            }
        }
    }

    public void PutItemOnContainer(GridNode grid, Vector2Int anchor, Item item, Container container)
    {
        container.PutItem(item);
        item.itemUIIcon.gameObject.SetActive(true);
        item.itemUIIcon.SetSize(item.GetSize().x, item.GetSize().y);
        item.itemUIIcon.SetPosFromOutSideOfUI(anchor);
        item.container = container;
        item.itemUIIcon.container = container;
        item.itemUIIcon.index = container.itemList.Count;
        grid.SetGridForItem(anchor, item, container.itemList.Count);
        item.gameObject.SetActive(false);
        item.itemUIIcon.transform.localScale = Vector3.one;
    }

    public void ResetInventory(Character character = null)
    {
        if(character == null)
        {
            character = GameController.Instance.player;
        }

        UIManager.Instance.inventoryUI.gameObject.SetActive(false);

        foreach(var slot in slots)
        {
            slot.InitContainer(character);
        }

        armorSlot.InitContainer(character);
        helmetSlot.InitContainer(character);

        if(backpackContainer!= null)
        {
            ThrowOutEquipedContainer(backpackContainer);
            backpackContainer = null;
        }

        if (rigContainer != null)
        {
            ThrowOutEquipedContainer(rigContainer);
            rigContainer = null;
        }

        if (pocketContainer != null)
        {
            pocketContainer.InitContainer(character);
        }

        SetContainers();
    }

    private void ThrowOutEquipedContainer(Container targetContainer)
    {
        Rigidbody rigidbody = targetContainer.GetComponent<Rigidbody>();
        targetContainer.transform.SetParent(null, false);
        targetContainer.transform.position = Camera.main.transform.position + Camera.main.transform.forward;
        targetContainer.isEquieped = false;
        rigidbody.velocity = Camera.main.transform.forward;
        rigidbody.isKinematic = false;
        Item containerItem = targetContainer.GetComponent<Item>();
        containerItem.itemUIIcon.InitIcon();
    }

    #endregion Method
}
