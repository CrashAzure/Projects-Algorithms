using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModeChangeSound : MonoBehaviour
{
    [SerializeField]
    private AudioClip changingSound;

    public void ModeChange()
    {
        GameObject audioPrefab = Resources.Load<GameObject>("Audio");
        SetAudio audio = (SetAudio)PoolManager.Instance.ReuseComponent(audioPrefab, transform.position, Quaternion.identity);

        audio.SetAudioSource(changingSound);
        audio.SetVolume(1f);
        audio.SetPitch(0.7f);
        audio.gameObject.SetActive(true);
        audio.Play();
    }
}
