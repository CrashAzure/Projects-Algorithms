using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Helmet : Item
{
    [Range(1, 3)]
    public int level = 1;
    public float maxDurability = 0f;
    public float currentDurability = 0f;

    public override void Awake()
    {
        base.Awake();

        currentDurability = maxDurability;
        itemType = ItemType.Helmet;
    }

}
