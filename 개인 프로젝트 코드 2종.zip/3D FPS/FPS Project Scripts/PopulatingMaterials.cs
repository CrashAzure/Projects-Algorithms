using cakeslice;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Unused, its too heavy
/// </summary>
public class PopulatingMaterials : MonoBehaviour
{
    [HideInInspector]
    public MeshRenderer[] meshRenderers;
    [HideInInspector]
    public MeshRenderer meshRenderer;
    [HideInInspector]
    public MeshFilter meshFilter;
    [HideInInspector]
    public MeshCollider meshCollider;
    [HideInInspector]
    public Outline outline;
    void Awake()
    {
        meshRenderers = GetComponentsInChildren<MeshRenderer>();
        meshFilter = GetComponent<MeshFilter>();
        meshCollider = GetComponent<MeshCollider>();
        Material[] materials = new Material[meshRenderers.Length];

        for(int j = 0; j< meshRenderers.Length; j++)
        {
            materials[j] = meshRenderers[j].material;
        }

        MeshFilter[] meshFilters = GetComponentsInChildren<MeshFilter>();
        CombineInstance[] combine = new CombineInstance[meshFilters.Length];

        int i = 0;
        while (i < meshFilters.Length)
        {
            if (meshFilters[i] == meshFilter) 
            {
                i++;
                continue;
            }
            combine[i].mesh = meshFilters[i].sharedMesh;
            combine[i].transform = meshFilters[i].transform.localToWorldMatrix;
            meshFilters[i].gameObject.SetActive(false);

            i++;
        }
        meshFilter.mesh = new Mesh();
        meshFilter.mesh.CombineMeshes(combine);
        transform.gameObject.SetActive(true);
        meshRenderer = gameObject.AddComponent<MeshRenderer>();
        outline = gameObject.AddComponent<Outline>();
        meshRenderer.sharedMaterials = materials;
        meshCollider.sharedMesh = meshFilter.mesh;
    }

}
