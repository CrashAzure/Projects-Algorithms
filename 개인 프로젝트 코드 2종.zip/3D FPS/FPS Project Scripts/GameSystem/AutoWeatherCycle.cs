using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoWeatherCycle : MonoBehaviour
{
    private ShaderEffects effect;
    private float timer = 0f;
    [SerializeField]
    private float cycleTime = 15f;

    private void Start()
    {
        effect = GameController.Instance.player.GetComponentInChildren<ShaderEffects>();
    }

    private void Update()
    {
        timer += Time.deltaTime;

        if(timer > cycleTime)
        {
            if(effect.currentEffect < EffectType.Blizzard)
            {
                effect.currentEffect++;
            }
            else
            {
                effect.currentEffect = EffectType.None;
            }

            timer = 0f;
        }
    }

}
