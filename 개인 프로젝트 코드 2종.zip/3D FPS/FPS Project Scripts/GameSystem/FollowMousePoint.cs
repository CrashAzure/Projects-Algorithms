using UnityEngine;

public class FollowMousePoint : MonoBehaviour
{
    [SerializeField]
    private Camera mainCam;
    private void Awake()
    {
        Cursor.lockState = CursorLockMode.Confined;
    }
    private void Update()
    {
        //Vector3 targetPos = mainCam.ScreenToWorldPoint();
        //transform.LookAt(new Vector3(targetPos.x, targetPos.y, -1.5f));

        transform.localEulerAngles = new Vector3(Mathf.Lerp(40, 0, Input.mousePosition.y / Screen.height),
                                                 Mathf.Lerp(40, -40, Input.mousePosition.x / Screen.width),
                                                 0f);
        mainCam.transform.localEulerAngles = new Vector3(Mathf.Lerp(5, -5, Input.mousePosition.y / Screen.height),
                                                 Mathf.Lerp(-5, 5, Input.mousePosition.x / Screen.width),
                                                 0f);
    }
}
