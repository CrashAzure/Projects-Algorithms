using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneCheck : MonoBehaviour
{
    private void OnDestroy()
    {
        GameController.Instance.player.playerStatus.isInGame = false;
        GameController.Instance.player.GetComponentInChildren<ShaderEffects>().currentEffect = EffectType.None;
    }
}
