using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EscapingLocation : MonoBehaviour
{
    [SerializeField]
    private string locationName;
    [SerializeField]
    private float escapingTime = 10f;
    [Range(1, 3)]
    [SerializeField]
    private int sceneIndex = 1;
    private float escapingTimer = 10f;
    private bool isEscaping = false;

    private void Awake()
    {
        escapingTimer = escapingTime;
    }

    private void OnTriggerEnter(Collider other)
    {
        isEscaping = true;
        UIManager.Instance.escapingNameUI.text = locationName;
        UIManager.Instance.escapingNameUI.gameObject.SetActive(true);
        UIManager.Instance.escapingTimeUI.gameObject.SetActive(true);
    }
    private void OnTriggerExit(Collider other)
    {
        isEscaping = false;
        escapingTimer = escapingTime;

        UIManager.Instance.escapingNameUI.gameObject.SetActive(false);
        UIManager.Instance.escapingTimeUI.gameObject.SetActive(false);
    }

    private void Update()
    {
        if (isEscaping)
        {
            escapingTimer -= Time.deltaTime;



            UIManager.Instance.escapingTimeUI.text = $"{escapingTimer:N2}";

            if (escapingTimer < 0f)
            {
                ProcessEscape();
            }
        }
    }

    private void ProcessEscape()
    {
        UIManager.Instance.loadingUI.FadeLoading(0f, 1f, 0.1f, 0.1f, Color.black);
        UIManager.Instance.loadingUI.FadeLoading(1f, 0f, 0.2f, 0.1f, Color.black);
        UIManager.Instance.inventoryUI.gameObject.SetActive(false);
        SceneManager.UnloadSceneAsync(sceneIndex);
    }
}
