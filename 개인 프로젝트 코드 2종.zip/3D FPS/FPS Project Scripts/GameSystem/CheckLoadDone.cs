using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckLoadDone : MonoBehaviour
{
    Spawners[] spawners;
    
    void Awake()
    {
        spawners = FindObjectsOfType<Spawners>();
    }

    // Update is called once per frame
    void Update()
    {
        foreach(var spawner in spawners)
        {
            if (!spawner.isDoneToInstantiate) return;
        }

        UIManager.Instance.loadingUI.FadeLoading(1, 0, 2f, 1.5f, Color.black);
        enabled = false;
    }
}
