using System.Collections;
using UnityEngine;

public class Projectiles : MonoBehaviour
{
    #region Parameters

    [Range(1, 20)]
    [Tooltip("After how long time should the bullet prefab be disabled?")]
    public float disableAfter;

    [Tooltip("If enabled the bullet destroys on impact")]
    public bool destroyOnImpact = false;

    [Tooltip("Minimum time after impact that the bullet is disabled")]
    public float minDisableTime;

    [Tooltip("Maximum time after impact that the bullet is disabled")]
    public float maxDisableTime;

    [Tooltip("Total Damage")]
    public float damage;

    [Tooltip("Penetration Level")]
    public int penetrationlevel;

    [HideInInspector]
    public Transform startTransform;

    private Transform bloodImpactPrefabs;
    private Transform metalImpactPrefabs;
    private Transform dirtImpactPrefabs;
    private Transform concreteImpactPrefabs;

    [HideInInspector]
    public Rigidbody rigidBody;
    private GameController gameController;
    #endregion Parameters
    #region Unity
    private void Awake()
    {
        rigidBody = GetComponent<Rigidbody>();
        SetImpactTransforms();
    }

    private void Update()
    {
        transform.LookAt(transform.position + rigidBody.velocity.normalized);
    }

    private void OnEnable()
    {
        if (startTransform == null) return;

        //Collider[] colliders = startTransform.GetComponentsInChildren<Collider>();

        //foreach(var collider in colliders)
        //{
        //    if(collider.gameObject.layer == LayerMask.NameToLayer("Character"))
        //    {
        //        Physics.IgnoreCollision(collider, GetComponent<Collider>());
        //        break;
        //    }
        //}

        //Start destroy timer
        StartCoroutine(HelperUtilities.DisableAfter(disableAfter, gameObject));
    }

    //If the bullet collides with anything
    private void OnCollisionEnter(Collision collision)
    {
        if (startTransform != null
            && collision.transform == startTransform) return;
        //Ignore collisions with other projectiles.
        if (collision.gameObject.GetComponent<Projectiles>() != null)
            return;

        //If destroy on impact is false, start 
        //coroutine with random destroy timer
        if (!destroyOnImpact)
        {
            StartCoroutine(DisableTimer());
        }
        //Otherwise, destroy bullet on impact
        else
        {
            //Destroy(gameObject);
            gameObject.SetActive(false);
        }

        if (collision.gameObject.layer == LayerMask.NameToLayer("HitBox") && collision.transform.GetComponentInParent<Player>() == null)
        {
            ReuseObject("Impacts/IMP_Blood", collision.contacts[0].normal, collision.transform);
            gameObject.SetActive(false);
        }

        //If bullet collides with "Blood" tag
        if (collision.transform.tag == "Blood" && collision.transform.GetComponentInParent<Player>() == null)
        {
            ReuseObject("Impacts/IMP_Blood", collision.contacts[0].normal);
            // Back to object pool
            gameObject.SetActive(false);
        }

        //If bullet collides with "Metal" tag
        if (collision.transform.tag == "Metal")
        {
            //Instantiate random impact prefab from array
            //Instantiate(metalImpactPrefabs, transform.position,
            //    Quaternion.LookRotation(collision.contacts[0].normal));
            ReuseObject("Impacts/IMP_Metal", collision.contacts[0].normal);
            // Back to object pool
            gameObject.SetActive(false);
        }

        //If bullet collides with "Dirt" tag
        if (collision.transform.tag == "Dirt")
        {
            //Instantiate random impact prefab from array
            //Instantiate(dirtImpactPrefabs, transform.position,
            //    Quaternion.LookRotation(collision.contacts[0].normal));
            ReuseObject("Impacts/IMP_Dirt", collision.contacts[0].normal);
            // Back to object pool
            gameObject.SetActive(false);
        }

        //If bullet collides with "Concrete" tag
        if (collision.transform.tag == "Concrete")
        {
            //Instantiate random impact prefab from array
            //Instantiate(concreteImpactPrefabs, transform.position,
            //    Quaternion.LookRotation(collision.contacts[0].normal));
            ReuseObject("Impacts/IMP_Concrete", collision.contacts[0].normal);
            // Back to object pool
            gameObject.SetActive(false);
        }

        //If bullet collides with "Target" tag
        if (collision.transform.tag == "Target")
        {
            //Toggle "isHit" on target object
            collision.transform.gameObject.GetComponent
                <TargetClass>().isHit = true;
            // Back to object pool
            gameObject.SetActive(false);
        }

        //If bullet collides with "ExplosiveBarrel" tag
        if (collision.transform.tag == "ExplosiveBarrel")
        {
            //Toggle "explode" on explosive barrel object
            collision.transform.gameObject.GetComponent
                <ExplosiveBarrel>().explode = true;
            // Back to object pool
            gameObject.SetActive(false);
        }

        //If bullet collides with "GasTank" tag
        if (collision.transform.tag == "GasTank")
        {
            //Toggle "isHit" on gas tank object
            collision.transform.gameObject.GetComponent
                <InfimaGames.LowPolyShooterPack.Legacy.GasTankScript>().isHit = true;
            // Back to object pool
            gameObject.SetActive(false);
        }
    }

    private void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.layer == LayerMask.NameToLayer("HitBox"))
        {
            //gameObject.SetActive(false);
        }
    }
    #endregion Unity

    #region Method

    private void SetImpactTransforms()
    {
        ImpactClass bloodImpact = Resources.Load<ImpactClass>("Impacts/IMP_Blood");
        ImpactClass metalImpact = Resources.Load<ImpactClass>("Impacts/IMP_Metal");
        ImpactClass dirtImpact = Resources.Load<ImpactClass>("Impacts/IMP_Dirt");
        ImpactClass concreteImpact = Resources.Load<ImpactClass>("Impacts/IMP_Concrete");

        bloodImpactPrefabs = bloodImpact.transform;
        metalImpactPrefabs = metalImpact.transform;
        dirtImpactPrefabs = dirtImpact.transform;
        concreteImpactPrefabs = concreteImpact.transform;
    }

    public void SetParentTransform(Transform parent)
    {
        startTransform = parent;
    }

    public void SetBulletWeight(float weight)
    {
        rigidBody.mass= weight;
    }

    public void SetDamage(float damage)
    {
        this.damage = damage;
    }

    public void SetPenetrationLevel(int level)
    {
        penetrationlevel = level;
    }
    /// <summary>
    /// Reuse object from pool
    /// </summary>
    private void ReuseObject(string path, Vector3 normal, Transform target = null)
    {
        ImpactClass impactPrefab = Resources.Load<ImpactClass>(path);

        ImpactClass impact = (ImpactClass)PoolManager.Instance.ReuseComponent(impactPrefab.gameObject, 
                                                                              transform.position, 
                                                                              Quaternion.LookRotation(normal));
        impact.transform.parent = target;
        impact.gameObject.SetActive(true);
    }

    /// <summary>
    /// Set Velocity
    /// </summary>
    public void SetVelocity(Vector3 velocity)
    {
        rigidBody.velocity = velocity;
    }

    private IEnumerator DisableTimer()
    {
        //Wait random time based on min and max values
        yield return new WaitForSeconds
            (Random.Range(minDisableTime, maxDisableTime));
        // Back to object pool
        gameObject.SetActive(false);
    }
    #endregion Method
}
