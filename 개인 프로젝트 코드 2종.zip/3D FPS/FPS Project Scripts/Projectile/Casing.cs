using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Casing : MonoBehaviour
{
    [SerializeField]
    [Tooltip("Casing drop sounds")]
    private List<AudioClip> dropSoundList = new List<AudioClip>();
    [SerializeField]
    [Tooltip("Disable after this time")]
    private float disableTime = 2.0f;

    private AudioSource audioSource;
    private Rigidbody rigidBody;

    private void Awake()
    {
        audioSource= GetComponent<AudioSource>();
        rigidBody = GetComponent<Rigidbody>();
    }

    private void OnEnable()
    {
        StartCoroutine(HelperUtilities.DisableAfter(disableTime, gameObject));
    }

    private void SetAudioSource()
    {
        audioSource.clip = dropSoundList[Random.Range(0, dropSoundList.Count - 1)];
        audioSource.volume = 1f;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Character")) return;

        SetAudioSource();
        audioSource.Play();
    }

    public void SetVelocity(Vector3 velocity, Vector3 angularVelocity)
    {
        rigidBody.velocity = velocity;
        rigidBody.angularVelocity = angularVelocity;
    }

}
