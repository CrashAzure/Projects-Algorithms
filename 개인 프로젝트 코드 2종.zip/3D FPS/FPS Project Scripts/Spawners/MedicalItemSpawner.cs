using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MedicalItemSpawner : Spawners
{
    [Range(0f, 100f)]
    [SerializeField]
    private float spawnPercentage = 100f;
    public override void Awake()
    {
        Item[] itemPrefabs = Resources.LoadAll<Item>("MedicalItems");

        int percent = Random.Range(1, 101);

        if (percent < spawnPercentage)
        {
            int index = Random.Range(0, itemPrefabs.Length);

            Item itemGO = Instantiate(itemPrefabs[index]);
            itemGO.transform.position = transform.position;
        }

        base.Awake();
    }
}
