using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HelmetSpawner : Spawners
{
    [Range(0f, 100f)]
    [SerializeField]
    private float spawnPercentage = 100f;
    public override void Awake()
    {
        Helmet[] helmetPrefab = Resources.LoadAll<Helmet>("Helmet");

        int percent = Random.Range(1, 101);

        if (percent < spawnPercentage)
        {
            int index = Random.Range(0, helmetPrefab.Length);

            Helmet helmet = Instantiate(helmetPrefab[index]);
            helmet.transform.position = transform.position;
        }

        base.Awake();
    }
}
