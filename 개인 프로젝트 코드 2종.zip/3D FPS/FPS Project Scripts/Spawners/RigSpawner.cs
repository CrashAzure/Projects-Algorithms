using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RigSpawner : Spawners
{
    [Range(0f, 100f)]
    [SerializeField]
    private float spawnPercentage = 100f;
    public override void Awake()
    {
        RigContainer[] rigObjects = Resources.LoadAll<RigContainer>("Rig");

        int percent = Random.Range(1, 101);

        if (percent < spawnPercentage)
        {
            int index = Random.Range(0, rigObjects.Length);

            RigContainer rig = Instantiate(rigObjects[index]);
            rig.transform.position = transform.position;
        }

        base.Awake();
    }
}
