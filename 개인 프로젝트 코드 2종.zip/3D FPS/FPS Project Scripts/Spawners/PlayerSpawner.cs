using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSpawner : MonoBehaviour
{
    public Player[] players;

    private void Awake()
    {
        players = FindObjectsOfType<Player>();

        foreach(Player player in players)
        {
            player.GetComponent<PlayerStatus>().isInGame = true;
            player.transform.position = transform.position;
        }
    }


}
