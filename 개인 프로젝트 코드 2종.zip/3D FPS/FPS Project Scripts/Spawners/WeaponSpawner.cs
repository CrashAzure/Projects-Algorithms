using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponSpawner : Spawners
{
    [Range(0f, 100f)]
    [SerializeField]
    private float spawnPercentage = 100f;
    public override void Awake()
    {
        WeaponStatus[] weaponObjects = Resources.LoadAll<WeaponStatus>("Weapons");

        int percent = Random.Range(1, 101);
        
        if(percent < spawnPercentage)
        {
            int index = Random.Range(0, weaponObjects.Length);

            WeaponStatus weaponGO = Instantiate(weaponObjects[index]);
            weaponGO.RandomWeaponPartsUpdate();
            weaponGO.transform.position = transform.position;
        }

        base.Awake();
    }
}
