using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmorSpawner : Spawners
{
    [Range(0f, 100f)]
    [SerializeField]
    private float spawnPercentage = 100f;
    public override void Awake()
    {
        Armor[] armorPrefabs = Resources.LoadAll<Armor>("Armor");

        int percent = Random.Range(1, 101);

        if (percent < spawnPercentage)
        {
            int index = Random.Range(0, armorPrefabs.Length);

            Armor armor = Instantiate(armorPrefabs[index]);
            armor.transform.position = transform.position;
        }

        base.Awake();
    }
}
