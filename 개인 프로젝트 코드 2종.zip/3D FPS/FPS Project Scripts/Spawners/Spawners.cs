using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawners : MonoBehaviour
{
    [HideInInspector]
    public bool isDoneToInstantiate = false;

    public virtual void Awake()
    {
        isDoneToInstantiate = true;
    }
}
