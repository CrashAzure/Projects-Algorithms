using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackPackSpawner : Spawners
{
    [Range(0f, 100f)]
    [SerializeField]
    private float spawnPercentage = 100f;
    public override void Awake()
    {
        BackPackContainer[] backpackPrefab = Resources.LoadAll<BackPackContainer>("Backpack");

        int percent = Random.Range(1, 101);

        if (percent < spawnPercentage)
        {
            int index = Random.Range(0, backpackPrefab.Length);

            BackPackContainer backpack = Instantiate(backpackPrefab[index]);
            backpack.transform.position = transform.position;
        }

        base.Awake();
    }
}
