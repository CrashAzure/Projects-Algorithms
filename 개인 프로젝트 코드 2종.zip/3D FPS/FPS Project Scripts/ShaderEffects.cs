using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShaderEffects : MonoBehaviour
{
    #region Parameters
    public List<ParticleSystem> effects = new List<ParticleSystem>();
    public Camera effectCamera;
    public Camera fogCamera;
    private CameraEff cameraEff;
    private CameraEffect cameraEffect;
    public EffectType currentEffect;
    private EffectType prevEffect;
    private SoundEffects soundEffect;
    #endregion

    #region Unity
    private void Awake()
    {
        for(int i = 0; i < transform.childCount; i++)
        {
            effects.Add(transform.GetChild(i).GetComponent<ParticleSystem>());
        }
        soundEffect = GetComponent<SoundEffects>();
        cameraEff = effectCamera.GetComponent<CameraEff>();
        cameraEffect = fogCamera.GetComponent<CameraEffect>();
    }

    private void Update()
    {
        ProcessRainning();
        ProcessFreezing();
        CheckToStopEffect();

        ProcessRotate();

        if (currentEffect != EffectType.Rain && currentEffect != EffectType.Blizzard)
        {
            effects[1].gameObject.SetActive(false);
        }

        
        //DontFollowFog();

        prevEffect = currentEffect;
    }

    private void DontFollowFog()
    {
        if(currentEffect == EffectType.Blizzard)
        {
            Vector3 player = GameController.Instance.player.transform.position;

            effects[3].transform.position = new Vector3(player.x, 0f, player.z);
        }
    }

    private void ProcessRotate()
    {
        Transform player = GameController.Instance.player.playerRootAnimator;
        transform.localEulerAngles = new Vector3(0f,-player.parent.eulerAngles.y, 0f);
    }

    #endregion Unity

    #region Methods
    /// <summary>
    /// Set current effect type
    /// </summary>
    public void SetEffectType(EffectType effectType)
    {
        currentEffect= effectType;
    }

    /// <summary>
    /// Process rainning
    /// </summary>
    private void ProcessRainning()
    {
        if (currentEffect != EffectType.Rain) return;
        float duration = 0f;

        if (prevEffect == EffectType.Blizzard)
        {
            duration = 5f;
            StartCoroutine(StopSnowing(5f));
        }

        if (prevEffect != currentEffect)
        {
            StartCoroutine(StartRainingSound(duration));
            StartCoroutine(StartRainning(duration));
        }

        ProcessColdBreathing();
    }


    private void ProcessFreezing()
    {
        if (currentEffect != EffectType.Blizzard) return;
        float duration = 0f;
        if (prevEffect == EffectType.Rain)
        {
            duration = 5f;
            StartCoroutine(StopRaining(5f));
        }

        if (prevEffect != currentEffect)
        {
            StartCoroutine(StartStormSound(duration));
            StartCoroutine(StartSnowing(duration));
        }

        ProcessColdBreathing();
    }

    private void ProcessColdBreathing()
    {
        CameraController camera = GameController.Instance.mainCameraController;
        effects[1].transform.position = camera.transform.position;
        effects[1].transform.rotation = camera.transform.rotation;
        effects[1].transform.position += camera.transform.forward * 0.2f;
        effects[1].gameObject.SetActive(true);
    }

    /// <summary>
    /// Stop Effect
    /// </summary>
    private void CheckToStopEffect()
    {
        if (currentEffect != EffectType.None) return;
        if (prevEffect == currentEffect)return;

        if (prevEffect == EffectType.Rain)
        {
            StartCoroutine(StopRaining(5f));
        }
        else if (prevEffect == EffectType.Blizzard)
        {
            StartCoroutine(StopSnowing(5f));
        }
        else
        {
            // Set effect type
            cameraEff.effectType = currentEffect;
            cameraEffect.effectType = currentEffect;
        }
    }

    private IEnumerator StartRainingSound(float duration)
    {
        yield return new WaitForSeconds(duration);
        yield return new WaitForSeconds(1.5f);
        soundEffect.SetAudio(EffectType.Rain);
    }

    private IEnumerator StartStormSound(float duration)
    {
        yield return new WaitForSeconds(duration);
        soundEffect.SetAudio(EffectType.Blizzard);
    }

    private IEnumerator StopFog(float duration)
    {
        yield return new WaitForSeconds(duration);
        ParticleSystem.MainModule main = effects[3].main;
        StartCoroutine(HelperUtilities.LerpCoroutine(1000f, 0f, 5f, a => main.maxParticles = (int)a));
        yield return new WaitForSeconds(5f);
        effects[3].gameObject.SetActive(false);
    }

    private IEnumerator StartFog(float duration)
    {
        yield return new WaitForSeconds(duration);
        ParticleSystem.MainModule main = effects[3].main;
        effects[3].gameObject.SetActive(true);
        StartCoroutine(HelperUtilities.LerpCoroutine(0f, 1000f, 5f, a => main.maxParticles = (int)a));
    }

    private IEnumerator StopRaining(float duration)
    {
        ParticleSystem.MainModule main = effects[0].transform.GetChild(0).GetComponent<ParticleSystem>().main;
        
        StartCoroutine(HelperUtilities.LerpCoroutine(1f, 0f, duration, a => cameraEff.rainAmount = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(0.5f, 0f, duration, a => cameraEff.vignette = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(1f, 0f, duration, a => cameraEff.fadeAmount = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(10000f, 0f, duration, a => main.maxParticles = (int)a));
        StartCoroutine(HelperUtilities.LerpCoroutine(0.1f, 0f, 2.0f, a => soundEffect.audioEffect.SetVolume(a)));

        yield return new WaitForSeconds(2.0f);
        soundEffect.DisableAudio();
        yield return new WaitForSeconds(duration - 2.0f);

        
        effects[0].gameObject.SetActive(false);

        // Set effect type
        cameraEff.effectType = currentEffect;

        UpdateEffects();
    }

    private IEnumerator StartRainning(float duration)
    {
        yield return new WaitForSeconds(duration);
        
        ParticleSystem.MainModule main = effects[0].transform.GetChild(0).GetComponent<ParticleSystem>().main;

        StartCoroutine(HelperUtilities.LerpCoroutine(0f, 1f, 5f, a => cameraEff.rainAmount = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(0f, 0.5f, 5f, a => cameraEff.vignette = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(0f, 1f, 5f, a => cameraEff.fadeAmount = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(0f, 10000f, 5f, a => main.maxParticles = (int)a));

        // first effect(Rain_Fx) enable
        effects[0].gameObject.SetActive(true);

        // Set effect type
        cameraEff.effectType = currentEffect;

        UpdateEffects();
    }

    private IEnumerator StartSnowing(float duration)
    {
        yield return new WaitForSeconds(duration);

        ParticleSystem.MainModule main = effects[2].main;

        StartCoroutine(HelperUtilities.LerpCoroutine(0f, 20f, 5f, a => cameraEff.freezeAmount = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(2f, 1f, 5f, a => cameraEff.lensVignette = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(1f, 1.2f, 5f, a => cameraEff.freezeFadeAmount = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(Vector3.one, new Vector3(0.8f, 0.9f, 1.2f), 5f, a => cameraEff.freezeColor = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(0f, 10000f, 5f, a => main.maxParticles = (int)a));
        effects[2].gameObject.SetActive(true);
        // Set effect type
        cameraEff.effectType = currentEffect;

        UpdateEffects();
    }

    public bool HasChangedEffect() => currentEffect != prevEffect;

    private IEnumerator StopSnowing(float duration)
    {
        effects[1].gameObject.SetActive(false);
        ParticleSystem.MainModule main = effects[2].main;

        StartCoroutine(HelperUtilities.LerpCoroutine(20f, 0f, duration, a => cameraEff.freezeAmount = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(1f, 2f, duration, a => cameraEff.lensVignette = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(1.2f, 1f, duration, a => cameraEff.freezeFadeAmount = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(new Vector3(0.8f, 0.9f, 1.2f), Vector3.one, duration, a => cameraEff.freezeColor = a));
        StartCoroutine(HelperUtilities.LerpCoroutine(10000f, 0f, duration, a => main.maxParticles = (int)a));
        StartCoroutine(HelperUtilities.LerpCoroutine(0.1f, 0f, 2.0f, a => soundEffect.audioEffect.SetVolume(a)));
        yield return new WaitForSeconds(2.0f);
        soundEffect.DisableAudio();
        yield return new WaitForSeconds(duration - 2.0f);

        effects[2].gameObject.SetActive(false);

        // Set effect type
        cameraEff.effectType = currentEffect;

        UpdateEffects();
    }

    private void UpdateEffects()
    {
        if (prevEffect != currentEffect)
        {
            
        }

        CameraEffect[] cameraEffects = FindObjectsOfType<CameraEffect>(true);

        foreach (var effect in cameraEffects)
        {
            effect.effectType = currentEffect;
        }
    }

    #endregion Methods
}
