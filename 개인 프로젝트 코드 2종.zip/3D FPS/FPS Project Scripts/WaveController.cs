using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class WaveController : MonoBehaviour
{
    public Material waveMaterial;
    public ComputeShader waveComputeShader;
    // NState , N minus 1 State, N Plus 1 State
    public RenderTexture NState, Nm1State, Np1State;

    public RenderTexture ObstacleTexture;

    public Vector2Int resoulution;

    public Vector3 effectVector; // x coord, y coord, strength

    public float dispersion;

    private void Awake()
    {
        InitializeRenderTexture(ref NState);
        InitializeRenderTexture(ref Nm1State);
        InitializeRenderTexture(ref Np1State);

        ObstacleTexture.enableRandomWrite = true;
        Debug.Assert(ObstacleTexture.width == resoulution.x && ObstacleTexture.height == resoulution.y);

        waveMaterial.mainTexture = NState;

        GetComponent<Renderer>().material = waveMaterial;
    }

    private void InitializeRenderTexture(ref RenderTexture tex)
    {
        tex = new RenderTexture(resoulution.x, resoulution.y, 1, UnityEngine.Experimental.Rendering.GraphicsFormat.R16G16B16A16_SNorm);

        tex.enableRandomWrite = true;
        tex.Create();
    }

    private void Update()
    {
        Graphics.CopyTexture(NState, Nm1State);
        Graphics.CopyTexture(Np1State, NState);

        waveComputeShader.SetTexture(0, "NState", NState);
        waveComputeShader.SetTexture(0, "Nm1State", Nm1State);
        waveComputeShader.SetTexture(0, "Np1State", Np1State);
        waveComputeShader.SetVector("effectVector", effectVector);

        waveComputeShader.SetInts("resolution", new int[] {resoulution.x, resoulution.y});

        waveComputeShader.SetFloat("dispersion", dispersion);

        waveComputeShader.SetTexture(0, "ObstacleTexture", ObstacleTexture);

        waveComputeShader.Dispatch(0, resoulution.x / 8, resoulution.x / 8, 1);

    }
}
