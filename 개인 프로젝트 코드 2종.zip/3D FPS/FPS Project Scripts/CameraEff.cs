using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EffectType
{
    None,
    Rain,
    Blizzard,
}

public class CameraEff : MonoBehaviour
{
    public EffectType effectType;
    public Material rainMaterial;
    public Material freezingMaterial;
    public Material defaultMaterial;
    [Range(0, 3)]
    public float freezeAmount;
    [Range(0, 1)]
    public float rainAmount;
    [Range(0, 1)]
    public float fadeAmount;
    [Range(0, 1)]
    public float freezeFadeAmount;
    [Range(0, 1f)]
    public float vignette;
    public float lensVignette;
    public Vector3 freezeColor = Vector3.one;

    public Camera thisCam;
    private void Awake()
    {
        Material rainMat = Resources.Load<Material>("RainDrop");
        rainMaterial = Instantiate(rainMat);
        Material freezingMat = Resources.Load<Material>("Freezing");
        freezingMaterial = Instantiate(freezingMat);
        thisCam = GetComponent<Camera>();
    }

    public void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if(effectType == EffectType.Rain)
        {
            rainMaterial.SetTexture("iChannel0", source);
            
            Graphics.Blit(source, destination, rainMaterial);
        }
        else if (effectType == EffectType.Blizzard)
        {
            freezingMaterial.SetTexture("iChannel0", source);

            Graphics.Blit(source, destination, freezingMaterial);
        }
        else if(effectType == EffectType.None) 
        {
            Graphics.Blit(source, destination);
        }
    }

    private void Update()
    {
        if (effectType == EffectType.Rain)
        {
            rainMaterial.SetFloat("amount", rainAmount);
            rainMaterial.SetFloat("fadeAmount", fadeAmount);
            rainMaterial.SetFloat("vignette", vignette);
        }

        if (effectType == EffectType.Blizzard)
        {
            freezingMaterial.SetFloat("FROSTYNESS", freezeAmount);
            freezingMaterial.SetFloat("fadeAmount", freezeFadeAmount);
            freezingMaterial.SetFloat("vignette", lensVignette);
            freezingMaterial.SetVector("freezingColor", freezeColor);
        }
    }
}
