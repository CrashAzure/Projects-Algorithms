using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Windows;

public class FootstepEnemy : Footstep
{
    private NavMeshAgent agent;
    private Enemy enemy;
    public override void Awake()
    {
        base.Awake();
        agent = GetComponent<NavMeshAgent>();
        enemy = GetComponent<Enemy>();
    }
    public override void Update()
    {
        if (!agent.isStopped && !enemy.isDead)
        {
            PlayFootstep();
        }
        else
        {
            StopFootstep();
        }
    }

    /// <summary>
    /// Looping coroutine for foot step
    /// </summary>
    public override IEnumerator FootstepCoroutine(float cycleTime)
    {
        float elapsed = 0f;
        float cycle = 0;
        float volume = 1f;

        while (true)
        {
            if (!agent.isStopped && !enemy.isDead)
            {
                cycle = Mathf.Lerp(cycleTime * 2, cycleTime / 2, enemy.verticalMoving);
                volume = Mathf.Lerp(0.4f, 1f, enemy.verticalMoving);
            }
            else
            {
                cycle = cycleTime;
                volume = 0.4f;
            }

            if (elapsed == 0f)
            {
                GameObject audioPrefab = Resources.Load<GameObject>("Audio");
                SetAudio audio = (SetAudio)PoolManager.Instance.ReuseComponent(audioPrefab, transform.position, Quaternion.identity);
                AudioClip footstep = concreteFootstepSounds[Random.Range(0, concreteFootstepSounds.Count - 1)];

                audio.SetVolume(volume);
                audio.SetPitch(1.0f);
                audio.SetAudioSource(footstep);
                audio.gameObject.SetActive(true);
                audio.Play();
                StartCoroutine(HelperUtilities.DisableObject(footstep.length, audio.gameObject));
            }

            elapsed += Time.deltaTime;

            if (elapsed >= cycle)
            {
                elapsed = 0f;
            }

            yield return null;
        }
    }
}
