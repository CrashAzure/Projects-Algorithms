using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.EventSystems;

public enum EnemyStatus
{
    Idle,
    Chasing,
    Observing,
    Fighting,
    Dead
}

public class Enemy : Character
{

    public bool isDead = false;
    [SerializeField]
    private GameObject animationDollGameObject;
    [SerializeField]
    private GameObject ragdollGameObject;

    private List<AudioClip> foundVoices = new List<AudioClip>();

    private Character target;
    private Vector3 prevPosition = Vector3.zero;

    private float movingTimer = 0f;
    private float shotTimer = 5f;
    private float reDiscoveryTimer = 0f;
    private float reDiscoveryTime = 3f;

    private int direction = 1;

    [HideInInspector]
    public float horizontalMoving = 0f;
    [HideInInspector]
    public float verticalMoving = 0f;
    private float Movement = 0f;
    private float sideWalkSpeed = 0.5f;
    private float walkBackwardSpeed = 1.3f;
    private float walkFrontSpeed = 3.5f;
    private float observingDistance = 15f;

    private bool isAim = false;
    [HideInInspector]
    public bool isSideWalk = false;

    private Coroutine verticalIdleCO = null;
    private Coroutine horizontalIdleCO = null;

    private WeaponController currentWeapon;

    private EnemyStatus status = EnemyStatus.Idle;
    

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        //animators = GetComponentsInChildren<Animator>(true);
        animator = animationDollGameObject.GetComponent<Animator>();
        movingTimer = Random.Range(1f, 3f);
        currentWeapon = GetComponentInChildren<WeaponController>();
        foundVoices.AddRange(Resources.LoadAll("Scav_Voices"));
        inventory = GetComponentInChildren<Inventory>();
    }

    private void Update()
    {
        if (isDead)
        {
            ProcessToDie();
            return;
        }
        // For Testing
        //else if(!animationDollGameObject.activeSelf)
        //{
        //    animationDollGameObject.gameObject.SetActive(true);
        //    ragdollGameObject.gameObject.SetActive(false);
        //}

        movingTimer -= Time.deltaTime;

        if (status != EnemyStatus.Fighting)
        {
            if ((prevPosition - transform.position).magnitude < 0.1f && agent.isStopped)
            {
                AgentSetIdle();
            }

            // Temp Section
            if (Vector3.Angle(transform.forward, GameController.Instance.player.transform.position - transform.position) <= 45f)
            {
                FoundTarget();
            }
        }
        else
        {
            animator.SetBool("Aim", true);
            shotTimer -= Time.deltaTime;
            FocusOnTarget(target.transform);
            ShootOnTarget();
        }

        SetRandomDestiantion();
        

        if (agent.pathStatus == NavMeshPathStatus.PathPartial)
        {
            movingTimer = 0f;
            agent.isStopped = true;
            return;
        }

        CheckArrivingAtDestination();
        CheckSideWalkRatio();
        
        if(verticalMoving > 0)
        {
            // Decide walk speed to front
            agent.speed = Mathf.Lerp(sideWalkSpeed, walkFrontSpeed, verticalMoving);
        }
        else
        {
            // Decide walk speed to backward
            agent.speed = Mathf.Lerp(sideWalkSpeed, walkBackwardSpeed, Mathf.Abs(verticalMoving));
        }
        

        if (isSideWalk)
        {
            animator.SetBool("Idle", false);
            ProcessStopMovement();
        }
        else
        {
            animator.SetBool("Idle", agent.isStopped);
            ProcessMoveAgain();
        }

        if (agent.isStopped)
        {
            horizontalMoving = 0f;
            verticalMoving = 0f;
        }
        
        animator.SetFloat("Horizontal", horizontalMoving);
        animator.SetFloat("Vertical", verticalMoving);
        animator.SetBool("Aim", isAim);

        prevPosition = transform.position;
    }

    private void SetRandomDestiantion()
    {
        if (movingTimer > 0f) return;

        movingTimer = Random.Range(10f, 20f);
        Vector2 randomUnitCircle = Random.insideUnitCircle.normalized;

        Vector3 observingPoint = transform.position + new Vector3(randomUnitCircle.x, 0f, randomUnitCircle.y) * observingDistance;

        if (status == EnemyStatus.Fighting)
        {
            observingPoint = transform.position + direction * Random.Range(observingDistance * 0.7f, observingDistance) * transform.right;
        }

        if (Physics.Raycast(observingPoint + Vector3.up * 100f, Vector3.down, out RaycastHit rayHit))
        {
            agent.SetDestination(rayHit.point);
            agent.isStopped = false;
        }
        else
        {
            // Search again
            // different side
            direction -= direction;

            movingTimer = 0f;
        }

    }

    private void ProcessStopMovement()
    {
        if (horizontalIdleCO == null
                && verticalIdleCO == null)
        {
            horizontalIdleCO = StartCoroutine(HelperUtilities.LerpCoroutine(horizontalMoving, 0f, 0.2f, a => horizontalMoving = a));
            verticalIdleCO = StartCoroutine(HelperUtilities.LerpCoroutine(verticalMoving, 0f, 0.2f, a => verticalMoving = a));
        }
    }

    private void ProcessMoveAgain()
    {
        if (horizontalIdleCO != null
                && verticalIdleCO != null)
        {
            StopAllCoroutines();
            horizontalIdleCO = null;
            verticalIdleCO = null;
        }
    }

    /// <summary>
    /// Check arrining at destination
    /// </summary>
    private void CheckArrivingAtDestination()
    {
        if ((transform.position - agent.destination).magnitude <= 1f)
        {
            agent.isStopped = true;
        }
        else
        {
            agent.isStopped = false;
            verticalMoving = 1f;
        }
    }

    /// <summary>
    /// Check side walk ratio
    /// </summary>
    private void CheckSideWalkRatio()
    {
        if (agent.isStopped && horizontalMoving < 0.001f)
        {
            ProcessStopMovement();
            return;
        }

        float directionAngle = Vector3.SignedAngle(transform.forward, animationDollGameObject.transform.forward, Vector3.up);

        if (directionAngle > 0.1f)
        {
            horizontalMoving = 1 - Mathf.Abs((directionAngle - 90f) / 90f);
            verticalMoving = horizontalMoving - 1;
            isSideWalk = true;

            if (directionAngle < 90)
            {
                verticalMoving = -verticalMoving;
            }
        }
        else if (directionAngle < -0.1f)
        {
            horizontalMoving = -1 + Mathf.Abs((directionAngle + 90f) / 90f);
            verticalMoving = horizontalMoving + 1;
            isSideWalk = true;

            if(directionAngle < -90)
            {
                verticalMoving = -verticalMoving;
            }
        }
        else
        {
            horizontalMoving = 0f;
            isSideWalk = false;
            agent.isStopped = false;
        }
    }

    /// <summary>
    /// Process to die.
    /// </summary>
    private void ProcessToDie()
    {
        animationDollGameObject.gameObject.SetActive(false);
        ragdollGameObject.gameObject.SetActive(true);

        Animator targetAinmator = ragdollGameObject.GetComponent<Animator>();

        targetAinmator.SetFloat("Horizontal", 0);
        targetAinmator.SetFloat("Vertical", 0);
        targetAinmator.SetBool("Dead", isDead);

        ragdollGameObject.GetComponent<Animator>().enabled = false;

        agent.isStopped = true;
        this.enabled = false;
    }

    private bool CheckFindingPlayer()
    {
        RaycastHit[] results = Physics.RaycastAll(transform.position + Vector3.up, GameController.Instance.player.transform.position - transform.position,  (GameController.Instance.player.transform.position - transform.position).magnitude
                                                  , ~((1 << LayerMask.NameToLayer("HitBox")) + (1<< LayerMask.NameToLayer("Invisible")) + (1 << LayerMask.NameToLayer("EscapingLocation"))));
        
        if (results.Length > 0)
        {
            foreach (RaycastHit hit in results)
            {
                if (!hit.transform.CompareTag("Player") && !hit.transform.CompareTag("Enemy"))
                {
                    return false;
                }
            }
        }
        return true;
    }

    private void OnDrawGizmos()
    {
        Debug.DrawRay(transform.position + Vector3.up, (GameController.Instance.player.transform.position + Vector3.up) - (transform.position + Vector3.up));
    }

    /// <summary>
    /// Temp
    /// </summary>
    private void FoundTarget()
    {
        if (!CheckFindingPlayer()) return;

        SetAudio audioPrefab = Resources.Load<SetAudio>("Audio");
        SetAudio audio = (SetAudio)PoolManager.Instance.ReuseComponent(audioPrefab.gameObject, headTransform.position, Quaternion.identity);
        audio.SetAudioSource(foundVoices[Random.Range(0, foundVoices.Count - 1)]);
        audio.transform.SetParent(headTransform);
        audio.gameObject.SetActive(true);
        audio.Play();

        // Search to move
        movingTimer = 0f;
        this.target = GameController.Instance.player;
        status = EnemyStatus.Fighting;
    }

    private void ShootOnTarget()
    {
        if (shotTimer > 0f) return;

        shotTimer = Random.Range(3f, 5f);
        currentWeapon.FireForEnemy(transform);
    }

    private void FocusOnTarget(Transform target)
    {
        if (!CheckFindingPlayer())
        {
            reDiscoveryTimer += Time.deltaTime;

            if (reDiscoveryTimer > reDiscoveryTime)
            {
                reDiscoveryTimer = 0f;
                AgentSetIdle();
            }
        }
        else
        {
            reDiscoveryTimer = 0f;
        }

        Vector3 targetPoint = new Vector3(target.position.x, transform.position.y, target.position.z);
        animationDollGameObject.transform.LookAt(targetPoint);
        ragdollGameObject.transform.LookAt(targetPoint);
        animationDollGameObject.transform.localEulerAngles -= Vector3.right * animationDollGameObject.transform.localEulerAngles.x;
        ragdollGameObject.transform.localEulerAngles -= Vector3.right * ragdollGameObject.transform.localEulerAngles.x;
        isAim = true;
    }

    private void AgentSetIdle()
    {
        agent.enabled = true;
        agent.isStopped = true;
        agent.speed = walkFrontSpeed;
        animationDollGameObject.transform.localRotation = Quaternion.identity;
        animator.SetBool("Aim", false);
        verticalMoving = 1f;
        horizontalMoving = 0f;
        direction = 1;
        status = EnemyStatus.Idle;
    }
    private void StartChasing()
    {
        agent.SetDestination(GameController.Instance.player.agent.transform.position);
        agent.isStopped = false;
    }

    /// <summary>
    /// Rotate velocity at player direction
    /// </summary>
    private Vector3 RotateVelocity(Vector3 velocity)
    {
        float signedAngle = Vector2.SignedAngle(Vector2.up, new Vector2(transform.forward.x, transform.forward.z));

        return Quaternion.AngleAxis(-signedAngle, Vector3.up) * velocity;
    }


}
