using System.Collections;
using UnityEngine;
using UnityEngine.Audio;

public class SetAudio : MonoBehaviour
{
    private AudioSource audioSource;
    private Coroutine playCoroutine = null;
    private AudioMixerGroup mixer;
    private Transform anchor;
    private void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        mixer = audioSource.outputAudioMixerGroup;
        anchor = transform.parent;
    }

    public void Play(bool isLoop = false)
    {
        if(playCoroutine != null)
        {
            StopCoroutine(playCoroutine);
            playCoroutine = null;
        }

        if (!gameObject.activeSelf) gameObject.SetActive(true);

        if (isLoop)
        {
            audioSource.Play();
        }
        else
        {
            playCoroutine = StartCoroutine(PlaySound());
        }
    }

    private IEnumerator PlaySound()
    {
        audioSource.Play();
        yield return new WaitForSeconds(audioSource.clip.length);
        InitAudioSource();
        gameObject.SetActive(false);
    }

    public void InitAudioSource()
    {
        transform.SetParent(anchor);
        audioSource.volume = 1.0f;
        audioSource.pitch = 1.0f;
        audioSource.clip = null;
    }

    public void SetVolume(float volume)
    {
        audioSource.volume = volume;
    }

    public void SetPitch(float pitch)
    {
        audioSource.pitch = pitch;
    }

    public void InitMixer()
    {
        audioSource.outputAudioMixerGroup = null;
    }
    public void ReturnMixer()
    {
        audioSource.outputAudioMixerGroup = mixer;
    }

    /// <summary>
    /// Set audio source
    /// </summary>
    public void SetAudioSource(AudioClip audioClip)
    {
        audioSource.clip = audioClip;
    }

    internal void SetLoop(bool isLoop)
    {
        audioSource.loop = isLoop;
    }
}
