using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PassingBulletSound : MonoBehaviour
{
    private List<AudioClip> audioClips = new List<AudioClip>();

    private void Awake()
    {
        foreach(var clip in Resources.LoadAll("PassingBullets"))
        {
            audioClips.Add(clip as AudioClip);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.layer == LayerMask.NameToLayer("Projectile"))
        {
            if (other.gameObject.GetComponent<Projectiles>().startTransform == transform.root) return;
            Play(other);
        }
    }

    private void Play(Collider other)
    {
        SetAudio audioPrefab = Resources.Load<SetAudio>("Audio");
        SetAudio audio = (SetAudio)PoolManager.Instance.ReuseComponent(audioPrefab.gameObject, other.transform.position, Quaternion.identity);
        
        audio.gameObject.SetActive(true);
        audio.SetAudioSource(audioClips[Random.Range(0, audioClips.Count - 1)]);
        audio.SetVolume(0.1f);
        audio.Play();
    }
}
