using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TextListController : MonoBehaviour
{
    public List<TextMeshProUGUI> textMeshProList = new List<TextMeshProUGUI>();

    private void SetTextList()
    {
        textMeshProList.Clear();

        TextMeshProUGUI[] array = GetComponentsInChildren<TextMeshProUGUI>();

        textMeshProList.AddRange(array);
    }
}
