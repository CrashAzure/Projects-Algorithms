using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CrouchingUI : MonoBehaviour
{
    public Sprite crouchIcon;
    public Sprite standIcon;

    [HideInInspector]
    public Image image;
    private TextMeshProUGUI tmp;
    private CanvasGroup group;
    private Coroutine co = null;

    private void Awake()
    {
        group = GetComponent<CanvasGroup>();
        image = GetComponent<Image>();
        tmp = GetComponentInChildren<TextMeshProUGUI>();
    }

    /// <summary>
    /// Set icon
    /// </summary>
    public void SetCrouchIcon(bool isCrouch)
    {
        if (isCrouch)
        {
            image.sprite = crouchIcon;
            tmp.text = "Coruching";
        }
        else
        {
            image.sprite = standIcon;
            tmp.text = "Standing";
        }

        ProcessLerp(1.0f, 0.3f, 1f, 2f);
    }

    /// <summary>
    /// Check coroutine is already here
    /// </summary>
    private void ProcessLerp(float start, float end, float duration, float delayTime)
    {
        if(co != null)
        {
            StopCoroutine(co);
            co = null;
        }
        co = StartCoroutine(LerpIcon(start, end, duration, delayTime));
    }

    /// <summary>
    /// Lerp coroutine
    /// </summary>
    private IEnumerator LerpIcon(float start, float end, float duration, float delayTime)
    {
        group.alpha = 1f;

        yield return new WaitForSeconds(delayTime);

        float elapsed = 0f;

        while(elapsed < 1f)
        {
            elapsed += Time.deltaTime / duration;

            group.alpha = Mathf.Lerp(start, end, elapsed);

            yield return null;
        }
    }

}
