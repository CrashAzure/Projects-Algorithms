using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FadeUI : MonoBehaviour
{
    private Image fadeImage;
    private Coroutine co = null;
    private bool isIncrease = false;
    private void Awake()
    {
        fadeImage = GetComponent<Image>();
    }
    public void FadeInAndOut(float duration, float delayTime, bool isIncrease)
    {
        if (!gameObject.activeSelf)
        {
            gameObject.SetActive(true);
        }
        //HelperUtilities.LerpCoroutine()
        if(co != null)
        {
            StopCoroutine(co);
            co = null;
        }
        if (isIncrease)
        {
            co = StartCoroutine(HelperUtilities.DelayLerpCoroutine(0f, 1f, duration, delayTime, a => fadeImage.color = new Color(0, 0, 0,a), b => co = b));
        }
        else
        {
            co = StartCoroutine(HelperUtilities.DelayLerpCoroutine(1f, 0f, duration, delayTime, a => fadeImage.color = new Color(0, 0, 0, a), b => co = b));
        }

        this.isIncrease = isIncrease;
    }

    private void Update()
    {
        if (co == null && gameObject.activeSelf && !isIncrease)
        {
            gameObject.SetActive(false);
            UIManager.Instance.loadingUI.gameObject.SetActive(false);
        }
    }
}
