using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class MaskController : MonoBehaviour
{
    private Animator animator;
    public bool isFade = false;
    public bool isDoing = false;
    private Coroutine fadeCoroutine = null;
    private RectTransform rect;
    private Image image;
    private Mask mask;

    private void Awake()
    {
        animator = GetComponent<Animator>();
        rect = GetComponent<RectTransform>();
        image = GetComponent<Image>();
        mask = GetComponent<Mask>();
    }

    private void OnEnable()
    {
        FadeOutMask();
    }

    private void Update()
    {
        if (!isDoing) return;
        if(!isFade) return;
        FadeInMask();
    }

    public void Disable()
    {
        FadeOutMask();
        isDoing = true;
    }
    private void OnDisable()
    {
        Disable();
    }

    public void FadeInMask()
    {
        //isFade = true;
        float start = rect.sizeDelta.x / image.sprite.rect.width;
        ProcessFade(1f, 0f);
    }

    public void FadeOutMask()
    {
        //isFade = false;
        float start = rect.sizeDelta.x / image.sprite.rect.width;
        ProcessFade(0f, 1f);
    }

    public bool HasFade() => isFade;

    private void ProcessFade(float start, float end)
    {
        if(fadeCoroutine != null)
        {
            StopCoroutine(fadeCoroutine);
            fadeCoroutine = null;
        }

        fadeCoroutine = StartCoroutine(FadeMask(start, end, 0.5f));
    }

    private IEnumerator FadeMask(float start, float end, float duration)
    {
        float elapsed = 0f;
        Vector2 targetVector = image.sprite.rect.size * 32f;

        while (elapsed <= 1f) 
        {
            elapsed += Time.deltaTime / duration;

            rect.sizeDelta = Vector2.Lerp(targetVector * start, targetVector * end, elapsed);

            yield return null;
        }

        isFade = !isFade;
        isDoing = false;
        fadeCoroutine = null;

        if (!isFade)
        {
            transform.parent.gameObject.SetActive(false);
        }
    }
}
