using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SelectUIController : MonoBehaviour
{
    private List<Button> btnList = new List<Button>();
    private int currentSelectedIndex = 0;
    private List<Button> currentBtnList = new List<Button>();
    private EventSystem eventSystem;
    private PointerEventData pointer;
    private RectTransform rectTransform;
    private RaycastHit currentRayHit;

    private void Awake()
    {
        eventSystem = EventSystem.current;
        pointer = new PointerEventData(EventSystem.current);
        rectTransform = GetComponent<RectTransform>();

        gameObject.SetActive(false);
    }

    private void OnEnable()
    {
        currentSelectedIndex = 0;
        currentRayHit = GameController.Instance.player.GetEnableOutline().GetRayPoint();

        GetChildren();
        SetButtons();
        EnableCurrentButton();
    }

    private void LateUpdate()
    {
        if (!GameController.Instance.player.GetEnableOutline().HasRayHit() ||
            currentRayHit.transform.name != GameController.Instance.player.GetEnableOutline().GetRayPoint().transform.name)
        {
            gameObject.SetActive(false);
        }
    }

    /// <summary>
    /// Set buttons with target game object tag
    /// </summary>
    private void SetButtons()
    {
        currentBtnList.Clear();

        foreach (Button btn in btnList)
        {
            CheckTag(btn);
        }
    }

    private void CheckTag(Button btn)
    {
        string getButton = "Btn_Get";
        string cancelButton = "Btn_Cancel";
        string equipButton = "Btn_Equip";
        string searchButton = "Btn_Search";

        List<string> targetButtonNames = new List<string>();

        if (GameController.Instance.player.GetEnableOutline().GetTargetTag() == "Enemy")
        {
            targetButtonNames.Add(searchButton);
            targetButtonNames.Add(cancelButton);

            SetCurrentButtons(btn, targetButtonNames);
        }
        else if (GameController.Instance.player.GetEnableOutline().GetOutLine().GetComponentInParent<Item>().GetItemType() == ItemType.Weapon
            || GameController.Instance.player.GetEnableOutline().GetOutLine().GetComponentInParent<Item>().GetItemType() == ItemType.Armor
            || GameController.Instance.player.GetEnableOutline().GetOutLine().GetComponentInParent<Item>().GetItemType() == ItemType.Helmet)
        {
            targetButtonNames.Add(getButton);
            targetButtonNames.Add(cancelButton);
            targetButtonNames.Add(equipButton);

            SetCurrentButtons(btn, targetButtonNames);
        }
        else if (GameController.Instance.player.GetEnableOutline().GetOutLine().GetComponentInParent<Item>().GetItemType() == ItemType.Container)
        {
            targetButtonNames.Add(getButton);
            targetButtonNames.Add(cancelButton);
            targetButtonNames.Add(equipButton);
            targetButtonNames.Add(searchButton);

            SetCurrentButtons(btn, targetButtonNames);
        }
        else if (GameController.Instance.player.GetEnableOutline().GetTargetTag() == "Item"
            || GameController.Instance.player.GetEnableOutline().GetOutLine().GetComponentInParent<Item>().GetItemType() == ItemType.HealItem
            || GameController.Instance.player.GetEnableOutline().GetOutLine().GetComponentInParent<Item>().GetItemType() == ItemType.item)
        {
            targetButtonNames.Add(getButton);
            targetButtonNames.Add(cancelButton);

            SetCurrentButtons(btn, targetButtonNames);
        }
    }

    private void SetCurrentButtons(Button btn, List<string> names)
    {
        foreach (string name in names)
        {
            if (btn.name == name)
            {
                currentBtnList.Add(btn);
                if (!btn.gameObject.activeSelf)
                    btn.gameObject.SetActive(true);
                return;
            }
        }

        btn.gameObject.SetActive(false);
    }


    private void SetCurrentButtons(Button btn, string str1, string str2, string str3, string str4)
    {
        if (btn.name != str1 && btn.name != str2 && btn.name != str3 && btn.name != str4)
        {
            btn.gameObject.SetActive(false);
        }
        else
        {
            currentBtnList.Add(btn);
            if (!btn.gameObject.activeSelf)
                btn.gameObject.SetActive(true);
        }
    }

    private void SetCurrentButtons(Button btn, string str1, string str2, string str3)
    {
        if (btn.name != str1 && btn.name != str2 && btn.name != str3)
        {
            btn.gameObject.SetActive(false);
        }
        else
        {
            currentBtnList.Add(btn);
            if (!btn.gameObject.activeSelf)
                btn.gameObject.SetActive(true);
        }
    }

    private void SetCurrentButtons(Button btn, string str1, string str2)
    {
        if (btn.name != str1 && btn.name != str2)
        {
            btn.gameObject.SetActive(false);
        }
        else
        {
            currentBtnList.Add(btn);
            if (!btn.gameObject.activeSelf)
                btn.gameObject.SetActive(true);
        }
    }

    /// <summary>
    /// Enter current button using mouse wheel
    /// </summary>
    public void OnPointerEnter(float input)
    {
        if(input > 0f && currentSelectedIndex > 0)
        {
            currentSelectedIndex--;
        }
        else if(input < 0f && currentSelectedIndex < currentBtnList.Count - 1)
        {
            currentSelectedIndex++;
        }

        EnableCurrentButton();
    }

    /// <summary>
    /// Click current button
    /// </summary>
    // have to change later
    public void ClickCurrentButton()
    {
        EnableOutline component = GameController.Instance.GetEnableOutline();
        GameObject itemGO = component.GetRayPoint().transform.gameObject;
        Item item = itemGO.GetComponentInParent<Item>();
        string currentSelected = currentBtnList[currentSelectedIndex].gameObject.name;
        Inventory inventory = GameController.Instance.playerInventory;

        switch (currentSelected)
        {
            case "Btn_Get":
                CheckInventory checkInventory = GameController.Instance.player.GetComponent<CheckInventory>();
                checkInventory.PutItemOnInventory();
                break;

            case "Btn_Search":
                Container container = item.GetComponent<Container>();
                UIManager.Instance.DisableAllLootingObjects();

                // for inventory to do
                if(container == null)
                {
                    
                }
                else if (container.type == ContainerType.Rig)
                {
                    UIManager.Instance.targetRigUI.SetActive(true);
                    UIManager.Instance.targetRigUI.GetComponent<ContainerUI>().SetContainerUI(container);
                    foreach(var grid in container.gridList)
                    {
                        grid.gameObject.SetActive(true);
                    }
                }
                else if(container.type == ContainerType.BackPack)
                {
                    UIManager.Instance.targetBackPackUI.SetActive(true);
                    UIManager.Instance.targetBackPackUI.GetComponent<ContainerUI>().SetContainerUI(container);
                    foreach (var grid in container.gridList)
                    {
                        grid.gameObject.SetActive(true);
                    }
                }

                GameController.Instance.input.ProcessInventoryOpen();
                break;

            case "Btn_Equip":
                //foreach(var icon in item.itemUIIcon.GetComponentsInChildren<Transform>())
                //{
                //    icon.gameObject.layer = LayerMask.NameToLayer("UI");
                //}
                if (item.HasWeapon())
                {
                    EquipWeapon(item, inventory);
                }
                else if (item.itemType == ItemType.Container)
                {
                    inventory.EquipContainer(item);
                }
                else if(item.itemType == ItemType.Helmet
                    || item.itemType == ItemType.Armor)
                {
                    inventory.EquipArmors(item);
                }
                break;

            case "Btn_Cancel":
                
                break;
        }
        gameObject.SetActive(false);
    }

    private void EquipWeapon(Item item, Inventory inventory)
    {
        WeaponDetails details = item.GetComponent<WeaponDetails>();

        if (details.weaponType >= WeaponType.HandGun_01 && details.weaponType <= WeaponType.HandGun_04)
        {
            inventory.CheckSlots(WeaponSlotType.Pistol, item);
        }
        else if (details.weaponType == WeaponType.None)
        {

        }
        else
        {
            inventory.CheckSlots(WeaponSlotType.Weapon1, item);
        }
    }

    
    /// <summary>
    /// Set world position to UI position
    /// </summary>
    public void SetPosition(Vector3 worldPosiiton)
    {
        Vector3 uiPosition = Camera.main.WorldToScreenPoint(worldPosiiton);

        rectTransform.anchoredPosition = Vector2.zero;

        //transform.position = uiPosition;
    }

    /// <summary>
    /// Enable only current button
    /// </summary>
    private void EnableCurrentButton()
    {
        if (currentBtnList.Count == 0) return;

        foreach (var btn in currentBtnList)
        {
            btn.OnPointerExit(pointer);
        }
        
        currentBtnList[currentSelectedIndex].OnPointerEnter(pointer);
    }

    /// <summary>
    /// Get Children
    /// </summary>
    private void GetChildren()
    {
        btnList.Clear();

        for (int i = 0; i < transform.childCount; i++)
        {
            btnList.Add(transform.GetChild(i).GetComponent<Button>());
        }
    }

    
}

