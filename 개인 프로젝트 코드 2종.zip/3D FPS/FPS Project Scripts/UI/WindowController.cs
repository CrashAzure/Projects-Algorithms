using InfimaGames.LowPolyShooterPack;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using Unity.VisualScripting;

public class WindowController : MonoBehaviour
{
    [SerializeField]
    private float space = 128f;
    private List<RectTransform> uiList = new List<RectTransform>();
    private RectTransform rect;

    public RectTransform mainRect;

    void OnEnable()
    {
        transform.SetAsLastSibling();

        if(rect == null)
        {
            //currentEvent = EventSystem.current;
            //pointer = new PointerEventData(currentEvent);
            rect = GetComponent<RectTransform>();
            return;
        }

        rect.position = Input.mousePosition;

        uiList.Clear();
        Image[] images = GetComponentsInChildren<Image>();
        RectTransform[] rects = new RectTransform[images.Length];

        for (int i = 0; i < images.Length; i++)
        {
            rects[i] = images[i].GetComponent<RectTransform>();
        }

        uiList.AddRange(rects);

        RectTransform minXRect = null;
        RectTransform minYRect = null;
        RectTransform maxXRect = null;
        RectTransform maxYRect = null;

        float maxHeight = 0f;
        float maxWidth = 0f;
        float tempHeight = 0f;
        float tempWidth = 0f;

        ContainerUI ui = GetComponent<ContainerUI>();

        for (int i = 0; i < ui.gridList.Count; i++)
        {
            if (i % ui.currentContainerDetail.width == 0)
            {
                tempWidth = 0f;
                maxHeight += tempHeight;
                tempHeight = ui.gridList[i].height;
            }
            if (ui.gridList[i].height > maxHeight)
            {
                tempHeight = ui.gridList[i].height;
            }

            tempWidth += ui.gridList[i].width;

            if (i % ui.currentContainerDetail.width == ui.currentContainerDetail.width - 1)
            {
                if (maxWidth < tempWidth)
                {
                    maxWidth = tempWidth;
                }
            }
        }

        //for (int i = 0; i < ui.currentContainerDetail.width; i++)
        //{
        //    for(int j = 0; j < ui.currentContainerDetail.height; j++ )
        //    {

        //    }
        //    if (i % ui.currentContainerDetail.width == 0)
        //    {
        //        maxWidth = 0f;
        //        maxHeight += tempHeight;
        //        tempHeight = ui.gridList[i].height;
        //    }
        //    if (ui.gridList[i].height > maxHeight)
        //    {
        //        tempHeight = ui.gridList[i].height;
        //    }

        //    tempWidth += ui.gridList[i].width;

        //    if (i % ui.currentContainerDetail.width == ui.currentContainerDetail.width - 1)
        //    {
        //        if (maxWidth < tempWidth)
        //        {
        //            maxWidth = tempWidth;
        //        }
        //    }
        //}


        foreach (RectTransform rect in uiList)
        {
            //if (rect == this.rect
            //    || rect.name == "ControlBar"
            //    || rect.name == "ExitButton"
            //    || rect == mainRect) continue;

            if (rect.GetComponent<GridNode>() == null) continue;

            if(maxHeight <= rect.sizeDelta.y)
            {
                maxHeight = rect.sizeDelta.y;
            }

            if (minXRect == null || minXRect.position.x > rect.position.x)
            {
                minXRect = rect;
            }

            if (minYRect == null || minYRect.position.y > rect.position.y)
            {
                minYRect = rect;
            }

            if (maxXRect == null || maxXRect.position.x < rect.position.x)
            {
                maxXRect = rect;
            }

            if (maxYRect == null || maxYRect.position.y < rect.position.y)
            {
                maxYRect = rect;
            }
        }

        //float width = maxXRect.position.x - minXRect.position.x + (maxXRect.sizeDelta.x + minXRect.sizeDelta.x) / 2;
        //float height = maxYRect.position.y - minYRect.position.y + (maxYRect.sizeDelta.y + minYRect.sizeDelta.y) / 2;
        float width = maxWidth * 64f;
        float height = maxHeight;

        Vector2 center = new Vector2(maxXRect.position.x + minXRect.position.x, maxYRect.position.y + minYRect.position.y) / 2f;

        //Vector2 gap = new Vector2(rect.position.x, rect.position.y) - center;

        //for (int i = 1; i < uiList.Count; ++i)
        //{
        //    uiList[i].position += new Vector3(gap.x, gap.y, 0);
        //}

        width += space;
        height += space;

        rect.sizeDelta = new Vector2(width, height);

        foreach (var rect in GetComponentsInChildren<RectTransform>())
        {
            if (rect.name == "ControlBar"
                || rect.GetComponent<GridNode>() != null
                || rect.name == "ExitButton")
            {
                //rect.anchoredPosition = new Vector3(0f, 0f, 0f);
            }
        }

        //mainRect.anchoredPosition = new Vector3(0, -space * 0.625f);
        mainRect.anchoredPosition = new Vector3(0, -80f);
        mainRect.sizeDelta = new Vector2(width * 0.9f, height - space);

        if (mainRect.GetComponentsInChildren<GridNode>().Length == 0) return;

        float mainRectWidth = 0f;

        foreach (var grid in mainRect.GetComponentsInChildren<GridNode>())
        {
            if (rect == mainRect) continue;
            mainRectWidth += grid.GetComponent<RectTransform>().sizeDelta.x;
        }

        mainRect.sizeDelta = new Vector2(mainRectWidth, height - space);
    }

    public void ExitWindow()
    {
        GetComponentInChildren<GridNode>().container.GetComponent<Item>().itemUIIcon.isInspecting = false;
            
        gameObject.SetActive(false);
    }
}
