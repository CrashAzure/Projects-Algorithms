using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuButtons : MonoBehaviour
{
    public void StartItemSpawnerScene()
    {
        Settings();
        Invoke("Load1", 2.5f);
    }

    public void StartWeatherTestScene()
    {
        Settings();
        Invoke("Load2", 2.5f);
    }

    public void StartCombatTestScene()
    {
        Settings();
        Invoke("Load3", 2.5f);
    }

    public void ExitGame()
    {
        Application.Quit();
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }

    private void Load1()
    {
        SceneManager.LoadSceneAsync(1, LoadSceneMode.Additive);
    }

    private void Load2()
    {
        SceneManager.LoadSceneAsync(2, LoadSceneMode.Additive);
    }

    private void Load3()
    {
        SceneManager.LoadSceneAsync(3, LoadSceneMode.Additive);
    }

    private void Settings()
    {
        UIManager.Instance.loadingUI.FadeLoading(0f, 1f, 0f, 0f, Color.black);
        SetStatus();
        DisableMainMenu();
        EnableInGameUI();
        SetInGameCursor();
    }
    private void DisableMainMenu()
    {
        UIManager.Instance.mainUIButtons.gameObject.SetActive(false);
        UIManager.Instance.titleImage.gameObject.SetActive(false);
    }

    private void EnableInGameUI()
    {
        UIManager.Instance.weaponStatusUI.gameObject.SetActive(true);
        UIManager.Instance.playerStatusUI.gameObject.SetActive(true);
    }

    private void SetStatus()
    {
        GameController.Instance.player.playerStatus.isInGame = true;
        StaticManager.Instance.mainMenuObjects.SetActive(false);
    }

    private void SetInGameCursor()
    {
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;
    }


}
