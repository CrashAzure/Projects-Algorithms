using UnityEngine;

public class UIController : MonoBehaviour
{
    public void Exit()
    {
        GridNode node = GetComponentInChildren<GridNode>();

        if (node != null)
        {
            node.container.GetComponent<Item>().itemUIIcon.isInspecting = false;
        }

        gameObject.SetActive(false);
    }

}
