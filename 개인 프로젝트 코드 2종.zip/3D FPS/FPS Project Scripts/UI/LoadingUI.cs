using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class LoadingUI : MonoBehaviour
{
    [SerializeField] private FadeUI fadeUI;
    private TextMeshProUGUI textMeshPro;
    private String fullText;

    private Coroutine fadeCoroutine;
    private Coroutine writeCoroutine;
    private Coroutine playCoroutine;
    public void SetTest(string text)
    {
        textMeshPro.text = text;
    }

    public void FadeLoading(float startFadeAlpha, float targetFadeAlpha, float delaySeconds, float fadeSeconds, Color backgroundColor)
    {
        if(textMeshPro == null)
        {
            textMeshPro = GetComponentInChildren<TextMeshProUGUI>();
            fullText = textMeshPro.text;
            fadeUI = UIManager.Instance.fadeUI;
        }
        if (!gameObject.activeSelf)
        {
            gameObject.SetActive(true);
        }

        if (!fadeUI.gameObject.activeSelf)
        {
            fadeUI.gameObject.SetActive(true);
        }

        if(fadeCoroutine != null || writeCoroutine != null)
        {
            StopAllCoroutines();
            fadeCoroutine = null;
            writeCoroutine = null;
        }
        bool isIncrease = startFadeAlpha <= targetFadeAlpha;
        fadeUI.FadeInAndOut(fadeSeconds, delaySeconds, isIncrease);
        writeCoroutine = StartCoroutine(WriteTextCoroutine(delaySeconds + fadeSeconds, result => textMeshPro.text = result, 3));
    }

    /// <summary>
    /// Write text coroutine
    /// </summary>
    public IEnumerator WriteTextCoroutine(float processTime, Action<string> targetText, int targetIndex, float delayTime = 0f, bool isRepeat = true)
    {
        // delay this coroutine if delaytime is not zero
        if (delayTime != 0f)
        {
            yield return new WaitForSeconds(delayTime);
        }

        float writeTimer = 0;
        int writeIndex = targetIndex;
        float time = 0;

        // Return here for process time
        while (time <= processTime)
        {
            time += Time.deltaTime;
            writeTimer += Time.deltaTime;

            WriteText(targetIndex, processTime, fullText, targetText, ref writeTimer, ref writeIndex, isRepeat);

            yield return null;
        }
    }

    /// <summary>
    /// Write Text once a cycle
    /// </summary>
    private void WriteText(int targetIndex, float processTime, string fullText, Action<string> targetText, ref float writeTimer, ref int writeIndex, bool isRepeat = true)
    {
        float writingSpeed = 0.2f;

        // Fit writing speed using process time and text length
        if (!isRepeat)
        {
            writingSpeed = processTime / fullText.Length;
            writingSpeed *= 0.7f;
        }

        // Check cycle with caculated writing speed
        if (writeTimer <= writingSpeed) return;

        // Only one process if we dont wanna repeat this
        // else keep going
        if (writeIndex < 0)
        {
            if (!isRepeat) return;

            writeIndex = targetIndex;
        }

        // Set result value of one coroutine cycle to delegate
        targetText(fullText.Substring(0, fullText.Length - writeIndex));

        // Initialise timer
        writeTimer = 0;
        // Update index
        writeIndex--;

    }
}
