using UnityEngine;

public class GridNode : MonoBehaviour
{
    private int cellSize = 64;
    private RectTransform rect;

    public Container container;

    public int width = 1;
    public int height = 1;

    public int[,] gridArray;

    private void OnEnable()
    {
        if(rect == null)
            rect = GetComponent<RectTransform>();
    }

    private void Update()
    {
        if (container == null)
        {
            Destroy(gameObject);
        }

        if (transform.localScale != Vector3.one)
        {
            transform.localScale = Vector3.one;
        }
    }

    //private void Update()
    //{
    //    if(transform.parent != null)
    //    {
    //        if (transform.parent.GetComponent<WindowController>() == null)
    //        {
    //            if (rect.anchorMin != new Vector2(0.5f, 0.5f))
    //            {
    //                rect.anchorMin = new Vector2(0.5f, 0.5f);
    //                rect.anchorMax = new Vector2(0.5f, 0.5f);
    //                rect.pivot = new Vector2(0.5f, 0.5f);
    //            }
    //        }
    //        else
    //        {
    //            if (rect.anchorMin != new Vector2(0f, 1f))
    //            {
    //                rect.anchorMin = new Vector2(0f, 1f);
    //                rect.anchorMax = new Vector2(0f, 1f);
    //                rect.pivot = new Vector2(0f, 1f);
    //            }
    //        }
    //    }

    //}

    public void SetGridNodeInfo(Vector2Int bounds)
    {
        this.width = bounds.x;
        this.height = bounds.y;

        InitializeGridArray();
    }

    public void InitializeGridArray()
    {
        if(gridArray == null)
        {
            gridArray = new int[width, height];
            rect.sizeDelta = new Vector2(cellSize * width, cellSize * height);
            transform.localScale = Vector3.one;
        }
    }

    public void SetGridForItem(Vector2Int anchor, Item item, int index)
    {
        Vector2Int size = item.GetSize();
        ItemUIIcon icon = item.itemUIIcon.GetComponent<ItemUIIcon>();
        GridNode parentNode = GetComponentInParent<GridNode>(true);

        icon.SetToIntFromOutside(parentNode);
        icon.SetGridItemArray(index);
        

        //if (icon.isRotate) 
        //{
        //    for(int i = 0; i< size.y; i++)
        //    {
        //        for (int j = 0; j < size.x; j++)
        //        {
        //            gridArray[anchor.x + i, anchor.y + j] = index;
        //        }
        //    }
        //}
        //else
        //{
        //    for (int i = 0; i < size.x; i++)
        //    {
        //        for (int j = 0; j < size.y; j++)
        //        {
        //            gridArray[anchor.x + i, anchor.y + j] = index;
        //        }
        //    }
        //}
    }

    /// <summary>
    /// Check this grid node
    /// </summary>
    public (bool, Vector2Int) CheckGridNode(Item item)
    {
        bool result = false;
        bool checkDone = false;
        Vector2Int anchor = Vector2Int.zero;
        int count = 0;

        while (!checkDone && !result && count <= 10000)
        {
            result = CheckArea(item, ref anchor, ref checkDone);
            count++;
        }

        ItemUIIcon icon = item.itemUIIcon.GetComponent<ItemUIIcon>();

        //if (icon.isRotate && icon.height % 2 == 0)
        //{
        //    anchor.x += item.GetSize().y;
        //}

        return (result, anchor);
    }

    private bool CheckArea(Item item, ref Vector2Int anchor ,ref bool checkDone)
    {
        bool canPlace = true;
        Vector2Int size = item.GetSize();
        ItemUIIcon icon = item.itemUIIcon.GetComponent<ItemUIIcon>();

        if (icon.isRotate)
        {
            if (anchor.x + size.y - 1 >= width)
            {
                anchor.x = 0;
                anchor.y++;

                if (anchor.y + size.x - 1 >= height)
                {
                    checkDone = true;
                    icon.isRotate = false;
                }

                return false;
            }

            if (anchor.y + size.x - 1 >= height)
            {
                checkDone = true;
                icon.isRotate = false;
                return false;
            }
        }
        else
        {
            if (anchor.x + size.x - 1 >= width)
            {
                anchor.x = 0;
                anchor.y++;
                if (anchor.y + size.y - 1 >= height)
                {
                    icon.isRotate = true;
                    anchor = Vector2Int.zero;
                }
                return false;
            }

            if (anchor.y + size.y - 1 >= height)
            {
                if (size.x == size.y)
                {
                    checkDone = true;
                    return false;
                }
                icon.isRotate = true;
                anchor = Vector2Int.zero;
                return false;
            }
        }

        int amount = 0;

        if (!icon.isRotate)
        {
            for (int i = 0; i < size.x; i++)
            {
                for (int j = 0; j < size.y; j++)
                {
                    if (gridArray[anchor.x + i, anchor.y + j] != 0)
                    {
                        if (amount < i + 1)
                            amount = i + 1;
                        
                        if (canPlace) canPlace = false;
                    }
                }
            }
        }
        else
        {
            for (int i = 0; i < size.y; i++)
            {
                for (int j = 0; j < size.x; j++)
                {
                    if (gridArray[anchor.x + i, anchor.y + j] != 0)
                    {
                        if (amount < i + 1)
                            amount = i + 1;

                        if (canPlace) canPlace = false;
                    }
                }
            }
        }

        anchor.x += amount;
        return canPlace;
    }

    public int[,] GetGridArray() => gridArray;

}
