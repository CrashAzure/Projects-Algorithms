using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System;

public class ItemUIIcon : MonoBehaviour,
                          IBeginDragHandler, 
                          IEndDragHandler,
                          IDragHandler
{
    #region Parameters
    private InventoryUI inventoryUI;
    private Transform prevParent;
    [HideInInspector]
    public RectTransform rect;
    private Transform tileDefaultParent;
    [HideInInspector]
    public Image icon;
    [HideInInspector]
    public Container container;
    
    private EventSystem currentEvent;
    private PointerEventData pointer;
    private GraphicRaycaster raycaster;

    private Vector2 defaultPosition;
    private Vector3 defaultEulerAngle;

    private bool onDragging = false;
    private bool onGridNode = false;
    public bool ableToSet = false;
    private bool prevRotate = false;
    public bool isInspecting = false;
    public bool isRotate = false;
    public int width = 0;
    public int height = 0;
    public int index = 1;
    private int prevXPos = 0;
    private int prevYPos = 0;
    private int currentXPos;
    private int currentYPos;
    private Vector3 prevScaleVec = Vector3.zero;

    private Color backgroundColor = new Color(0.3f, 0.7f, 0.8f, 0.7f);
    private Color weaponColor = new Color(0.8f, 0.8f, 0.8f, 0.7f);
    private Color containerColor = new Color(0.5f, 0.7f, 0.4f, 0.7f);
    private Color healItemColor = new Color(0.93f, 0.5f, 0.93f, 0.7f);
    private Color armorColor = new Color(0.5f, 0.93f, 0.93f, 0.7f);
    private Color otherColor = new Color(0.3f, 0.7f, 0.8f, 0.7f);
    private Color enableColor = new Color(0.2f, 1f, 0.2f, 0.7f);
    private Color disableColor = new Color(1f, 0.2f, 0.2f, 0.7f);

    public Item item;

    [HideInInspector]
    public List<Tile> tileList = new List<Tile>();

    #endregion Parameters

    #region Unity
    private void Awake()
    {
        currentEvent = EventSystem.current;
        pointer = new PointerEventData(currentEvent);
        inventoryUI = GetComponentInParent<InventoryUI>();
        rect = GetComponent<RectTransform>();
        if(icon == null)
            icon = GetComponentInChildren<Image>(true);

        raycaster = UIManager.Instance.canvas.GetComponent<GraphicRaycaster>();
    }

    private void Start()
    {
        tileDefaultParent = PoolManager.Instance.transform.Find("TileAnchor");
    }

    private void Update()
    {
        if (onDragging)
        {
            RotateIcon();
        }

        if(transform.localScale != Vector3.one)
        {
            if (item.itemType == ItemType.Container && item.GetComponent<Container>().isEquieped) return;

            transform.localScale = Vector3.one;
        }
    }
    #endregion Unity

    #region Event
    public void OnBeginDrag(PointerEventData eventData)
    {
        //SetTilesFromObjectPool();
        UIManager.Instance.selectedIcon = this;
        prevScaleVec = rect.localScale;
        InitIconScale();
        onDragging = true;
        ableToSet = false;
        prevParent = transform.parent;
        defaultPosition = transform.position;
        defaultEulerAngle = transform.localEulerAngles;

        if (transform.parent.GetComponent<GridNode>() != null)
        {
            SetGridItemArray(0);
            prevXPos = currentXPos;
            prevYPos = currentYPos;
        }

        foreach(var tile in tileList)
        {
            if (!tile.gameObject.activeSelf)
            {
                tile.gameObject.SetActive(true);
            }
        }

        transform.localPosition += Vector3.forward;
        transform.SetParent(UIManager.Instance.canvas.transform);
        transform.SetAsLastSibling();
    }


    public void OnDrag(PointerEventData eventData)
    {
        transform.position = new Vector3(eventData.position.x, eventData.position.y, transform.position.z);

        List<RaycastResult> rayList = new List<RaycastResult>();

        //currentEvent.RaycastAll(eventData, rayList);
        raycaster.Raycast(eventData, rayList);

        foreach (RaycastResult ray in rayList)
        {
            ItemUIIcon icon = ray.gameObject.transform.parent.GetComponent<ItemUIIcon>();

            if (icon != null && icon.item.GetItemType() == ItemType.Container && icon != this)
            {
                CheckContainer(icon);
                onGridNode = false;
                break;
            }

            WeaponSlotUI weaponSlot = ray.gameObject.GetComponent<WeaponSlotUI>();

            if (weaponSlot != null)
            {
                if (weaponSlot.slot.itemList.Count == 0f && item.GetComponent<WeaponController>() != null)
                {
                    bool isPistol = ((item.GetWeaponType() >= WeaponType.HandGun_01 && item.GetWeaponType() <= WeaponType.HandGun_04)
                        && weaponSlot.type == WeaponSlotType.Pistol);
                    bool isWeapon = (!(item.GetWeaponType() >= WeaponType.HandGun_01 && item.GetWeaponType() <= WeaponType.HandGun_04)
                        && weaponSlot.type != WeaponSlotType.Pistol);

                    if ((isPistol || isWeapon)
                        && weaponSlot.type != WeaponSlotType.Melee)
                    {
                        SetAllTileColor(enableColor);
                    }
                    else
                    {
                        SetAllTileColor(disableColor);
                    }
                }
                else
                {
                    SetAllTileColor(disableColor);
                }
                break;
            }

            ContainerUI containerUI = ray.gameObject.transform.parent.GetComponent<ContainerUI>();

            if (containerUI != null && item.GetItemType() == ItemType.Container)
            {
                if (GameController.Instance.playerInventory.CheckContainerCanEquip(item))
                {
                    SetAllTileColor(enableColor);
                }
                else
                {
                    SetAllTileColor(disableColor);
                }
                break;
            }

            GridNode node = ray.gameObject.GetComponent<GridNode>();

            if (node != null)
            {
                SetToInt(node);
                break;
            }

        }

        onGridNode = false;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        onDragging = false;
        UIManager.Instance.selectedIcon = null;

        List<RaycastResult> rayList = new List<RaycastResult>();

        raycaster.Raycast(eventData, rayList);

        foreach (RaycastResult ray in rayList)
        {
            GridNode node = ray.gameObject.GetComponent<GridNode>();

            if (node != null) break;

            ItemUIIcon icon = ray.gameObject.transform.parent.GetComponent<ItemUIIcon>();
            if (icon != null && icon.item.GetItemType() == ItemType.Container && icon != this)
            {
                CheckContainer(icon, true);
                return;
            }

            ContainerUI containerUI = ray.gameObject.transform.parent.GetComponent<ContainerUI>();

            if(containerUI != null && item.GetItemType() == ItemType.Container)
            {
                GameController.Instance.playerInventory.EquipContainer(item);
                containerUI.SetContainerUI(item.GetComponent<Container>());
                return;
            }

            if (CheckWeaponSlot(ray)) return;
        }

        ReturnToDefault();

        DisableAllTiles();
    }
    #endregion Event

    #region Method
    /// <summary>
    /// Check Weapon Slot and UI
    /// </summary>
    private bool CheckWeaponSlot(RaycastResult ray)
    {
        WeaponSlotUI weaponSlot = ray.gameObject.GetComponent<WeaponSlotUI>();

        if (weaponSlot != null)
        {
            if (weaponSlot.slot.itemList.Count == 0f)
            {
                if (!CheckAllTileEnable()) return false;
                Container prevContainer = transform.parent.GetComponent<GridNode>()?.container;

                // Set item parent
                item.GetComponent<WeaponStatus>().isEquiped = true;
                item.transform.SetParent(weaponSlot.slot.transform);

                // Set icon parent
                transform.SetParent(weaponSlot.transform);
                rect.anchoredPosition = Vector2.zero;

                // Update index
                if (prevContainer!= null)
                {
                    prevContainer.UpdateItemIndex();
                }

                isRotate = false;
                RotateIcon();

                // Reset Background Color and rotate
                SetAllTileColor(weaponColor);
                weaponSlot.slot.UpdateItemIndex();
                weaponSlot.InitWeaponSlotUI();
                rect.anchoredPosition = -icon.rectTransform.anchoredPosition;
                return true;
            }
        }
        return false;
    }
    private void SetAllTileColor(Color color)
    {
        foreach (Tile tile in tileList)
        {
            tile.GetComponent<Image>().color = color;
        }
    }
    public void SetInfo(Sprite iconImage, int width, int height)
    {
        switch (item.GetItemType())
        {
            case ItemType.Weapon:
                backgroundColor = weaponColor;
                break;
            case ItemType.HealItem:
                backgroundColor = healItemColor;
                break;
            case ItemType.Helmet:
            case ItemType.Armor:
                backgroundColor = armorColor;
                break;
            case ItemType.Container:
                backgroundColor = containerColor;
                break;
            default:
                backgroundColor = otherColor;
                break;
        }

        icon = GetComponentInChildren<Image>(true);
        icon.SetNativeSize();

        float ratio = iconImage.rect.size.x / iconImage.rect.size.y;

        float widthResult = width * 64f;
        float heightResult = height * 64f;

        //if (height == 1 || item.GetItemType() != ItemType.Weapon)
        //{
        //    icon.rectTransform.sizeDelta = new Vector2(heightResult * ratio, heightResult);
        //}
        //else
        //{
        //    icon.rectTransform.sizeDelta = new Vector2(widthResult, heightResult);
        //}
        if (item.GetItemType() == ItemType.Weapon)
        {
            if (height != 1)
            {
                icon.rectTransform.sizeDelta = new Vector2(widthResult, heightResult);
            }
            else
            {
                icon.rectTransform.sizeDelta = new Vector2(heightResult * ratio, heightResult);
            }
        }
        else if (height <= width)
        {
            icon.rectTransform.sizeDelta = new Vector2(widthResult, widthResult / ratio);
        }
        else
        {
            icon.rectTransform.sizeDelta = new Vector2(heightResult * ratio, heightResult);
        }

        while (true)
        {
            if(item.GetItemType() == ItemType.Weapon) break;

            if (icon.rectTransform.sizeDelta.x > widthResult)
            {
                icon.rectTransform.sizeDelta = new Vector2(icon.rectTransform.sizeDelta.x - 2f, (icon.rectTransform.sizeDelta.x - 2f) / ratio);
                continue;
            }

            if (icon.rectTransform.sizeDelta.y > heightResult)
            {
                icon.rectTransform.sizeDelta = new Vector2((icon.rectTransform.sizeDelta.y - 2f) * ratio, icon.rectTransform.sizeDelta.y - 2f);
                continue;
            }

            break;
        }

        if (width % 2 == 0)
        {
            icon.rectTransform.anchoredPosition += Vector2.left * 32f;
        }
        if (height % 2 == 1)
        {
            icon.rectTransform.anchoredPosition += Vector2.down * 32f;
        }
        SetIcon(iconImage);
        this.width = width;
        this.height = height;

        SetTilesFromObjectPool();
    }


    private void CheckContainer(ItemUIIcon icon, bool isPut = false)
    {
        Container targetContainer = icon.item.GetComponent<Container>();
        (bool, Vector2Int, GridNode) result = targetContainer.ProcessCheckInventory(item);

        Color resultColor;

        if (result.Item1)
        {
            resultColor = enableColor;

            if (isPut)
            {
                MoveItemToOtherContainer(result, targetContainer, ref resultColor);
            }
        }
        else
        {
            resultColor = disableColor;

            if (isPut)
            {
                ReturnToDefault();
                DisableAllTiles();
                return;
            }
        }

        foreach (Tile tile in tileList)
        {
            tile.GetComponent<Image>().color = resultColor;
        }
    }

    private void MoveItemToOtherContainer((bool, Vector2Int, GridNode) result, Container targetContainer, ref Color resultColor)
    {
        targetContainer.PutItem(item);
        gameObject.SetActive(true);
        SetSize(item.GetSize().x, item.GetSize().y);
        SetPosFromOutSideOfUI(result.Item2);
        result.Item3.SetGridForItem(result.Item2, item, targetContainer.itemList.Count);
        container = targetContainer;
        item.container = targetContainer;
        item.transform.SetParent(container.transform, false);

        container.UpdateItemIndex();
        if (prevParent.GetComponentInParent<GridNode>() != null)
        {
            prevParent.GetComponentInParent<GridNode>().container.UpdateItemIndex();
        }
        else if(prevParent.GetComponent<WeaponSlotUI>() != null)
        {
            WeaponSlotUI slotUI = prevParent.GetComponent<WeaponSlotUI>();
            slotUI.slot.UpdateItemIndex();
            slotUI.InitWeaponSlotUI();

            if (slotUI.slot.GetComponentInParent<Player>() != null)
            {
                if(GameController.Instance.playerInventory.currentWeapon == item.GetComponent<WeaponController>())
                {
                    GameController.Instance.playerInventory.currentWeapon = null;
                    GameController.Instance.input.isHolstered = true;
                }
            }
        }
        index = targetContainer.itemList.Count;

        item.gameObject.SetActive(false);
        resultColor = backgroundColor;
    }

    public void SetPosFromOutSideOfUI(Vector2Int anchor)
    {
        if (isRotate)
        {
            currentXPos = anchor.x + Mathf.FloorToInt(height / 2f);
            currentYPos = -anchor.y - Mathf.FloorToInt(width / 2f) - 1;

            if (width % 2 == 0) currentYPos++;
        }
        else
        {
            currentXPos = anchor.x + Mathf.FloorToInt(width / 2f);
            currentYPos = -anchor.y - Mathf.FloorToInt(height / 2f);
        }

    }
    public void SetSize(int width, int height)
    {
        this.width = width;
        this.height = height;
    }

    private void SetTilesFromObjectPool()
    {
        tileList.Clear();

        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                GameObject tilePrefab = Resources.Load<GameObject>("Tile");
                //Tile tileImage = (Tile)PoolManager.Instance.ReuseComponent(tilePrefab, Vector3.zero, Quaternion.identity);
                Tile tileImage = Instantiate(tilePrefab).GetComponent<Tile>();
                tileList.Add(tileImage);
                tileImage.GetComponent<Image>().color = backgroundColor;
                tileImage.transform.SetParent(transform);
                tileImage.transform.localPosition = new Vector3((i - (int)(width / 2)) * 64f, ((int)(height / 2) - j) * 64f - 32f, 0f);
                tileImage.gameObject.SetActive(true);
            }
        }
        icon.transform.SetAsLastSibling();
    }



    private void ReturnToDefault()
    {
        if (CheckAllTileEnable())
        {
            ableToSet = false;

            if (item.GetItemType() == ItemType.Container)
            {
                foreach (var grid in item.GetComponent<Container>().gridList)
                {
                    grid.gameObject.SetActive(false);
                }
                if (item.GetComponent<Container>().isEquieped)
                {
                    item.GetComponent<Container>().isEquieped = false;
                    item.GetComponentInParent<Inventory>().SetContainers();
                }
            }

            if (item.GetComponent<WeaponStatus>() != null)
            {
                if (item.GetComponent<WeaponController>() == item.GetComponentInParent<Inventory>(true).currentWeapon)
                {
                    item.GetComponentInParent<Inventory>(true).currentWeapon = null;
                }
                item.GetComponent<WeaponStatus>().isEquiped = false;
            }

            Container prevContainer = this.container;
            WeaponSlotUI slot = prevParent.GetComponent<WeaponSlotUI>();
            SetGridItemArray(index);
            Container container = GetComponentInParent<GridNode>(true).container;
            this.container = container;
            item.transform.SetParent(container.transform);

            container.UpdateItemIndex();

            if(slot != null)
            {
                slot.slot.UpdateItemIndex();
                slot.InitWeaponSlotUI();

                if(slot.slot.GetComponentInParent<Player>() != null
                    && GameController.Instance.playerInventory.currentWeapon == item.GetComponent<WeaponController>())
                {
                    GameController.Instance.input.isHolstered = true;
                }
            }
            else if(prevContainer != null)
            {
                prevContainer.UpdateItemIndex();
            }
            
            
        }
        else
        {
            transform.SetParent(prevParent);
            transform.position = defaultPosition;
            transform.localEulerAngles = defaultEulerAngle;
            rect.localScale = prevScaleVec;

            if(GetComponentInParent<ContainerUI>() != null)
            {
                ContainerUI ui = GetComponentInParent<ContainerUI>();
                ui.SetContainerUI();
            }
        
            if(defaultEulerAngle == Vector3.zero)
            {
                isRotate = false;
            }
            else
            {
                isRotate = true;
            }
            
            currentXPos = prevXPos;
            currentYPos = prevYPos;

            if(prevParent.GetComponent<GridNode>() != null)
            {
                SetGridItemArray(index);
            }
        }
    }

    public void SetGridItemArray(int itemID)
    {
        GridNode parentNode = GetComponentInParent<GridNode>(true);

        int anchoredWidth = Mathf.FloorToInt(width / 2f);
        int anchoredHeight = Mathf.FloorToInt(height / 2f);

        for (int i = -anchoredWidth; i < width - anchoredWidth; i++)
        {
            for (int j = -anchoredHeight; j < height - anchoredHeight; j++)
            {
                int xPosOnGrid = 0;
                int yPosOnGrid = 0;

                if (isRotate)
                {
                    xPosOnGrid = j + currentXPos;
                    if (xPosOnGrid < 0) xPosOnGrid = 0;
                    yPosOnGrid = i + Mathf.Abs(currentYPos) - 1;
                    if (width % 2 == 0)
                        yPosOnGrid++;                     
                }
                else
                {
                    xPosOnGrid = i + currentXPos;
                    yPosOnGrid = j + Mathf.Abs(currentYPos);
                }

                if(parentNode != null)
                {
                    parentNode.gridArray[xPosOnGrid, yPosOnGrid] = itemID;
                }
            }
        }
    }

    public void DisableAllTiles()
    {
        foreach (Tile tile in tileList)
        {
            //tile.transform.SetParent(tileDefaultParent);
            //tile.gameObject.SetActive(false);
            tile.GetComponent<Image>().color = backgroundColor;
        }
    }

    public void SetToIntFromOutside(GridNode node)
    {
        transform.SetParent(node.transform);
        transform.rotation = Quaternion.identity;
        

        if (isRotate)
        {
            float amount = 32f;

            rect.localPosition = new Vector3(currentXPos * 64f, currentYPos * 64f + amount, 0f);
            transform.localEulerAngles = new Vector3(0f, 0f, 90f);
        }
        else
        {
            rect.localPosition = new Vector3(currentXPos * 64f + 32f, currentYPos * 64f, 0f);
            transform.localEulerAngles = Vector3.zero;
        }
    }

    private void InitIconScale()
    {
        transform.localScale = Vector3.one;
    }

    public void InitIcon()
    {
        InitIconScale();

        isRotate = false;
        rect.rotation = Quaternion.identity;
        index = 0;
        rect.anchoredPosition = Vector2.zero;
        gameObject.SetActive(false);
        transform.SetParent(null, false);
    }

    private void SetToInt(GridNode node)
    {
        if (node == null || node.container.GetComponent<Item>() == item) 
        {
            if (!onGridNode)
            {
                SetAllTilesToRed();
            }
            return; 
        }

        onGridNode = true;

        ableToSet = true;

        transform.SetParent(node.transform);

        float xPosGap = Mathf.Abs(rect.localPosition.x / 64f - Mathf.CeilToInt(rect.localPosition.x / 64f));
        float yPosGap = Mathf.Abs(rect.localPosition.y / 64f - Mathf.CeilToInt(rect.localPosition.y / 64f));

        if (isRotate)
        {
            if(rect.localPosition.x < 0)
            {
                currentXPos = Mathf.CeilToInt((rect.localPosition.x + 32f) / 64f);
            }
            else
            {
                currentXPos = Mathf.FloorToInt((rect.localPosition.x + 32f) / 64f);
            }

            if (rect.localPosition.y < 0)
            {
                currentYPos = Mathf.CeilToInt(rect.localPosition.y / 64f) - 1;
            }
            else
            {
                currentYPos = Mathf.FloorToInt(rect.localPosition.y / 64f) - 1;
            }

            if (!CheckSetToGrid(isRotate)) return;

            rect.localPosition = new Vector3(currentXPos * 64f, currentYPos * 64f + 32f, 0f);
        }
        else
        {
            if (rect.localPosition.x < 0)
            {
                currentXPos = Mathf.CeilToInt(rect.localPosition.x / 64f);
            }
            else
            {
                currentXPos = Mathf.FloorToInt(rect.localPosition.x / 64f);
            }

            currentYPos = Mathf.RoundToInt((rect.localPosition.y + 32f) / 64f);

            if (!CheckSetToGrid(isRotate)) return;

            rect.localPosition = new Vector3(currentXPos * 64f + 32f, currentYPos * 64f, 0f);
        }

        
    }

    private void SetAllTilesToRed()
    {
        if (onGridNode) return;

        foreach (Tile tile in tileList)
        {
            tile.GetComponent<Image>().color = new Color(1, 0.2f, 0.2f, 0.7f);
        }
    }

    private bool CheckSetToGrid(bool isRotate)
    {
        SetTileColorOnGrid(isRotate);

        return CheckAllTileEnable();
    }

    private bool CheckAllTileEnable()
    {
        foreach (Tile tile in tileList)
        {
            if (tile.GetComponent<Image>().color.g < 0.8f)
            {
                ableToSet = false;
                return false;
            }
        }

        return true;
    }

    public void SetTileColorOnGrid(bool isRotate)
    {
        GridNode parentNode = GetComponentInParent<GridNode>(true);
        int anchoredWidth = Mathf.FloorToInt(width / 2f);
        int anchoredHeight = Mathf.FloorToInt(height / 2f);

        ableToSet = true;

        for (int i = -anchoredWidth; i <= width / 2f; i++)
        {
            for (int j = -anchoredHeight; j <= height / 2f; j++)
            {
                int xPosOnGrid;
                int yPosOnGrid;

                if (isRotate)
                {
                    xPosOnGrid = j + currentXPos - 1;
                    yPosOnGrid = i + Mathf.Abs(currentYPos) - 1;
                    if(width % 2 == 0)
                    {
                        yPosOnGrid++;
                    }
                    if(height % 2 == 1)
                    {
                        xPosOnGrid++;
                    }
                }
                else
                {
                    xPosOnGrid = i + currentXPos;
                    yPosOnGrid = j + Mathf.Abs(currentYPos);
                }

                if (xPosOnGrid < 0 || xPosOnGrid >= parentNode.width)
                {
                    SetTileColor(i, j, anchoredWidth, anchoredHeight, isRotate, disableColor);
                }
                else if (yPosOnGrid < 0 || yPosOnGrid >= parentNode.height)
                {
                    SetTileColor(i, j, anchoredWidth, anchoredHeight, isRotate, disableColor);
                }
                else if(parentNode.gridArray[xPosOnGrid, yPosOnGrid] != 0)
                {
                    SetTileColor(i, j, anchoredWidth, anchoredHeight, isRotate, disableColor);
                }
                else
                {
                    SetTileColor(i, j, anchoredWidth, anchoredHeight, isRotate, enableColor);
                }

            }
        }
    }

    private void SetTileColor(int indexWidth, int indexHeight, int anchoredWidth, int anchoredHeight, bool isRotate, Color color)
    {
        int index;

        if (isRotate)
        {
            index = tileList.Count - 1 - (indexWidth + anchoredWidth) * height - (-indexHeight + anchoredHeight);
        }
        else
        {
            index = (indexWidth + anchoredWidth) * height + (indexHeight + anchoredHeight);
        }

        if (index < 0 || index >= tileList.Count) return;

        tileList[index].GetComponent<Image>().color = color;
    }

    private void RotateIcon()
    {
        if (prevRotate == isRotate) return;

        //float yPosGap = Mathf.Abs(rect.localPosition.y - Mathf.CeilToInt(rect.localPosition.y / 64f));

        if (isRotate)
        {
            transform.localEulerAngles = new Vector3(0f, 0f, 90f);
        }
        else
        {
            transform.localEulerAngles = Vector3.zero;
        }

        PointerEventData data = new PointerEventData(currentEvent);

        data.position = Input.mousePosition;
        OnDrag(data);

        prevRotate = isRotate;
    }

    /// <summary>
    /// Set icon image
    /// </summary>
    public void SetIcon(Sprite Image)
    {
        icon.sprite = Image;
    }
    #endregion Method

}
