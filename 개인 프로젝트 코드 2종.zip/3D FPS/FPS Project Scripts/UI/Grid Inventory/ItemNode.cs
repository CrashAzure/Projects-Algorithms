public class ItemNode
{
    public int xPosition = 0;
    public int yPosition = 0;

    public int instanceID = 0;
}
