using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName = "Container_", menuName = "KJJ/Container SO")]
public class ContainerSO : ScriptableObject
{
    public ContainerType containerType;
    public int width = 1;
    public int height = 1;
    public string containerName;

    public List<Vector2Int> gridSizeList = new List<Vector2Int>();


#if UNITY_EDITOR
    private void OnValidate()
    {
        if(width * height < gridSizeList.Count)
        {
            gridSizeList.Clear();
        }

        int index = gridSizeList.Count;

        for (int i = index; i < width * height; i++)
        {
            gridSizeList.Add(new Vector2Int(1, 1));
        }
    }
#endif
}
