using System.Collections.Generic;
using System.Diagnostics.Tracing;
using UnityEngine;

public enum ContainerType
{
    None,
    Rig,
    BackPack,
    Stash,
    Pocket,
    WeaponSlot,
    Size,
}

public enum RigType
{
    None,
    smallRig,
    mediumRig,
    largeRig,
    Size,
}

public enum BackPackType
{
    None,
    smallBackPack,
    mediumBackPack,
    largeBackPack,
    Size,
}

public class ContainerUI : MonoBehaviour
{
    [SerializeField]
    private bool isInspectArea = false;

    private int cellSize = 64;
    public int width = 0;
    public int height = 0;

    public ContainerType type;
    //public RigType rigtype;
    //public BackPackType backpacktype;

    public List<ContainerSO> containerList = new List<ContainerSO>();
    public ContainerSO currentContainerDetail = null;

    private Transform gridTransform;
    [HideInInspector]
    public bool isPlayerInventory = false;
    [HideInInspector]
    public bool isGrid = false;
    [HideInInspector]
    public Container targetContainer;
   

    [HideInInspector]
    public List<GridNode> gridList = new List<GridNode>();

    #region Unity

    private void OnEnable()
    {
        if (GetComponent<WindowController>() != null) return;
        SetContainerUI();

        //switch (type)
        //{
        //    case ContainerType.None:
        //        break;
        //    case ContainerType.Rig:
        //        SetContainer(type, (int)rigtype);
        //        break;
        //    case ContainerType.BackPack:
        //        SetContainer(type, (int)backpacktype);
        //        break;
        //    case ContainerType.Stash:
        //        break;
        //}
    }

    public void SetContainerUI(Container target = null)
    {
        //if (isGrid) return;
        

        
        
        gridTransform = transform.Find("Grid");

        Transform checkParent = transform.parent.parent;

        if (checkParent.name == "Area_Equipments")
        {
            isPlayerInventory = true;
            isGrid = false;
        }
        else if (checkParent.name == "Area_Loot")
        {
            isPlayerInventory = false;
            isGrid = false;
        }
        else
        {
            isGrid = true;
            isPlayerInventory = true;
        }

        Inventory inventory;
        targetContainer = target;

        if (isPlayerInventory)
        {
            inventory = GameController.Instance.playerInventory;
        }
        else
        {
            inventory = null;
        }

        if(target == null)
        {
            if(type != ContainerType.Stash)
            {
                Container[] containers = inventory.GetComponentsInChildren<Container>();

                foreach (var container in containers)
                {
                    if (container.type == type)
                    {
                        targetContainer = container;
                        break;
                    }
                }
            }
            else
            {
                targetContainer = FindObjectOfType<Stash>();
            }
            
        }
        else
        {
            targetContainer = target;
        }

        

        //rigtype = targetContainer.rigtype;
        //backpacktype = targetContainer.backpacktype;
        if (targetContainer != null)
        {
            if (targetContainer.currentContainerDetail == null)
            {
                targetContainer.Init();
            }
            type = targetContainer.type;
            gridList = targetContainer.gridList;
            currentContainerDetail = targetContainer.currentContainerDetail;

            SetContainer();
        }
    }

    #endregion Unity
    public void SetContainer()
    {
        switch (type)
        {
            case ContainerType.None:
                InitializeContainer();
                break;
            default:
                if(currentContainerDetail != null)
                {
                    ItemUIIcon icon = targetContainer.GetComponent<Item>().itemUIIcon;

                    if(icon != null)
                    {
                        if (GetComponent<WindowController>() == null)
                        {
                            icon.transform.SetParent(transform.GetChild(0), false);
                            icon.transform.SetAsFirstSibling();
                            icon.isRotate = false;
                            icon.transform.localScale = new Vector3(transform.GetChild(0).GetComponent<RectTransform>().sizeDelta.x / (icon.width * 64f),
                                                                    transform.GetChild(0).GetComponent<RectTransform>().sizeDelta.y / (icon.height * 64f),
                                                                    1f);
                            icon.transform.rotation = Quaternion.identity;
                            icon.transform.position = Vector3.zero;
                            RectTransform iconRect = icon.GetComponent<RectTransform>();
                            RectTransform imageRect = icon.transform.GetChild(icon.transform.childCount - 1).GetComponent<RectTransform>();

                            iconRect.anchoredPosition = -new Vector2(imageRect.anchoredPosition.x * icon.transform.localScale.x, imageRect.anchoredPosition.y * icon.transform.localScale.y);
                        }

                        if (targetContainer.isEquieped)
                        {
                            icon.item.gameObject.SetActive(false);
                        }
                        icon.DisableAllTiles();
                        icon.gameObject.SetActive(true);
                    }
                    
                    SetContainerInfo();
                    SetGrids();
                }
                break;
            //case ContainerType.Rig:
            //    SetContainerInfo(containerList[index - 1]);
            //    SetGrids();
            //    break;
            //case ContainerType.BackPack:
            //    SetContainerInfo(containerList[index + (int)RigType.Size - 2]);
            //    SetGrids();
            //    break;
            //case ContainerType.Stash:
            //    SetContainerInfo(containerList[index + (int)RigType.Size + (int)BackPackType.Size - 3]);
            //    SetGrids();
            //    break;
        }

        Item containerItem = targetContainer.GetComponent<Item>();
        if (containerItem.itemUIIcon != null)
        {
            if (isInspectArea)
            {
                containerItem.itemUIIcon.gameObject.SetActive(false);
            }
            else
            {
                containerItem.itemUIIcon.gameObject.SetActive(true);
            }
        }
    }

    private void SetGrids()
    {
        InitializeGrids();

        Vector3 currentAnchor = new Vector2(2, -2);
        int maxYSizeOnCurrentRow = 0;

        List<Vector2Int> sizeList = currentContainerDetail.gridSizeList;

        //for(int i =0; i < sizeList.Count; i++)
        //{
        //    GridNode gridPrefab = Resources.Load<GridNode>("GridNode");
        //    GridNode grid = (GridNode)PoolManager.Instance.ReuseComponent(gridPrefab.gameObject, Vector3.zero, Quaternion.identity);
        //    grid.transform.SetParent(gridTransform.transform);
        //    grid.GetComponent<RectTransform>().anchoredPosition = currentAnchor;

        //    if (maxYSizeOnCurrentRow < sizeList[i].y)
        //    {
        //        maxYSizeOnCurrentRow = sizeList[i].y;
        //    }

        //    if (i % width != width - 1 || i == 0)
        //    {
        //        currentAnchor = new Vector2(currentAnchor.x + 2 + cellSize * sizeList[i].x, currentAnchor.y);
        //    }
        //    else
        //    {
        //        currentAnchor = new Vector2(2, currentAnchor.y - 2 - maxYSizeOnCurrentRow * cellSize);
        //        maxYSizeOnCurrentRow = 0;
        //    }

        //    grid.SetGridNodeInfo(sizeList[i]);
        //    grid.gameObject.SetActive(true);
        //    grid.InitializeGridArray();
        //}
        int count = 0;

        foreach (GridNode grid in gridList)
        {
            grid.transform.SetParent(gridTransform.transform);
            grid.GetComponent<RectTransform>().anchoredPosition = currentAnchor;

            if (maxYSizeOnCurrentRow < sizeList[count].y)
            {
                maxYSizeOnCurrentRow = sizeList[count].y;
            }

            if (count % width != width - 1 || count == 0)
            {
                currentAnchor = new Vector2(currentAnchor.x + 4 + cellSize * sizeList[count].x, currentAnchor.y);
            }
            else
            {
                currentAnchor = new Vector2(2, currentAnchor.y - 4 - maxYSizeOnCurrentRow * cellSize);
                maxYSizeOnCurrentRow = 0;
            }

            grid.SetGridNodeInfo(sizeList[count]);
            grid.gameObject.SetActive(true);
            grid.InitializeGridArray();

            count++;
        }
    }

    private void InitializeGrids()
    {
        //gridList.Clear();|
        GridNode[] grids = GetComponentsInChildren<GridNode>();
        foreach (GridNode grid in grids)
        {
            grid.gameObject.SetActive(false);
        }
    }

    public void SetContainerInfo()
    {
        //currentContainerDetail = container;
        //width = container.width;
        //height = container.height;
        if (currentContainerDetail == null) return;
        width = currentContainerDetail.width;
        height = currentContainerDetail.height;
    }

    private void InitializeContainer()
    {
        width = 0;
        height = 0;
        type = ContainerType.None;
        //rigtype = RigType.None;
        //backpacktype = BackPackType.None;
    }
}