using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    private static UIManager instance;
    public SelectUIController selectUI;
    public WeaponStatusUI weaponStatusUI;
    public InventoryUI inventoryUI;
    public DamageIndicator damageIndicator;
    public DamageIndicator[] damageIndicators;
    public ArmorSlotUI[] armorSlots;
    public CrouchingUI crouchingUI;
    public Canvas canvas;
    public FadeUI fadeUI;
    public Transform playerStatusUI;
    public Image CenterPoint;
    public ItemUIIcon selectedIcon;
    public ItemUIIcon focusedIcon;
    public GameObject playerStatusUIOnScreen;
    public GameObject mainUIButtons;
    public LoadingUI loadingUI;
    public GameObject targetInventoryUI;
    public GameObject targetRigUI;
    public GameObject targetBackPackUI;
    public GameObject stashUI;
    public Image titleImage;

    public TextMeshProUGUI escapingTimeUI;
    public TextMeshProUGUI escapingNameUI;
    public static UIManager Instance
    {
        get
        {
            if(instance == null)
            {
                GameObject uiManager = new GameObject("UIManager");
                instance = uiManager.AddComponent<UIManager>();
                uiManager.transform.SetParent(GameObject.Find("Managers").transform);
                uiManager.GetComponent<UIManager>().Init();
            }
            return instance;
        }
    }

    private void Init()
    {
        selectUI = FindObjectOfType<SelectUIController>(true);
        weaponStatusUI= FindObjectOfType<WeaponStatusUI>(true);
        inventoryUI = FindObjectOfType<InventoryUI>(true);
        damageIndicator = FindObjectOfType<DamageIndicator>(true);
        damageIndicators = FindObjectsOfType<DamageIndicator>(true);
        armorSlots = FindObjectsOfType<ArmorSlotUI>(true);

        foreach (DamageIndicator indicator in damageIndicators)
        {
            indicator.Init();
        }
        titleImage = GameObject.Find("Title_Image").GetComponent<Image>();
        escapingTimeUI = GameObject.Find("EscapingTime").GetComponent<TextMeshProUGUI>();
        escapingNameUI = GameObject.Find("EscapingName").GetComponent<TextMeshProUGUI>();
        targetInventoryUI = GameObject.Find("TargetInventory");
        targetRigUI = GameObject.Find("RigContainer");
        targetBackPackUI = GameObject.Find("BackPackContainer");
        stashUI = GameObject.Find("Stash");
        loadingUI = FindObjectOfType<LoadingUI>(true);
        mainUIButtons = GameObject.Find("MainMenuButtons");
        crouchingUI = FindObjectOfType<CrouchingUI>(true);
        canvas = GameObject.Find("MainUI").GetComponent<Canvas>();
        playerStatusUI = canvas.transform.Find("PlayerStatusUI");
        fadeUI = FindObjectOfType<FadeUI>(true);
        CenterPoint = canvas.transform.Find("CenterPoint").GetComponent<Image>();
    }

    public void DisableAllLootingObjects()
    {
        targetInventoryUI.SetActive(false);
        targetRigUI.SetActive(false);
        targetBackPackUI.SetActive(false);
        stashUI.SetActive(false);
    }

    public ItemUIIcon GetFocousedIcon()
    {
        EventSystem currentEventSystem = EventSystem.current;
        List<RaycastResult> rayList = new List<RaycastResult>();
        PointerEventData pointer = new PointerEventData(currentEventSystem);
        pointer.position = Input.mousePosition;
        
        currentEventSystem.RaycastAll(pointer, rayList);

        ItemUIIcon icon = null;

        foreach (RaycastResult ray in rayList)
        {
            if (ray.gameObject.transform.parent.GetComponent<ItemUIIcon>() != null)
            {
                icon = ray.gameObject.transform.parent.GetComponent<ItemUIIcon>();
            }
        }

        return icon;
    }
}

