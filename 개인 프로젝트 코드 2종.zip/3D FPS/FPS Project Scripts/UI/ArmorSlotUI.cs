using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ArmorSlotUI : MonoBehaviour
{
    [HideInInspector]
    public Container slot;
    private Character target;
    public ItemType type;
    private Inventory inventory;
    private Image image;
    private void OnEnable()
    {
        if(image == null)
        {
            image = GetComponent<Image>();
        }

        InitWeaponSlotUI();
    }

    public void InitWeaponSlotUI(Character character = null)
    {
        if (type != ItemType.Helmet && type != ItemType.Armor) return;

        if (character == null)
        {
            target = GameController.Instance.player;
        }
        else
        {
            target = character;
        }

        if (target.inventory == null)
        {
            target.inventory = target.GetComponentInChildren<Inventory>();
        }

        inventory = target.inventory;

        if (slot == null)
        {
            if(type == ItemType.Helmet)
            {
                slot = inventory.helmetSlot;
            }

            if(type == ItemType.Armor)
            {
                slot = inventory.armorSlot;
            }
        }

        if (slot != null && slot.itemList.Count != 0)
        {
            slot.itemList[0].itemUIIcon.transform.SetParent(transform, false);

            slot.itemList[0].itemUIIcon.gameObject.SetActive(true);

            foreach (var tile in slot.itemList[0].GetComponentsInChildren<Tile>())
            {
                tile.gameObject.SetActive(false);
            }

            slot.itemList[0].itemUIIcon.rect.anchoredPosition = -slot.itemList[0].itemUIIcon.icon.rectTransform.anchoredPosition;
            image.enabled = false;
        }
        else
        {
            image.enabled = true;
        }
    }
}
