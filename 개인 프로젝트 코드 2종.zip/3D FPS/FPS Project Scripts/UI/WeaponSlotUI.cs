using System.Linq.Expressions;
using UnityEngine;

public class WeaponSlotUI : MonoBehaviour
{
    [HideInInspector]
    public WeaponSlot slot;
    private Character target;
    public WeaponSlotType type;
    private void OnEnable()
    {
        InitWeaponSlotUI();
    }

    public void InitWeaponSlotUI(Character character = null)
    {
        if (character == null)
        {
            target = GameController.Instance.player;
        }
        else
        {
            target = character;
        }

        if (target.inventory == null)
        {
            target.inventory = target.GetComponentInChildren<Inventory>();
        }

        if (slot == null)
        {
            foreach (var slot in target.inventory.slots)
            {
                if (type == slot.weaponSlotType)
                {
                    this.slot = slot;
                    break;
                }
            }
        }

        if (slot != null && slot.itemList.Count != 0)
        {
            slot.itemList[0].itemUIIcon.transform.SetParent(transform, false);

            slot.itemList[0].itemUIIcon.gameObject.SetActive(true);

            foreach(var tile in slot.itemList[0].GetComponentsInChildren<Tile>())
            {
                tile.gameObject.SetActive(false);
            }
        }
    }
}
