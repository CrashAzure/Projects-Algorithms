using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class InitialiseForMainUI : MonoBehaviour
{
    private PlayerStatus playerStatus;

    private void OnEnable()
    {
        if(playerStatus == null)
        {
            playerStatus =  FindObjectOfType<PlayerStatus>();
        }

        playerStatus.isDead = false;
        playerStatus.isInGame = false;

        UIManager.Instance.mainUIButtons.SetActive(true);
        //UIManager.Instance.inventoryUI.gameObject.SetActive(false);
        UIManager.Instance.CenterPoint.gameObject.SetActive(false);
        UIManager.Instance.escapingNameUI.gameObject.SetActive(false);
        UIManager.Instance.escapingTimeUI.gameObject.SetActive(false);
    }
    private void OnDisable()
    {
        playerStatus.isDead = false;
        playerStatus.isInGame = true;

        UIManager.Instance.mainUIButtons.SetActive(false);
        UIManager.Instance.inventoryUI.gameObject.SetActive(false);
        UIManager.Instance.titleImage.gameObject.SetActive(false);
    }
}
