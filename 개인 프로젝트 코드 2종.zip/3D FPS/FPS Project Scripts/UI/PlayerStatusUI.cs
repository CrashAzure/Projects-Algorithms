using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStatusUI : MonoBehaviour
{
    private DamageIndicator indicator;
    private Transform equipedItems;
    private void Awake()
    {
        indicator = GetComponentInChildren<DamageIndicator>(true);
        equipedItems = transform.Find("Area_Item");
    }

    public void ChangeToIndicator()
    {
        indicator.gameObject.SetActive(true);
        equipedItems.gameObject.SetActive(false);
    }

    public void ChangeToEquipments()
    {
        indicator.gameObject.SetActive(false);
        equipedItems.gameObject.SetActive(true);
    }
}
