using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class WeaponController : MonoBehaviour
{
    #region Parameters
    private Animator animator;
    private CharacterInput playerInput;
    private Muzzle muzzle;
    private Eject eject;
    private WeaponDetails weaponDetails;
    private Transform parent;

    private float verticalRecoil = 5f;
    private float horizontalRecoil = 3f;

    private float fireRate = 0.1f;
    private float speed = 500f;
    private float fireTimer = 0f;
    private bool cooldownFire = false;
    private bool singleShot = true;
    private List<Camera> scopeCameras = new List<Camera>();

    [HideInInspector]
    public bool isDirty = false;

    private Coroutine fireRecoilCoroutine = null;
    #endregion Parameters

    #region Unity
    private void OnEnable()
    {
        if (animator == GetComponent<Animator>()) return;

        if(scopeCameras.Count == 0)
        {
            scopeCameras.AddRange(GetComponentsInChildren<Camera>(true));
        }

        if (parent == null) 
        {
            parent = GetComponentInParent<Character>().transform;
        }

        animator = GetComponent<Animator>();
        weaponDetails = GetComponent<WeaponDetails>();

        playerInput = GetComponentInParent<CharacterInput>();

        InitializeWeaponInfo();
    }

    private void Update()
    {
        if (isDirty)
        {
            isDirty = false;
            parent = GetComponentInParent<Character>().transform;

            bool isPlayer = parent == GameController.Instance.player.transform;

            SetScopeCameras(isPlayer);
        }

        if (playerInput == null) return;

        if (playerInput.HasFire() && !cooldownFire && transform.localPosition == Vector3.zero)
        {
            if (singleShot)
            {
                playerInput.SetFire(false);
            }

            Fire();
            cooldownFire = true;
        }

        if (cooldownFire)
        {
            fireTimer += Time.deltaTime;
        }

        if (fireTimer >= fireRate)
        {
            fireTimer = 0f;
            cooldownFire = false;
        }
    }
    #endregion Unity

    #region Method
    /// <summary>
    /// Initialize weapon info
    /// </summary>
    private void InitializeWeaponInfo()
    {
        verticalRecoil = weaponDetails.verticalRecoil;
        horizontalRecoil = weaponDetails.horizontalRecoil;

        fireRate = weaponDetails.fireRate;
        speed = weaponDetails.speed;
    }

    public void SetDirty()
    {
        isDirty = true;
    }

    private void SetScopeCameras(bool isPlayer)
    {
        foreach(var scopeCam in scopeCameras)
        {
            scopeCam.gameObject.SetActive(isPlayer);
        }
    }

    /// <summary>
    /// Do fire
    /// </summary>
    private void Fire()
    {
        CharacterInput characterInput = GameController.Instance.input;
        WeaponStatus currentWeaponStatus = characterInput.inventory.currentWeapon.GetComponent<WeaponStatus>();
        AnimatorClipInfo[] animatorInfoArray = characterInput.HasAnimator().GetCurrentAnimatorClipInfo(1);

        if (animatorInfoArray[0].clip.name == "A_FP_PCH_Run_02_Additive") return;

        if (playerInput.HasRun()) return;

        if (currentWeaponStatus.GetCurrentAmmo() == 0) return;

        currentWeaponStatus.ReduceClipAmmo();

        // fire animate
        const string stateName = "Fire";
        animator.Play(stateName, 0, 0.0f);

        PlayFireSound();

        // muzzle effect
        muzzle.Effect();

        // Casing
        eject.Ejecting();

        FireProjectile();

        fireRecoilCoroutine = StartCoroutine(DoRecoilOfWeapon(0.2f));
    }

    public void FireForEnemy(Transform enemy)
    {
        PlayFireSound();

        // muzzle effect
        muzzle?.Effect();

        // Casing
        eject.Ejecting(enemy);

        FireProjectile();
    }

    /// <summary>
    /// Change shot mode to single / full auto
    /// </summary>
    public void ChangeShotMode()
    {
        singleShot = !singleShot;
        string shotmodeText = "";

        if (singleShot)
        {
            shotmodeText = "Single Mode";
        }
        else
        {
            shotmodeText = "Full Auto";
        }

        UIManager.Instance.weaponStatusUI.SetText(shotmodeText);

        UIManager.Instance.weaponStatusUI.FadeUI(0.5f, 2.5f);
    }

    /// <summary>
    /// Set Muzzle
    /// </summary>
    public void SetMuzzle()
    {
        muzzle = GetComponentInChildren<Muzzle>();
    }

    /// <summary>
    /// Set Eject
    /// </summary>
    public void SetEject()
    {
        eject = GetComponentInChildren<Eject>(true);
    }

    /// <summary>
    /// Play sounds using poolmanager
    /// </summary>
    private void PlayFireSound()
    {
        GameObject audioPrefab = Resources.Load<GameObject>("Audio");
        
        SetAudio audioObject = (SetAudio)PoolManager.Instance.ReuseComponent(audioPrefab.gameObject, 
                                                                            transform.position, 
                                                                            Quaternion.identity);

        StartCoroutine(ProcessAudio(audioObject));
    }

    /// <summary>
    /// Fire projectile bullet
    /// </summary>
    private void FireProjectile()
    {
        Character character = GetComponentInParent<Character>();
        Player player = character as Player;
        Enemy enemy = character as Enemy;

        if (player != null)
        {
            playerInput.HasAnimator().SetTrigger("Fire");
            parent = player.transform;
        }
        else if (enemy != null)
        {
            parent = enemy.transform;
        }
        else
        {
            parent = null;
            return;
        }

        GameObject projectilePrefab = Resources.Load<GameObject>("Projectile_Bullet");
        Projectiles projectileObject;

        if (player != null)
        {
            projectileObject = (Projectiles)PoolManager.Instance.ReuseComponent(projectilePrefab.gameObject,
                                                                                Camera.main.transform.position,
                                                                                Camera.main.transform.rotation);
        }
        else
        {
            projectileObject = (Projectiles)PoolManager.Instance.ReuseComponent(projectilePrefab.gameObject,
                                                                                transform.position,
                                                                                transform.rotation);
        }

        projectileObject.SetParentTransform(parent);
        projectileObject.SetBulletWeight(weaponDetails.bulletWeight);
        projectileObject.SetDamage(weaponDetails.damageAmount);
        projectileObject.SetPenetrationLevel(weaponDetails.bulletPenetrationLevel);


        if (player != null)
        {
            if (player.GetComponentInChildren<PlayerAnimationController>().isLeanForward)
            {
                Transform cameraTransform = GameController.Instance.mainCameraController.transform;
                Transform playerTransform = GameController.Instance.player.transform;

                projectileObject.transform.position = cameraTransform.position + 0.2f * playerTransform.forward;
                projectileObject.SetVelocity(cameraTransform.forward.normalized * speed);
            }
            else
            {
                projectileObject.transform.position = muzzle.GetSocket().position;
                projectileObject.SetVelocity(transform.forward.normalized * speed);
            }
        }
        else
        {
            ProcessProjectileForEnemy(projectileObject);
        }

        projectileObject.gameObject.SetActive(true);
    }

    private void ProcessProjectileForEnemy(Projectiles projectile)
    {
        (float, float) upScale = GetUpScaleForAI(projectile);
        float upScaleAmount = upScale.Item1;
        float errorRange = Mathf.Log((upScale.Item2) / 50 + 1);


        if (!parent.GetComponent<Character>().agent.isStopped)
        {
            errorRange *= 1.5f;
        }

        projectile.transform.position = muzzle.GetSocket().position;
        projectile.transform.LookAt(GameController.Instance.player.headTransform.position + Vector3.down * 0.2f + Random.insideUnitSphere * errorRange);
        projectile.transform.eulerAngles = Vector3.right * upScaleAmount + projectile.transform.eulerAngles;
        projectile.SetVelocity(projectile.transform.forward * speed);
    }

    /// <summary>
    /// Reverse caculate of gravity
    /// How much up vector for hit
    /// </summary>
    private (float, float) GetUpScaleForAI(Projectiles  projectile)
    {
        float distance = Vector3.Distance(muzzle.GetSocket().position, GameController.Instance.player.headTransform.position);
        float gravity = Physics.gravity.y * projectile.rigidBody.mass;
        float result = Mathf.Asin(distance * gravity / Mathf.Pow(speed, 2));
        result *= Mathf.Rad2Deg;
        result /= 2f;

        if(Mathf.Abs(result) < 0.0001f)
        {
            result = 0f;
        }
        result = 0f;
        return (result, distance);
    }

    /// <summary>
    /// Process audio
    /// </summary>
    private IEnumerator ProcessAudio(SetAudio audio)
    {
        audio.SetVolume(0.2f);
        audio.SetAudioSource(muzzle.GetAudioClipFire());
        audio.gameObject.SetActive(true);
        audio.Play();
        yield return new WaitForSeconds(muzzle.GetAudioClipFire().length);
        audio.gameObject.SetActive(false);
    }

    /// <summary>
    /// Do recoil coroutine
    /// </summary>
    private IEnumerator DoRecoilOfWeapon(float delayTime)
    {
        float elapsed = 0f;

        while(elapsed <= delayTime)
        {
            elapsed += Time.deltaTime / delayTime;
            Vector3 xAngle = playerInput.characterRoot.localEulerAngles;
            Vector3 yAngle = playerInput.transform.localEulerAngles;
            float verticalRecoil = this.verticalRecoil;
            float horizontalRecoil = this.horizontalRecoil;

            if (playerInput.HasCrouch())
            {
                verticalRecoil = verticalRecoil * 0.75f;
                horizontalRecoil = horizontalRecoil * 0.75f;
            }

            // recoil
            playerInput.transform.localEulerAngles = Vector3.Lerp(yAngle,
                                                                yAngle + new Vector3(0f, 
                                                                Random.Range(-horizontalRecoil, horizontalRecoil), 0f), elapsed);
            playerInput.characterRoot.localEulerAngles = Vector3.Lerp(xAngle,
                                                                      xAngle + new Vector3(-Random.Range(verticalRecoil * 0.8f, verticalRecoil),
                                                                      0f, 0f), elapsed);

            yield return null;
        }
    }
    #endregion Method
}
