using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.InputSystem.LowLevel.InputStateHistory;

public class WeaponSounds : MonoBehaviour
{
    [Header("Reloading sounds")]
    public AudioClip reload;

    public AudioClip reloadEmpty;

    [Space(10)]
    [Header("One by One Reloading sounds")]
    public AudioClip open;

    public AudioClip close;

    public AudioClip insert;

    private Transform prevTransform;

    private Transform targetTransform;
    private WeaponStatus status;

    private void Awake()
    {
        status = GetComponent<WeaponStatus>();
    }
    private void Update()
    {
        if (status.isEquiped)
        {
            if (targetTransform == null)
            {
                Character character = GetComponentInParent<Character>();
                if (character != null)
                {
                    targetTransform = character.headTransform;
                }
            }
        }
        else 
        {
            if (targetTransform != null)
            {
                targetTransform = null;
            }
        }
    }

    public void PlayReloadSound()
    {
        var prefab = Resources.Load<GameObject>("Audio");

        SetAudio audio = (SetAudio)PoolManager.Instance.ReuseComponent(prefab,
                                            Vector3.zero,
                                            Quaternion.identity);
        DisableCoroutine(reload, audio);
    }

    public void PlayReloadEmptySound()
    {
        var prefab = Resources.Load<GameObject>("Audio");

        SetAudio audio = (SetAudio)PoolManager.Instance.ReuseComponent(prefab,
                                            Camera.main.transform.position + Camera.main.transform.forward * 0.05f,
                                            Quaternion.identity);

        DisableCoroutine(reloadEmpty, audio);
    }

    private void DisableCoroutine(AudioClip audio, SetAudio target)
    {
        target.transform.SetParent(targetTransform.transform);
        target.transform.localPosition = targetTransform.forward * 0.05f;
        target.transform.localEulerAngles = Vector3.zero;
        target.gameObject.SetActive(true);
        target.SetVolume(1f);
        target.SetAudioSource(audio);
        target.Play();
    }

}
