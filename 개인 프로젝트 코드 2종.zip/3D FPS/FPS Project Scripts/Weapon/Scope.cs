﻿using UnityEngine;
using static Unity.VisualScripting.Member;

/// <summary>
/// Weapon Scope.
/// </summary>
public class Scope : MonoBehaviour
{
    #region Serialized

    private ShaderEffects effects;
    private float normalFov = 0f;

    private Camera rendererCamera;

    [Title(label: "Multipliers")]

    [Tooltip("Amount to multiply the mouse sensitivity by while aiming through this scope.")]
    [SerializeField]
    private float multiplierMouseSensitivity = 0.8f;

    [Tooltip("Value multiplied by the weapon's spread while aiming through this scope.")]
    [SerializeField]
    private float multiplierSpread = 0.1f;

    [Title(label: "Interface")]

    [Tooltip("Interface Sprite.")]
    [SerializeField]
    private Sprite sprite;

    [Title(label: "Sway")]

    [Tooltip("The value to multiply the weapon sway by while aiming through this scope.")]
    [SerializeField]
    private float swayMultiplier = 1.0f;

    [Title(label: "Aiming Offset")]

    [Tooltip("Weapon bone location offset while aiming.")]
    [SerializeField]
    private Vector3 offsetAimingLocation;

    [Tooltip("Weapon bone rotation offset while aiming.")]
    [SerializeField]
    private Vector3 offsetAimingRotation;

    [Title(label: "Field Of View")]

    [Tooltip("Field Of View Multiplier Aim.")]
    [SerializeField]
    private float fieldOfViewMultiplierAim = 0.9f;

    [Tooltip("Field Of View Multiplier Aim Weapon.")]
    [SerializeField]
    private float fieldOfViewMultiplierAimWeapon = 0.7f;

    [Title(label: "Materials")]

    [Tooltip("The index of the scope material that gets hidden when we don't aim.")]
    [SerializeField]
    private int materialIndex = 3;

    [Tooltip("Material to block the scope while not aiming through it.")]
    [SerializeField]
    private Material materialHidden;

    [Tooltip("Material to Set Rain Drop lens.")]
    [SerializeField]
    private Material materialRainDrop;

    #endregion

    #region Parameters

    /// <summary>
    /// Mesh Renderer.
    /// </summary>
    private MeshRenderer meshRenderer;
    /// <summary>
    /// Default scope material. We store it so we can re-apply it at any time, since it is
    /// usually changed at runtime.
    /// </summary>
    private Material materialDefault;

    #endregion

    #region Unity
    private void Awake()
    {
        offsetAimingLocation.x = Mathf.Abs(offsetAimingLocation.x);
        offsetAimingLocation.y = -offsetAimingLocation.z;
        normalFov = GameController.Instance.mainCameraController.depthCamera.fieldOfView;
        //Cache Scope Renderer.
        meshRenderer = GetComponentInChildren<MeshRenderer>();
        rendererCamera = GetComponentInChildren<Camera>();

        if(rendererCamera != null)
        {
            Shader rainDropShader = Shader.Find("Custom/Raindrop");

            materialRainDrop = new Material(rainDropShader);

            materialRainDrop.SetTexture("iChannel0", rendererCamera.targetTexture);
        }
        effects = FindObjectOfType<ShaderEffects>();

        //Make sure that the index can exist.
        if (!HasMaterialIndex())
            return;

        //Cache default material.
        materialDefault = meshRenderer.materials[materialIndex];
    }

    private void Start()
    {
        //Start at the default state.
        OnAimStop();
    }

    #endregion

    #region Getter

    /// <summary>
    /// GetMultiplierMouseSensitivity.
    /// </summary>
    public float GetMultiplierMouseSensitivity() => multiplierMouseSensitivity;
    /// <summary>
    /// GetMultiplierSpread.
    /// </summary>
    public float GetMultiplierSpread() => multiplierSpread;

    /// <summary>
    /// GetOffsetAimingLocation.
    /// </summary>
    public Vector3 GetOffsetAimingLocation() => offsetAimingLocation;
    /// <summary>
    /// GetOffsetAimingRotation.
    /// </summary>
    public Vector3 GetOffsetAimingRotation() => offsetAimingRotation;

    /// <summary>
    /// GetFieldOfViewMultiplierAim.
    /// </summary>
    public float GetFieldOfViewMultiplierAim() => fieldOfViewMultiplierAim;
    /// <summary>
    /// GetFieldOfViewMultiplierAimWeapon.
    /// </summary>
    public float GetFieldOfViewMultiplierAimWeapon() => fieldOfViewMultiplierAimWeapon;

    /// <summary>
    /// GetSprite.
    /// </summary>
    public Sprite GetSprite() => sprite;
    /// <summary>
    /// GetSwayMultiplier.
    /// </summary>
    public float GetSwayMultiplier() => swayMultiplier;

    /// <summary>
    /// Returns true if the Scope's Mesh Renderer could have this Material index.
    /// </summary>
    private bool HasMaterialIndex()
    {
        //Null check.
        if (meshRenderer == null)
            return false;

        //Make sure that the index can exist.
        return materialIndex < meshRenderer.materials.Length && materialIndex >= 0;
    }

    public Camera GetRenderCamera() => rendererCamera;

    #endregion

    #region Method

    /// <summary>
    /// Aimming
    /// </summary>
    public void OnAim()
    {
        CameraController main = GameController.Instance.mainCameraController;

        main.CameraRePosiiton(offsetAimingLocation, 0.2f);
        main.CameraRotate(offsetAimingRotation);
        main.CameraFovChange(normalFov * fieldOfViewMultiplierAim, 0.2f);

        //Make sure that the index can exist.
        if (!HasMaterialIndex())
            return;

        //Get Materials.
        Material[] materials = meshRenderer.materials;

        //Restore to default material.
        materials[materialIndex] = materialDefault;

        //Update Materials.
        meshRenderer.materials = materials;
    }

    /// <summary>
    /// aimming stop
    /// </summary>
    public void OnAimStop()
    {
        CameraController main = GameController.Instance.mainCameraController;
        main.CameraResetPosition(0.2f);
        //main.CameraFovChange(53f, 0.2f);
        main.CameraFovChange(normalFov, 0.2f);

        //Make sure that the index can exist.
        if (!HasMaterialIndex())
            return;

        //Get Materials.
        Material[] materials = meshRenderer.materials;
        //Hide.
        materials[materialIndex] = materialHidden;
        //Update Materials.
        meshRenderer.materials = materials;
    }

    #endregion
}