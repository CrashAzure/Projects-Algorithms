using Mono.Cecil;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class MuzzleToWallControl : MonoBehaviour
{
    private Animator[] playerAnimator;
    private Transform playerTransform;
    private CameraController mainCamera;
    private float playerToSocket = 1.2f;
    private float prevRatio;

    private void Start()
    {
        playerAnimator = GameController.Instance.GetPlayerAnimator();
        playerTransform = GameController.Instance.player.transform;
        mainCamera = GameController.Instance.mainCameraController;
    }

    private void LateUpdate()
    {
        bool isRayHit = Physics.Raycast(mainCamera.transform.position,
                                        mainCamera.transform.forward,
                                        out RaycastHit rayHit,
                                        5f,
                                        (1 << LayerMask.NameToLayer("Default"))
                                        + (1 << LayerMask.NameToLayer("Wall"))
                                        + (1 << LayerMask.NameToLayer("HitBox")));
        //(new Vector2(mainCamera.transform.position.x, mainCamera.transform.position.z) - new Vector2(rayHit.point.x, rayHit.point.z)).magnitude -

        float playerToTarget = rayHit.distance;

        float ratio = playerToTarget / playerToSocket;

        if (!isRayHit) 
        {
            ratio = 1f;
        }
        else
        {
            ratio = ratio > 1 ? 1 : ratio;

            if (Mathf.Abs(prevRatio - ratio) > 0.9f)
            {
                ratio = prevRatio;
            }
        }

        playerTransform.GetComponent<CharacterInput>().HasAnimator().SetFloat("Leaning Forward", ratio);

        prevRatio = ratio;
    }
}