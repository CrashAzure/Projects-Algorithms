using cakeslice;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations.Rigging;
using UnityEngine.XR;

public class WeaponStatus : MonoBehaviour
{
    #region Parameters
    private WeaponController weaponController;
    [HideInInspector]
    public Item weaponDetails;

    [Header("Current Weapon is Equiped")]
    public bool isEquiped = false;

    [Header("Current Weapon Ammo Info")]
    public int currentAmmoCapacity;
    public int currentAmmoClipCapacity;
    public int currentAmmo;
    public float damageAmount;
    public int bulletPenetrationLevel;

    [Header("Current Weapon Parts Info")]
    public List<Transform> gripList = new List<Transform>();
    public List<Transform> laserList = new List<Transform>();
    public List<Transform> muzzleList = new List<Transform>();
    public List<Transform> scopeList = new List<Transform>();
    private List<Transform> socketList = new List<Transform>();
    [SerializeField]
    private int gripIndex = 2;
    [SerializeField]
    private int laserIndex = 2;
    [SerializeField]
    // Weapon has to have default muzzle
    private int muzzleIndex = 2;
    [SerializeField]
    // Weapon has to have default scope
    private int scopeIndex = 7;

    private Rigidbody rigid;
    private Outline outline;
    private Transform meshTransform;
    private MeshCollider meshCollider;
    private Transform[] allChildren;

    private Transform parent;
    #endregion Parameters

    #region Unity

    private void OnEnable()
    {
        if (weaponController == null)
        {
            weaponController = GetComponent<WeaponController>();
            weaponDetails = GetComponent<Item>();
            currentAmmoCapacity = weaponDetails.GetWeaponCapacities().Item1;
            currentAmmoClipCapacity = weaponDetails.GetWeaponCapacities().Item2;
            damageAmount = weaponDetails.GetDamageAmount();
            bulletPenetrationLevel = GetComponent<WeaponDetails>().bulletPenetrationLevel;
            rigid = GetComponent<Rigidbody>();
            meshTransform = transform.GetChild(1);
            meshCollider = meshTransform.GetComponent<MeshCollider>();
            meshCollider.sharedMesh = meshTransform.GetComponent<SkinnedMeshRenderer>().sharedMesh;
            currentAmmo = currentAmmoClipCapacity;
            allChildren = GetComponentsInChildren<Transform>(true);
        }

        if (socketList.Count == 0)
        {
            InitializeWeaponParts();
        }

        if(GetComponentInParent<Character>() != null)
        {
            parent = GetComponentInParent<Character>().transform;
        }
        else
        {
            parent = null;
        }
        

        WeaponPartsUpdate();

        weaponController.SetMuzzle();

        weaponController.SetEject();

        SetWeaponStatus(isEquiped);

        //Outline outline = GetComponentInChildren<Outline>(true);
        //outline.Init();
    }

    public void Init()
    {
        
    }


    #endregion Unity

    #region Getter
    public int GetCurrentAmmo() => currentAmmo;
    public bool HasEmpty() => currentAmmo == 0;
    public bool HasFull() => currentAmmo == currentAmmoClipCapacity || currentAmmo == currentAmmoCapacity;
    #endregion Getter

    #region Method
    public void SetWeaponStatus(bool isEquiped)
    {
        this.isEquiped = isEquiped;
        weaponController.enabled = isEquiped;
        if (isEquiped)
        {
            foreach(var transform in allChildren)
            {
                if(parent == GameController.Instance.player.transform)
                {
                    transform.gameObject.layer = LayerMask.NameToLayer("First Person View");
                }
                else
                {
                    transform.gameObject.layer = LayerMask.NameToLayer("Default");
                }
                
            }
        }
        else
        {
            foreach (var transform in allChildren)
            {
                transform.gameObject.layer = LayerMask.NameToLayer("Interactable");
            }
        }

        SetOutlineEffect();
    }
    public void SetOutlineEffect()
    {
        //this.isEquiped = isEquiped;

        if (isEquiped)
        {
            if (!rigid.isKinematic || meshCollider.enabled)
            {
                meshCollider.enabled = false;
                rigid.isKinematic = true;
                transform.localPosition = Vector3.zero;
                transform.localRotation = Quaternion.identity;
                Destroy(outline);
                outline = null;
                scopeList[scopeIndex].GetComponentInChildren<Camera>(true)?.gameObject.SetActive(true);

            }
        }
        else
        {
            if (rigid.isKinematic)
            {
                outline = meshTransform.gameObject.AddComponent<Outline>();
                rigid.isKinematic = false;
                meshCollider.enabled = true;
                scopeList[scopeIndex].GetComponentInChildren<Camera>(true)?.gameObject.SetActive(false);
            }
        }
    }
    private void InitializeWeaponParts()
    {
        Transform root = transform.GetChild(0).Find("root");

        for(int i = 0; i < root.childCount; i++)
        {
            socketList.Add(root.GetChild(i));
            SortSockets(root, i);
        }
    }

    /// <summary>
    /// Reduce current clip ammo
    /// </summary>
    public int ReduceClipAmmo()
    {
        if(currentAmmo > 0)
            currentAmmo--;
            currentAmmoCapacity--;

        return currentAmmo;
    }

    /// <summary>
    /// Refill ammo after reloading
    /// </summary>
    public void RefillClipAmmo()
    {
        if(currentAmmoClipCapacity > currentAmmoCapacity)
        {
            currentAmmo = currentAmmoCapacity;
        }
        else
        {
            currentAmmo = currentAmmoClipCapacity;
        }

    }

    /// <summary>
    /// Sorting sockets transform with each parts
    /// </summary>
    private void SortSockets(Transform root, int index)
    {
        if (root.GetChild(index).name == "barrel")
        {
            for(int i = 0; i < root.GetChild(index).childCount; i++)
            {
                SortSockets(root.GetChild(index), i);
            }
        }

        if (root.GetChild(index).name == "slide")
        {
            for (int i = 0; i < root.GetChild(index).childCount; i++)
            {
                SortSockets(root.GetChild(index), i);
            }
        }

        if (root.GetChild(index).name == "SOCKET_Grip")
        {
            AddPartsList(root, index, ref gripList);
        }
        else if (root.GetChild(index).name == "SOCKET_Laser")
        {
            AddPartsList(root, index, ref laserList);

        }
        else if (root.GetChild(index).name == "SOCKET_Muzzle")
        {
            AddPartsList(root, index, ref muzzleList);
        }
        else if(root.GetChild(index).name == "SOCKET_Default")
        {
            // scope list get first default scope
            scopeList.Add(root.GetChild(index).GetChild(root.GetChild(index).childCount - 1));
        }
        else if (root.GetChild(index).name == "SOCKET_Scope")
        {
            AddPartsList(root, index, ref scopeList);
        }
    }

    /// <summary>
    /// Add parts to each list
    /// </summary>
    private void AddPartsList(Transform parent, int index, ref List<Transform> targetList, bool barrel = false)
    {
        Transform rootSocket = rootSocket = parent.GetChild(index).GetChild(0);

        for (int i = 0; i < rootSocket.childCount; i++)
        {
            targetList.Add(rootSocket.GetChild(i));
        }
    }

    /// <summary>
    /// Update weapon parts
    /// </summary>
    public void WeaponPartsUpdate()
    {
        CheckPartsIndex();

        EnableWeaponPart(gripList, gripIndex);
        EnableWeaponPart(laserList, laserIndex);
        EnableWeaponPart(muzzleList, muzzleIndex);
        EnableWeaponPart(scopeList, scopeIndex);
    }

    public void RandomWeaponPartsUpdate()
    {
        gripIndex = Random.Range(0, gripList.Count - 1);
        laserIndex = Random.Range(0, laserList.Count - 1);
        laserIndex = Random.Range(0, muzzleList.Count - 1);
        scopeIndex = Random.Range(0, scopeList.Count - 1);

        CheckPartsIndex();

        EnableWeaponPart(gripList, gripIndex);
        EnableWeaponPart(laserList, laserIndex);
        EnableWeaponPart(muzzleList, muzzleIndex);
        EnableWeaponPart(scopeList, scopeIndex);
    }


    /// <summary>
    /// Set weapon parts index
    /// </summary>
    public void SetWeaponParts(int ejectIndex, int gripIndex, int laserIndex, int muzzleIndex, int scopeIndex)
    {
        this.gripIndex = gripIndex;
        this.laserIndex = laserIndex;
        this.muzzleIndex = muzzleIndex;
        this.scopeIndex = scopeIndex;
    }

    /// <summary>
    /// Enable weapon part
    /// </summary>
    private void EnableWeaponPart(List<Transform> list, int index)
    {
        if(list.Count <= index)
        {
            if(list.Count != 0)
            {
                list[list.Count - 1].gameObject.SetActive(true);
            }
            return;
        }

        for (int i = 0; i < list.Count; i++)
        {
            if (list[i].gameObject.activeSelf && i != index)
            {
                list[i].gameObject.SetActive(false);
            }

            if (i == index && index != -1)
            {
                list[i].gameObject.SetActive(true);
            }
        }
    }

    /// <summary>
    /// Check that part disabled
    /// </summary>
    private void CheckPartsIndex()
    {
        if (gripIndex < 0) DisableAllParts(gripList);
        if (laserIndex < 0) DisableAllParts(laserList);
    }

    /// <summary>
    /// Disable all parts
    /// </summary>
    private void DisableAllParts(List<Transform> list)
    {
        foreach(var part in list)
        {
            part.gameObject.SetActive(false);
        }
    }
    #endregion Method


}

