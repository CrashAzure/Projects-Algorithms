using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Muzzle : Muzzles
{
    #region FIELDS SERIALIZED

    [Title(label: "Settings")]

    [Tooltip("Socket at the tip of the Muzzle. Commonly used as a firing point.")]
    [SerializeField]
    private Transform socket;

    [Tooltip("Sprite. Displayed on the player's interface.")]
    [SerializeField]
    private Sprite sprite;

    [Tooltip("Audio clip played when firing through this muzzle.")]
    [SerializeField]
    private AudioClip audioClipFire;

    [Title(label: "Particles")]

    [Tooltip("Firing Particles.")]
    [SerializeField]
    private GameObject prefabFlashParticles;

    [Tooltip("Smoking Particles.")]
    [SerializeField]
    private GameObject prefabSmokeParticles;

    [Tooltip("Dark Smoking Particles.")]
    [SerializeField]
    private GameObject prefabDarkSmokeParticles;

    [Tooltip("Number of particles to emit when firing.")]
    [SerializeField]
    private int flashParticlesCount = 5;

    [Title(label: "Flash Light")]

    [Tooltip("Muzzle Flash Prefab. A small light we use when firing.")]
    [SerializeField]
    private GameObject prefabFlashLight;

    [Tooltip("Time that the light flashed stays active. After this time, it is disabled.")]
    [SerializeField]
    private float flashLightDuration;

    [Tooltip("Local offset applied to the light.")]
    [SerializeField]
    private Vector3 flashLightOffset;

    private Light pointLight;

    private GameObject spawnedParticlesPrefabForScope;

    private GameObject spawnedParticlesPrefab;

    #endregion

    #region FIELDS

    /// <summary>
    /// Instantiated Particle System.
    /// </summary>
    private List<ParticleSystem> particles = new List<ParticleSystem>();
    /// <summary>
    /// Instantiated light.
    /// </summary>
    private Light flashLight;

    #endregion

    #region UNITY FUNCTIONS

    /// <summary>
    /// Awake.
    /// </summary>
    private void Awake()
    {
        Muzzle[] muzzles = GetComponents<Muzzle>();
        Collider[] colliders = GetComponents<Collider>();
        if (muzzles.Length > 1)
        {
            for(int i = 1; i< muzzles.Length; i++)
            {
                Destroy(muzzles[i]);
            }
        }
        if (colliders.Length > 1)
        {
            foreach(Collider collider in colliders)
            {
                Destroy(collider);
            }
        }

        //Null Check.
        //if (prefabFlashParticles != null)
        //{
        //    //Instantiate Particles.
        //    spawnedParticlesPrefab = Instantiate(prefabFlashParticles, socket);
        //    //Reset the position.
        //    spawnedParticlesPrefab.transform.localPosition = default;
        //    //Reset the rotation.
        //    spawnedParticlesPrefab.transform.localEulerAngles = default;

        //    //Get Reference.
        //    particles.Add(spawnedParticlesPrefab.GetComponent<ParticleSystem>());
        //}

        //Null Check.
        if (prefabSmokeParticles != null)
        {
            //Instantiate Particles.
            spawnedParticlesPrefab = Instantiate(prefabSmokeParticles, socket);
            //Reset the position.
            //spawnedParticlesPrefab.transform.localPosition += Vector3.up * 0.1f; 
            spawnedParticlesPrefab.transform.localEulerAngles = default;
            
            //Get Reference.
            particles.Add(spawnedParticlesPrefab.GetComponent<ParticleSystem>());
        }

        if(prefabDarkSmokeParticles != null)
        {
            //Instantiate Particles.
            spawnedParticlesPrefabForScope = Instantiate(prefabDarkSmokeParticles, socket);
            //Reset the position.
            spawnedParticlesPrefabForScope.transform.position += socket.forward * 3f + Vector3.up * 0.1f;
            spawnedParticlesPrefabForScope.transform.localEulerAngles = default;

            //Get Reference.
            particles.Add(spawnedParticlesPrefabForScope.GetComponent<ParticleSystem>());
        }

        //Null Check.
        if (prefabFlashLight)
        {
            //Instantiate.
            GameObject spawnedFlashLightPrefab = Instantiate(prefabFlashLight, socket);
            //Reset the position.
            spawnedFlashLightPrefab.transform.localPosition = flashLightOffset;
            //Reset the rotation.
            spawnedFlashLightPrefab.transform.localEulerAngles = default;

            //Get reference.
            flashLight = spawnedFlashLightPrefab.GetComponent<Light>();
            //Disable.
            flashLight.enabled = false;
        }
    }

    #endregion

    #region GETTERS

    public override void Effect()
    {
        //Try to play the fire particles from the muzzle!
        if (particles.Count != 0)
        {
            Enemy enemy = GetComponentInParent<Enemy>();
            //Player player = GetComponentInParent<Player>();
            if (enemy != null)
            {
                spawnedParticlesPrefabForScope.gameObject.SetActive(false);
            }
            else
            {
                spawnedParticlesPrefabForScope.gameObject.SetActive(true);
            }
            foreach (ParticleSystem particle in particles)
            {
                particle.Emit(flashParticlesCount);
                if (enemy != null)
                {
                    particle.gameObject.layer = LayerMask.NameToLayer("Default");
                }
                else
                {
                    particle.gameObject.layer = LayerMask.NameToLayer("All Person View");
                }
            }
        }

        //Make sure that we have a light to flash!
        if (flashLight != null)
        {
            //Enable the light.
            flashLight.enabled = true;
            
            //Disable the light after a few seconds.
            StartCoroutine(DisableLight());
            
        }

        if(pointLight != null)
        {
            pointLight.gameObject.SetActive(true);
            StartCoroutine(DisableLight(pointLight));
        }
        else
        {
            pointLight = GetComponentInChildren<Light>(true);
            if (pointLight == null) return;
            pointLight.gameObject.SetActive(true);
            StartCoroutine(DisableLight(pointLight));
        }
    }

    public override Transform GetSocket() => socket;

    public override Sprite GetSprite() => sprite;
    public override AudioClip GetAudioClipFire() => audioClipFire;

    public override List<ParticleSystem> GetParticlesFire() => particles;
    public override int GetParticlesFireCount() => flashParticlesCount;

    public override Light GetFlashLight() => flashLight;
    public override float GetFlashLightDuration() => flashLightDuration;

    #endregion

    #region METHODS

    private IEnumerator DisableLight()
    {
        //Wait.
        yield return new WaitForSeconds(flashLightDuration);
        //Disable.
        flashLight.enabled = false;
    }

    private IEnumerator DisableLight(Light light)
    {
        //Wait.
        yield return new WaitForSeconds(flashLightDuration);
        //Disable.
        light.gameObject.SetActive(false);
    }

    #endregion

}