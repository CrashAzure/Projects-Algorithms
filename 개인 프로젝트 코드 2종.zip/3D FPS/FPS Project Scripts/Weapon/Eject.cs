using UnityEngine;

public enum CasingType
{
    Small_Bullet,
    Big_Bullet,
    Grenade_Shell,
    Shotgun_Shell,
}

public class Eject : MonoBehaviour
{
    [SerializeField]
    [Tooltip("Casing type")]
    private CasingType casingType;
    private Transform ejectSocket;
    private void Awake()
    {
        ejectSocket = transform.GetChild(0);
    }

    public void Ejecting(Transform enemy = null)
    {
        GameObject casingPrefab = GetPrefab();
        Casing casing = (Casing)PoolManager.Instance.ReuseComponent(casingPrefab, ejectSocket.position, Quaternion.identity);

        Transform player = null;
        if (enemy == null)
        {
            player = GameController.Instance.player.transform; ;
        }
        else
        {
            player = enemy;
        }
         
        Vector3 velocity = player.right * Random.Range(5f, 7f)
                           + player.up * Random.Range(-3f, 3f)
                           + player.forward * Random.Range(-0.5f, 0.5f);

        casing.transform.eulerAngles = ejectSocket.eulerAngles;
        casing.transform.Rotate(Vector3.right * 90f);

        casing.SetVelocity(velocity,
                           new Vector3(0f, Random.Range(-15f, 15f), 0f));
        casing.gameObject.SetActive(true);
    }

    private GameObject GetPrefab()
    {
        GameObject casingPrefab;

        switch (casingType)
        {
            case CasingType.Small_Bullet:
                casingPrefab = Resources.Load<GameObject>("Casings/Casing_Small_Bullet");
                break;
            case CasingType.Big_Bullet:
                casingPrefab = Resources.Load<GameObject>("Casings/Casing_Big_Bullet");
                break;
            case CasingType.Grenade_Shell:
                casingPrefab = Resources.Load<GameObject>("Casings/Casing_Grenade_Shell");
                break;
            case CasingType.Shotgun_Shell:
                casingPrefab = Resources.Load<GameObject>("Casings/Casing_Shotgun_Shell");
                break;
            default:
                casingPrefab = Resources.Load<GameObject>("Casings/Casing_Small_Bullet");
                break;
        }
        return casingPrefab;
    }
}
