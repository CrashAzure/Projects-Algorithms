using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponDetails : MonoBehaviour
{
    [Header("Bullet Details")]
    [Tooltip("Weapon type")]
    public WeaponType weaponType;
    
    [Tooltip("This weapon's ammo clip capacity")]
    public int ammoClipCapacity;

    [Tooltip("This weapon's ammo capacity")]
    public int ammoCapacity;

    [Tooltip("This weapon's damage amount")]
    public int damageAmount;

    [Tooltip("This bullet's weight")]
    public float bulletWeight;

    [Tooltip("Bullet penetraion level")]
    [Range(0, 3)]
    public int bulletPenetrationLevel = 0;

    [Header("Weapon Details")]
    [Tooltip("Vertical Recoil for weapon fire")]
    [Range(0, 20f)]
    public float verticalRecoil = 5f;
    [Tooltip("Horizontal Recoil for weapon fire")]
    [Range(0, 20f)]
    public float horizontalRecoil = 3f;

    [Space(10)]
    [Header("Fire Info")]
    public float fireRate = 0.1f;
    public float speed = 500f;

    [Space(10)]
    [Header("Weapon Parts")]
    public int muzzleidex = 0;
    public int laserIndex = -1;
    public int gripIndex = -1;
    public int scopeIndex = 0;



}
