using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WeaponStatusUI : MonoBehaviour
{
    private CanvasGroup canvasGroup;
    private Coroutine fadeCoroutine;
    private TextMeshProUGUI text;
    [SerializeField]
    private Image shotModeBackground;
    private float gapAmount = 50f;

    private void Awake()
    {
        canvasGroup = GetComponent<CanvasGroup>();
        text = GetComponentInChildren<TextMeshProUGUI>();
    }

    public void SetText(string str)
    {
        text.text = str;
        RectTransform rect = shotModeBackground.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(text.preferredWidth + gapAmount, text.preferredHeight);
        rect.anchoredPosition = new Vector2(gapAmount / 2f, - gapAmount / 2f);
    }

    public void FadeUI(float duration, float delayTime)
    {
        if(fadeCoroutine!= null)
        {
            StopCoroutine(fadeCoroutine);
            fadeCoroutine = null;
        }

        fadeCoroutine = StartCoroutine(FadeCoroutine(duration, delayTime));
    }

    private IEnumerator FadeCoroutine(float duration, float delayTime)
    {
        yield return StartCoroutine(HelperUtilities.LerpCoroutine(0f, 0.8f, duration, a => canvasGroup.alpha = a));

        yield return new WaitForSeconds(delayTime);

        yield return StartCoroutine(HelperUtilities.LerpCoroutine(0.8f, 0f, duration, a => canvasGroup.alpha = a));
    }



}
