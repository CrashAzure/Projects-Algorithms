using cakeslice;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#region ----Enum----
public enum WeaponType
{
    None = -1,
    AR_01,
    AR_02,
    AR_03,
    GL_01,
    HandGun_01,
    HandGun_02,
    HandGun_03,
    HandGun_04,
    RL_01,
    Shotgun_01,
    SMG_01,
    SMG_02,
    SMG_03,
    SMG_04,
    SMG_05,
    Sniper_01,
    Sniper_02,
    Sniper_03,
}

public enum ItemType
{
    None,
    Weapon,
    Armor,
    Helmet,
    HealItem,
    Container,
    item,
}
#endregion ----Enum----

public class Item : MonoBehaviour
{
    #region Parameters
    [Header("Grid info")]
    [SerializeField]
    private int width;
    [SerializeField]
    private int height;
    [SerializeField]
    private Sprite iconImage;
    [HideInInspector]
    public Container container;

    [Header("Types")]
    [Tooltip("Item type")]
    public ItemType itemType;

    [HideInInspector]
    public ItemUIIcon itemUIIcon;

    [HideInInspector]
    public Rigidbody rigidBody;

    #endregion Parameters

    #region Unity Event
    public virtual void Awake()
    {
        if (GetComponent<WeaponDetails>() != null)
        {
            GetComponent<WeaponDetails>().enabled = (itemType == ItemType.Weapon);
        }
        if (GetComponent<ContainerDetails>() != null)
        {
            GetComponent<ContainerDetails>().enabled = (itemType == ItemType.Container);
        }
        if (GetComponent<Rigidbody>() == null && gameObject.layer != LayerMask.NameToLayer("First Person View"))
        {
            rigidBody = gameObject.AddComponent<Rigidbody>();
            if (itemType == ItemType.Container)
            {
                if(GetComponent<Stash>() != null)
                {
                    rigidBody.isKinematic = true;
                }
            }
        }
        else
        {
            rigidBody = GetComponent<Rigidbody>();
        }
        if(iconImage == null)
        {
            iconImage = Resources.Load<Sprite>("TestSprite");
        }

        if(GetComponentInChildren<Outline>() == null)
        {
            //GetComponentInChildren<Renderer>().gameObject.AddComponent<Outline>();
        }


        //width = Mathf.RoundToInt(iconImage.rect.width / 64f / reduceScale);
        //height = Mathf.RoundToInt(iconImage.rect.height / 64f / reduceScale);
        
        if (itemUIIcon == null)
        {
            itemUIIcon = Instantiate(Resources.Load<ItemUIIcon>("Item"));
            itemUIIcon.item = this;
            itemUIIcon.SetInfo(iconImage, width, height);
            itemUIIcon.transform.SetParent(transform, false);
            itemUIIcon.gameObject.SetActive(false);
        }
    }
    #endregion Unity Event

    #region Getter
    public WeaponType GetWeaponType() => GetComponent<WeaponDetails>().weaponType;
    public ItemType GetItemType() => itemType;
    public (int, int) GetWeaponCapacities() => (GetComponent<WeaponDetails>().ammoCapacity, GetComponent<WeaponDetails>().ammoClipCapacity);
    public Vector2Int GetSize() => new Vector2Int(width, height);
    public float GetDamageAmount() => GetComponent<WeaponDetails>().damageAmount;
    public bool HasWeapon() => itemType == ItemType.Weapon;
    #endregion Getter

}
