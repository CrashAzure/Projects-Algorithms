using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContainerDetails : MonoBehaviour
{
    [Header("Container Details")]
    [Tooltip("Container type")]
    public ContainerType container;

    [Tooltip("Rig type")]
    public RigType rigType;

    [Tooltip("BackPack type")]
    public BackPackType backPackType;
}
