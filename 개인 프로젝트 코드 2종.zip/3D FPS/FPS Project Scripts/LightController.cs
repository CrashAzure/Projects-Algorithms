using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightController : MonoBehaviour
{
    [Tooltip("Main Directional Light")]
    [SerializeField]
    private Light mainLight;

    private float timeSpeed = 1f;

    private Animator lightAnimator;

    // 1 day is 86400 seconds
    private float secondsForADay = 60f;
    [HideInInspector]
    public float ratio = 0f;

    void Start()
    {
        mainLight.gameObject.SetActive(true);
        lightAnimator = mainLight.GetComponent<Animator>();
        Time.timeScale = timeSpeed;
    }

    void Update()
    {
        //1 day is 86400 seconds
        ratio += Time.deltaTime * timeSpeed / secondsForADay;

        if (ratio > 1f)
        {
            ratio = 0f;
        }


        lightAnimator.SetFloat("Ratio", ratio);
    }
}
