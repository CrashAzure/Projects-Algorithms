using System.Collections;
using System.Collections.Generic;
//using UnityEditor.Animations;
using UnityEngine;

public class ThirdPersonAnimatorController : MonoBehaviour
{
    public List<Animator> animatorList = new List<Animator>();
    public List<Camera> playerCamera = new List<Camera>();
    public Camera thirdMainCamera;
    

    private void Awake()
    {
        foreach (Camera camera in GetComponentsInChildren<Camera>(true))
        {
            if (camera.clearFlags == CameraClearFlags.Skybox)
            {
                thirdMainCamera = camera;
            }
        }
    }

    public void SetThirdPersonCameraToMain()
    {
        foreach(Camera camera in playerCamera)
        {
            camera.enabled = false;
        }

        thirdMainCamera.enabled = true;
    }

    public void SetFirstPersonCameraToMain()
    {
        foreach (Camera camera in playerCamera)
        {
            camera.enabled = true;
        }

        thirdMainCamera.enabled = false;
    }
}
