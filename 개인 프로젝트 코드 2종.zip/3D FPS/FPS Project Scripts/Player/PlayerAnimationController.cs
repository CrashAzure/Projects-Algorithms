using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerAnimationController : MonoBehaviour
{
    #region Parameters
    public List<AnimatorOverrideController> animatorList = new List<AnimatorOverrideController>();
    public Transform root;
    public Coroutine jumpCoroutine;
    public Coroutine cameraCoroutine;
    private Animator animator;
    private CharacterInput playerInput;
    private CameraController mainCamera;
    private Coroutine cameraAngleCoroutine = null;
    private Coroutine cameraPositionCoroutine = null;
    private Coroutine yAngleFixedCoroutine = null;
    [HideInInspector]
    public bool isLeanForward = false;
    [HideInInspector]
    public bool isModeChange = false;

    public bool isLeaningFunction = false;

    
    #endregion Parameters

    #region Unity
    private void Awake()
    {
        animator = GetComponent<Animator>();
        playerInput = GameController.Instance.input;
        mainCamera = GameController.Instance.mainCameraController;
    }

    private void Update()
    {
        //if (!isLeaningFunction) return;

        if (animator.GetFloat("Leaning Forward") >= 0.97f)
        {
            isLeanForward = false;

            //ResetCameraAngle();

            //ResetCameraPosition();

            //ResetRootAngle();

            return;
        }

        if (playerInput.HasJump()) return;

        LeaningForward();
    }
    #endregion Unity

    #region Method
    private void LeaningForward()
    {
        float amount = 1 - animator.GetFloat("Leaning Forward");
        
        isLeanForward = true;

        //FixYAngle();

        //GameController.Instance.mainCameraController.transform.localPosition = 0.1f * Vector3.forward;
        //GameController.Instance.mainCameraController.transform.localEulerAngles = Vector3.right * amount * 90f;
        //root.localEulerAngles = (amount * 90f - 90f) * Vector3.right;

        //cameraAngleCoroutine = null;
        //cameraPositionCoroutine = null;
    }

    private void FixYAngle()
    {
        if (yAngleFixedCoroutine != null)
        {
            StopCoroutine(yAngleFixedCoroutine);
            yAngleFixedCoroutine = null;
        }
        yAngleFixedCoroutine = StartCoroutine(HelperUtilities.LerpCoroutine(transform.localEulerAngles,
                                                                                  Vector3.zero,
                                                                                  0.02f,
                                                                                  a => transform.localEulerAngles = a));
    }

    private void ResetRootAngle()
    {
        Vector3 startAngle = new Vector3(root.localEulerAngles.x, 0f, 0f);

        //root.localEulerAngles = -90f * Vector3.right;

        if (root.localEulerAngles.x >= -90f)
        {
            root.localEulerAngles = new Vector3(-90f, 0f, 0f);
            return;
        } 

        if (root.localEulerAngles.x < -90f)
        {
            root.localEulerAngles += new Vector3(Time.deltaTime / 0.02f, 0f, 0f);
        }
        //else
        //{
        //    root.localEulerAngles -= new Vector3(Time.deltaTime / 0.2f, 0f, 0f);
        //}
    }

    private void ResetCameraPosition()
    {
        if (playerInput.HasAimming()) return;
        Vector3 start = mainCamera.transform.localPosition;

        if (cameraPositionCoroutine != null) return;

        cameraPositionCoroutine = StartCoroutine(HelperUtilities.LerpCoroutine(start,
                                                 Vector3.zero,
                                                 0.02f,
                                                 a => mainCamera.transform.localPosition = a));

    }

    private void ResetCameraAngle()
    {
        if (playerInput.HasJump()) return;

        Vector3 start = mainCamera.transform.localEulerAngles;

        if (cameraAngleCoroutine != null) return;

        cameraAngleCoroutine = StartCoroutine(HelperUtilities.LerpCoroutine(start,
                                                                            Vector3.zero,
                                                                            0.02f,
                                                                            a => mainCamera.transform.localEulerAngles = a));
    }

    public void ModeChange(bool change)
    {
        isModeChange = change;
        animator.SetBool("Mode Change", isModeChange);
    }

    public bool GetAnimatorState(int layer, string name)
    {
        AnimatorClipInfo[] layerHolster = animator.GetCurrentAnimatorClipInfo(layer);

        if (layerHolster.Length == 0) return true;

        if (layerHolster[0].clip.name != name) return true;

        return false;
    }

    #endregion Method

    #region Events
    public void SetAnimator(int index)
    {
        if(animator == null)
        {
            animator = GetComponent<Animator>();
        }
        animator.runtimeAnimatorController = animatorList[index];
    }

    public void NightVisionLetUpOrDown()
    {
        GetComponentInChildren<CameraForNightVision>()?.LetNightVisionDownUp();
    }

    public void NightVisioning()
    {
        GetComponentInChildren<CameraForNightVision>()?.SetNightVision();
    }

    public void ModeChanged()
    {
        isModeChange = false;
        animator.SetBool("Mode Change", isModeChange);
    }

    public void ReloadDone()
    {
        GetComponentInParent<CharacterInput>().DoneToReload();
        playerInput.inventory.currentWeapon.GetComponent<WeaponStatus>().RefillClipAmmo();
    }

    public void Jumping()
    {
        if (!playerInput.HasJumpDone()) return;
        jumpCoroutine = StartCoroutine(JumpCoroutine(Vector3.zero, new Vector3(Random.Range(-15f, -10f), 0f, 0f), 0.1f));
    }


    private IEnumerator JumpCoroutine(Vector3 start, Vector3 end, float duration)
    {
        float elapsed = 0f;
        while (elapsed < 1f)
        {
            elapsed += Time.deltaTime / duration;

            GameController.Instance.mainCameraController.transform.localEulerAngles = Vector3.Lerp(start, end, elapsed);
            transform.GetChild(0).localEulerAngles = Vector3.Lerp(start, - end, elapsed);
            yield return null;
        }
    }
    #endregion Events
}
