using UnityEngine;

public class CheckInventory : MonoBehaviour
{
    // When outline be abled, lets check inevntory
    // This Iten can enter at inventory or not
    private EnableOutline enableOutline;
    private Inventory inventory;
    private GridNode targetGrid = null;
    private Container targetContainer;
    private Vector2Int resultCoord = Vector2Int.zero;
    private Item item;
    private void Start()
    {
        enableOutline = GameController.Instance.GetEnableOutline();
        inventory = GameController.Instance.playerInventory;
    }

    //private void Update()
    //{
    //    if (enableOutline.HasRayHit() && 
    //        (enableOutline.GetTargetTag() == "Item" || enableOutline.GetTargetTag() == "Weapon"))
    //     {
    //        if (item != null) return;
    //        item = enableOutline.GetRayPoint().transform.GetComponent<Item>();

    //        ProcessCheckInventory(item);
    //    }
    //    else
    //    {
    //        // target reset
    //        targetGrid = null;
    //        targetContainer = null;
    //        item = null;
    //        resultCoord = Vector2Int.zero;
    //    }
    //}

    /// <summary>
    /// When I direct aim to item, lets check inventory to put in that
    /// </summary>
    private void ProcessCheckInventory(Item item)
    {
        bool isDone = false;

        if(item.GetItemType() == ItemType.HealItem)
        {
            CheckRig(ref isDone, item);
            CheckBackPack(ref isDone, item);
            //CheckPocket(ref isDone, item);
            
        }
        else
        {
            CheckBackPack(ref isDone, item);
            //CheckPocket(ref isDone, item);
            CheckRig(ref isDone, item);
        }

    }

    private void CheckPocket(ref bool isDone, Item item)
    {
        if (isDone || inventory.pocketContainer == null) return;
        (bool, Vector2Int, GridNode) result = inventory.pocketContainer.ProcessCheckInventory(item);
        SetTargets(result, ref isDone, inventory.pocketContainer);
    }

    private void CheckRig(ref bool isDone, Item item)
    {
        if (isDone || inventory.rigContainer == null) return;
        (bool, Vector2Int, GridNode) result = inventory.rigContainer.ProcessCheckInventory(item);
        SetTargets(result, ref isDone, inventory.rigContainer);
    }

    private void CheckBackPack(ref bool isDone, Item item)
    {
        if (isDone || inventory.backpackContainer == null) return;

        (bool, Vector2Int, GridNode) result = inventory.backpackContainer.ProcessCheckInventory(item);

        SetTargets(result, ref isDone, inventory.backpackContainer);
    }

    private void SetTargets((bool, Vector2Int, GridNode) result, ref bool isDone , Container container)
    {
        if (!result.Item1) 
        {
            targetGrid = null;
            return;
        }

        isDone = true;
        resultCoord = result.Item2;
        targetGrid = result.Item3;
        targetContainer = container;
    }

    public void PutItemOnInventory()
    {
        // target reset
        targetGrid = null;
        targetContainer = null;
        item = null;
        resultCoord = Vector2Int.zero;

        if (enableOutline.HasRayHit() &&
            (enableOutline.GetTargetTag() == "Item" || enableOutline.GetTargetTag() == "Weapon" || enableOutline.GetRayPoint().transform.GetComponent<Item>() != null))
        {
            item = enableOutline.GetRayPoint().transform.GetComponent<Item>();

            ProcessCheckInventory(item);
        }
        //else
        //{
        //    // target reset
        //    targetGrid = null;
        //    targetContainer = null;
        //    item = null;
        //    resultCoord = Vector2Int.zero;
        //}

        if (targetGrid == null || targetContainer == null || item == null) return;

        GetComponent<CharacterInput>().HasAnimator().SetTrigger("Take");

        inventory.PutItemOnContainer(targetGrid, resultCoord, item, targetContainer);
    }


}
