using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;

public class CharacterInput : MonoBehaviour
{
    #region Parameters
    public float plusGravity = 0.1f;
    [HideInInspector]
    public Transform characterRoot;
    private float moveSpeed = 3.0f;
    private float runSpeed = 6.0f;
    private float currentSpeed = 0f;
    private float aimmingSpeed = 5f;
    private float aimming = 0f;
    private float jumpingHeight = 4.5f;
    private float leaningInput = 0f;
    private float doubleClickTimer = 0f;
    [Range(0.01f, 3f)]
    public float sensitivity = 1f;
    
    [HideInInspector]
    public int currentEnableWeapon = 1;
    [HideInInspector]
    public int currentWeaponNumber = 1;

    private Player player;
    private Rigidbody rigidBody;
    private CapsuleCollider playerCapsuleCollider;
    [SerializeField]
    private CapsuleCollider controllingCapsuleColldier;
    private PlayerAnimationController playerAnimationController;
    // Check condition on weapon
    [SerializeField]
    private Animator[] animators;
    private Animator playerAnimator;
    private AimScope aimScope;
    private EnableOutline enableOutline;
    [HideInInspector]
    public Inventory inventory;

    private IA_Player iA_Player;
    private Vector3 movementInput = Vector3.zero;
    private Vector2 mouseInput = Vector2.zero;
    private bool isMovementsInput = false;
    private bool isMove = false;
    private bool isRun = false;
    private bool isMouseInput = false;
    private bool isAim = false;
    private bool isReload = false;
    private bool isFire = false;
    private bool isJump = false;
    private bool isEmpty = false;
    private bool isJumping = false;
    private bool isJumpDone = true;
    private bool isCrouch = false;
    [HideInInspector]
    public bool isHolstered = false;
    private PlayerStatus status;

    private Coroutine aimmingCoroutine = null;
    private Coroutine swappingCoroutine = null;
    private Coroutine crouchingCoroutine = null;
    private Coroutine leaningCoroutine = null;
    private Coroutine movementCoroutine = null;

    private ItemUIIcon clickedIcon = null;
    #endregion Parameters

    #region Unity
    private void Awake()
    {
        player = GetComponent<Player>();
        playerAnimationController = GetComponentInChildren<PlayerAnimationController>(true);
        playerAnimator = playerAnimationController.GetComponent<Animator>();
        characterRoot = playerAnimationController.transform;
        SetInputActions();
        status = GetComponent<PlayerStatus>();
        inventory = GetComponentInChildren<Inventory>(true);

        if (inventory.currentWeapon == null)
        {
            swappingCoroutine = StartCoroutine(ThrowoutCurrentWeapon());
            currentEnableWeapon = 0;
        }
        else
        {
            currentEnableWeapon = (int)inventory.currentWeapon.GetComponent<WeaponStatus>().weaponDetails.GetWeaponType();
        }
        playerAnimationController.SetAnimator(currentEnableWeapon);

        if (!status.isInGame)
        {
            InitializeParameters();
            iA_Player.Player.Disable();
            iA_Player.PlayerInventoryUI.Enable();
        }
    }
    private void Start()
    {
        ClampXAxisAngle();
    }

    private void Update()
    {
        //CheckLeaningForward();
        CheckInput();

        ProcessLeaning();
        ProcessMouseInput();
        ClampXAxisAngle();
        CheckMovementToFront();

        //CheckYVelocity();
        //CheckHeightCondition();
        SetInputSystemInventory();

        ProcessMoveCharacter();
        ProcessJumpCharacter();

        if (!isJumpDone)
        {
            if(rigidBody.velocity.y < 0)
                rigidBody.velocity += new Vector3(0f, -plusGravity, 0f);
            else
                rigidBody.velocity += new Vector3(0f, -plusGravity / 2f, 0f);
        }

        if(UIManager.Instance.CenterPoint.gameObject.activeSelf != isHolstered
            && status.isInGame)
        {
            UIManager.Instance.CenterPoint.gameObject.SetActive(isHolstered);
        }

        if (isRun || isJump) ProcessLerpLeaning(0f);
    }

    private void LateUpdate()
    {
        SetAnimatorParameters();
    }

    //private void OnCollisionStay(Collision collision)
    //{
    //    if (collision.gameObject.layer == 6) return;
    //    if (rigidBody.velocity.y > 0f) return;

    //    foreach (var contact in collision.contacts)
    //    {
    //        if (contact.point.y - criterion.position.y <= 0.2f)
    //        {
    //            isJumpDone = true;
    //            isJump = false;
    //            isJumping = false;
    //        }
    //    }

    //}

    private void OnCollisionEnter(Collision collision)
    {
        if (!isJumpDone)
        {
            foreach (ContactPoint contact in collision.contacts)
            {
                if (contact.point.y <= transform.position.y + 0.7f)
                {
                    isJumpDone = true;
                    isJump = false;
                    isJumping = false;
                    
                    if (playerAnimationController.jumpCoroutine == null) return;

                    playerAnimationController.StopCoroutine(playerAnimationController.jumpCoroutine);
                    playerAnimationController.jumpCoroutine = null;
                    GameController.Instance.mainCameraController.transform.localEulerAngles = Vector3.zero;
                    playerAnimationController.transform.GetChild(0).localEulerAngles = Vector3.zero;
                }
            }
        }
        
    }
    #endregion Unity

    #region New Input System

    /// <summary>
    /// Initialise Input actions
    /// </summary>
    private void SetInputActions()
    {
        iA_Player = new IA_Player();
        iA_Player.Enable();

        iA_Player.Player.Movement.started += OnMove;
        iA_Player.Player.Movement.started += HasInput;
        iA_Player.Player.Movement.performed += OnMove;
        iA_Player.Player.Movement.canceled += OnMove;

        iA_Player.Player.Run.started += OnRunning;
        iA_Player.Player.Run.started += HasInput;
        iA_Player.Player.Run.canceled += OnRunning;

        iA_Player.Player.Jump.started += OnJumping;
        iA_Player.Player.Jump.started += HasInput;

        iA_Player.Player.Aim.started += OnAiming;
        iA_Player.Player.Aim.performed += OnAiming;
        iA_Player.Player.Aim.canceled += OnAiming;

        iA_Player.Player.Num1.started += OnNum1Press;
        iA_Player.Player.Num2.started += OnNum2Press;
        iA_Player.Player.Num3.started += OnNum3Press;

        iA_Player.Player.Look.started += OnLooking;
        iA_Player.Player.Look.performed += OnLooking;
        iA_Player.Player.Look.canceled += OnLooking;

        iA_Player.Player.Reload.started += OnReloading;

        iA_Player.Player.Fire.started += OnFireGun;
        iA_Player.Player.Fire.performed += OnFireGun;
        iA_Player.Player.Fire.canceled += OnFireGun;

        iA_Player.Player.ShotMode.started += OnShotModeSetting;

        iA_Player.Player.Leaning.started += OnLean;
        iA_Player.Player.Leaning.performed += OnLean;
        iA_Player.Player.Leaning.canceled += OnLean;

        iA_Player.Player.Holster.started += OnHolstering;

        iA_Player.Player.Crouch.started += OnCrouching;

        iA_Player.Player.SelectUIWheel.started += OnUpdatingSelectUI;

        iA_Player.Player.SelectUI.started += OnSelectingUI;

        iA_Player.Player.Inventory.started += OnInventoryOpen;

        iA_Player.Player.Interact.started += OnInteracting;

        iA_Player.Player.NightVision.started += OnNightVisioning;

        iA_Player.PlayerInventoryUI.CloseTab.started += OnInventoryOpen;
        iA_Player.PlayerInventoryUI.RotateIcon.started += OnRatatingIcon;
        iA_Player.PlayerInventoryUI.ThrowOutItem.started += OnThrowOut;
        iA_Player.PlayerInventoryUI.Click.started += OnClickIcon;
    }



    private void OnShotModeSetting(InputAction.CallbackContext context)
    {
        if (!context.started) return;
        if (playerAnimationController.isModeChange) return;
        if (isReload) return;
        bool checkAnimator = playerAnimationController.GetAnimatorState(playerAnimator.GetLayerIndex("Layer NightVision"), "NightVision"); ;
        if (!checkAnimator) return;
        if (!status.isInGame) return;

        playerAnimationController.ModeChange(true);
        GetComponent<ModeChangeSound>().ModeChange();
        inventory.currentWeapon.ChangeShotMode();
        
    }

    private void OnNightVisioning(InputAction.CallbackContext context)
    {
        if (!context.started) return;
        bool checkAnimator = playerAnimationController.GetAnimatorState(playerAnimator.GetLayerIndex("Layer NightVision"), "NightVision"); ;
        if (!checkAnimator) return;
        if (isReload) return;
        if (isFire) return;
        if (!status.isInGame) return;
        playerAnimator.SetTrigger("NightVision");
    }

   
    private void OnHolstering(InputAction.CallbackContext context)
    {
        if (!context.started) return;
        if (isReload) return;
        if (inventory.currentWeapon == null) return;
        if (!status.isInGame) return;

        isHolstered = isHolstered ? false : true;
    }

    public void OnInteracting(InputAction.CallbackContext context)
    {
        if (context.phase != InputActionPhase.Started) return;

        GameObject selectUI = UIManager.Instance.selectUI.gameObject;

        if (selectUI.activeSelf)
        {
            selectUI.SetActive(false);
        }
        else if (enableOutline.HasRayHit())
        {
            selectUI.SetActive(true);
            UIManager.Instance.selectUI.SetPosition(enableOutline.GetRayPoint().transform.position);
        }
    }

    public void HasInput(InputAction.CallbackContext context)
    {
        if (context.phase == InputActionPhase.Started)
        {
            isMovementsInput = true;
        }
    }

    /// <summary>
    /// Failed, plz fix this method
    /// </summary>
    public void OnCrouching(InputAction.CallbackContext context)
    {
        if (context.phase != InputActionPhase.Started) return;
        if (!isJumpDone) return;
        if (!status.isInGame) return;

        isRun = false;

        if (isCrouch)
        {
            ProcessCrouch(1.78f, 0.2f);
            isCrouch = false;
            currentSpeed *= 2;
        }
        else
        {
            ProcessCrouch(1.78f / 2f, 0.2f);
            isCrouch = true;
            currentSpeed /= 2;
        }

        UIManager.Instance.crouchingUI.SetCrouchIcon(isCrouch);
    }

    public void OnInventoryOpen(InputAction.CallbackContext context)
    {
        if (context.phase != InputActionPhase.Started) return;

        UIManager.Instance.DisableAllLootingObjects();

        if (!status.isInGame)
        {
            UIManager.Instance.stashUI.SetActive(true);
        }

        ProcessInventoryOpen();
    }

    public void ProcessInventoryOpen()
    {
        GameObject inventoryGO = UIManager.Instance.inventoryUI.gameObject;

        if (inventoryGO.activeSelf)
        {
            if (status.isInGame)
            {
                UIManager.Instance.playerStatusUI.gameObject.SetActive(true);
            }

            inventoryGO.SetActive(false);

            foreach (var window in UIManager.Instance.canvas.GetComponentsInChildren<WindowController>())
            {
                window.gameObject.SetActive(false);
                window.GetComponentInChildren<GridNode>().container.GetComponent<Item>().itemUIIcon.isInspecting = false;
            }
        }
        else
        {
            UIManager.Instance.playerStatusUI.gameObject.SetActive(false);
            inventoryGO.SetActive(true);
        }
    }

    public void OnSelectingUI(InputAction.CallbackContext context)
    {
        GameObject selectUI = UIManager.Instance.selectUI.gameObject;

        if (!selectUI.activeSelf) return;

        if (context.phase == InputActionPhase.Started)
        {
            UIManager.Instance.selectUI.ClickCurrentButton();
        }
    }

    public void OnJumping(InputAction.CallbackContext context)
    {
        if (!status.isInGame) return;

        if (context.phase == InputActionPhase.Started)
        {
            GetComponentInChildren<PlayerAnimationController>().Jumping();

            isJump = true;
            isJumpDone = false;

            if (isCrouch)
            {
                ProcessCrouch(1.78f, 0.2f);
                isCrouch = false;
                currentSpeed *= 2;
                UIManager.Instance.crouchingUI.SetCrouchIcon(isCrouch);
            }

            if (isAim)
            {
                isAim = false;
                ProcessAiming(0f, false);
            }
        }

    }

    public void OnLean(InputAction.CallbackContext context)
    {
        if (!status.isInGame) return;

        if (context.performed)
        {
            if (isJump || isRun) return;

            float input = context.ReadValue<float>();

            ProcessLerpLeaning(input);
        }

        if (context.canceled)
        {
            ProcessLerpLeaning(0f);
        }
    }

    public void OnMove(InputAction.CallbackContext context)
    {
        if (!status.isInGame) return;

        if (context.started || context.performed)
        {
            Vector2 movementInput = context.ReadValue<Vector2>();
            Vector3 startMovement = this.movementInput;

            ProcessMoving(startMovement, new Vector3(movementInput.x, 0f, movementInput.y), 0.2f);

            SetBoolForInput<float>(ref isMove, context, a => currentSpeed = a, 0f);
        }
        else if(context.canceled)
        {
            Vector3 startMovement = this.movementInput;

            ProcessMoving(startMovement, Vector3.zero, 0.2f);

            isMove = false;
        }
        
    }

    private void ProcessMoving(Vector3 start, Vector3 end, float duration)
    {
        if (movementCoroutine != null)
        {
            StopCoroutine(movementCoroutine);
            movementCoroutine = null;
        }
        movementCoroutine = StartCoroutine(HelperUtilities.LerpCoroutine(start,
                                                                         end,
                                                                         duration,
                                                                         a => this.movementInput = a));
    }

    public void OnNum1Press(InputAction.CallbackContext context)
    {
        if (swappingCoroutine != null) return;
        if (!status.isInGame) return;

        bool checkAnimator = playerAnimationController.GetAnimatorState(playerAnimator.GetLayerIndex("Layer NightVision"), "NightVision");
        if (!checkAnimator) return;
        if (isReload) return;
        

        if (SetCurrentWeapon(WeaponSlotType.Weapon1))
        {
            ProcessSwapCoroutine();
        }
    }

    public void OnNum2Press(InputAction.CallbackContext context)
    {
        if (swappingCoroutine != null) return;
        if (!status.isInGame) return;

        bool checkAnimator = playerAnimationController.GetAnimatorState(playerAnimator.GetLayerIndex("Layer NightVision"), "NightVision");
        if (!checkAnimator) return;
        if (isReload) return;

        if (SetCurrentWeapon(WeaponSlotType.Weapon2))
        {
            ProcessSwapCoroutine();
        }
    }
    public void OnNum3Press(InputAction.CallbackContext context)
    {
        if (swappingCoroutine != null) return;
        if (!status.isInGame) return;

        bool checkAnimator = playerAnimationController.GetAnimatorState(playerAnimator.GetLayerIndex("Layer NightVision"), "NightVision");
        if (!checkAnimator) return;
        if (isReload) return;

        
        if (SetCurrentWeapon(WeaponSlotType.Pistol))
        {
            ProcessSwapCoroutine();
        }
    }


    public void OnReloading(InputAction.CallbackContext context)
    {
        if (context.phase != InputActionPhase.Started ||
            playerAnimator.GetCurrentAnimatorStateInfo(2).tagHash == Animator.StringToHash("Reload") ||
            inventory.currentWeapon == null ||
            inventory.currentWeapon.GetComponent<WeaponStatus>().HasFull() ||
            isReload
            ||!status.isInGame) return;

        bool checkAnimator = playerAnimationController.GetAnimatorState(playerAnimator.GetLayerIndex("Layer NightVision"), "NightVision");
        if (!checkAnimator) return;

        isFire = false;
        WeaponController weapon = inventory.currentWeapon;

        if (weapon.GetComponent<WeaponStatus>().HasEmpty())
        {
            isEmpty = true;
            weapon.GetComponent<Animator>().Play("Reload Empty", 0, 0.0f);
            weapon.GetComponent<WeaponSounds>().PlayReloadEmptySound();
        }
        else
        {
            isEmpty = false;
            weapon.GetComponent<Animator>().Play("Reload", 0, 0.0f);
            weapon.GetComponent<WeaponSounds>().PlayReloadSound();
        }

        isReload = true;

        
    }



    public void OnAiming(InputAction.CallbackContext context)
    {
        if (isRun) return;
        if (isJump) return;
        if (inventory.currentWeapon == null) return;
        if (!status.isInGame) return;

        bool checkAnimator = playerAnimationController.GetAnimatorState(playerAnimator.GetLayerIndex("Layer NightVision"), "NightVision");
        if (!checkAnimator) return;

        switch (context.phase)
        {
            case InputActionPhase.Started:
                isAim = true;
                ProcessAiming(1f);
                break;

            case InputActionPhase.Performed:
                isAim = true;
                break;

            case InputActionPhase.Canceled:
                if (isAim)
                {
                    isAim = false;
                    ProcessAiming(0f, false);
                }
                break;

            default:
                break;
        }
    }

    public void OnRunning(InputAction.CallbackContext context)
    {
        if (!status.isInGame) return;

        if (context.canceled)
        {
            isRun = false;
            return;
        }
        if (isAim) return;
        if (isCrouch) return;
        if (!isJumpDone) return;
        if (movementInput.z <= 0) return;
        
        SetBoolForInput(ref isRun, context);
    }

    public void OnLooking(InputAction.CallbackContext context)
    {
        if (!status.isInGame) return;

        mouseInput = context.ReadValue<Vector2>();

        SetBoolForInput(ref isMouseInput, context);
    }

    public void OnFireGun(InputAction.CallbackContext context)
    {
        if (!status.isInGame) return;

        if (isHolstered
            || isReload) return;

        if (UIManager.Instance.selectUI.gameObject.activeSelf
            || UIManager.Instance.inventoryUI.gameObject.activeSelf
            || inventory.currentWeapon == null
            || inventory.currentWeapon.GetComponent<WeaponStatus>().GetCurrentAmmo() == 0) return;

        bool checkAnimator = playerAnimationController.GetAnimatorState(playerAnimator.GetLayerIndex("Layer NightVision"), "NightVision");
        if (!checkAnimator) return;

        SetBoolForInput(ref isFire, context);
    }

    public void OnUpdatingSelectUI(InputAction.CallbackContext context)
    {
        Vector2 wheelInput = context.ReadValue<Vector2>();

        UIManager.Instance.selectUI.OnPointerEnter(wheelInput.y);
    }

    /// <summary>
    /// Set boolean using call back context
    /// </summary>
    private void SetBoolForInput(ref bool boolean, InputAction.CallbackContext context)
    {
        switch (context.phase)
        {
            case InputActionPhase.Started:
                boolean = true;
                break;

            case InputActionPhase.Performed:
                boolean = true;
                break;

            case InputActionPhase.Canceled:
                boolean = false;
                break;

            default:
                break;
        }
    }

    /// <summary>
    /// Set boolean using call back context with delegate
    /// </summary>
    private void SetBoolForInput<T>(ref bool boolean, InputAction.CallbackContext context, Action<T> action, T type1)
    {
        switch (context.phase)
        {
            case InputActionPhase.Started:
                boolean = true;
                break;

            case InputActionPhase.Performed:
                boolean = true;
                break;

            case InputActionPhase.Canceled:
                boolean = false;
                action(type1);
                break;

            default:
                break;
        }
    }
    #endregion New Input System

    #region Inventory New Input System
    private void OnClickIcon(InputAction.CallbackContext context)
    {
        if (!context.started) return;

        
        if (doubleClickTimer > 0f)
        {
            ItemUIIcon icon = UIManager.Instance.GetFocousedIcon();

            if (clickedIcon != icon) return;

            if (icon != null && icon.isInspecting == false)
            {
                if (icon.item.GetItemType() != ItemType.Container) return;
                Container container = icon.item.GetComponent<Container>();
                if (container.isEquieped) return;

                GameObject windowPrefab = Resources.Load<GameObject>("ContainerWindow");
                WindowController window = (WindowController)PoolManager.Instance.ReuseComponent(windowPrefab,
                                                                                                new Vector3(0f,0f,0f),
                                                                                                Quaternion.identity);
                ContainerUI containerUI = window.GetComponent<ContainerUI>();

                window.transform.SetParent(UIManager.Instance.canvas.transform, false);
                containerUI.SetContainerUI(container);
                //foreach (var grid in container.gridList)
                //{
                //    grid.transform.SetParent(window.mainRect.transform, false);
                //}

                window.gameObject.SetActive(true);
                icon.isInspecting = true;
            }
        }
        else
        {
            StartCoroutine(DoubleClickCheckCoroutine());
        }
    }

    private IEnumerator DoubleClickCheckCoroutine()
    {
        clickedIcon = UIManager.Instance.GetFocousedIcon();
        while (doubleClickTimer < 0.2f)
        {
            doubleClickTimer += Time.deltaTime;
            yield return null;
        }
        clickedIcon = null;
        doubleClickTimer = 0;
    }

    private void OnRatatingIcon(InputAction.CallbackContext context)
    {
        if (!context.started) return;

        ItemUIIcon icon = UIManager.Instance.selectedIcon;

        if (icon != null)
        {
            icon.isRotate = !icon.isRotate;
        }
    }

    private void OnThrowOut(InputAction.CallbackContext context)
    {
        if (!context.started) return;

        GetFocusedItem(out GameObject focusedItem);

        if (focusedItem == null) return;

        ItemUIIcon icon = focusedItem.GetComponent<ItemUIIcon>();
        GridNode parentGrid = icon.GetComponentInParent<GridNode>();


        if (parentGrid != null)
        {
            parentGrid.container.ThrowOutItem(icon.index - 1, player);
        }
        else
        {
            Item item = icon.item;

            if (item.GetItemType() == ItemType.Weapon)
            {
                if (isReload) return;
                if (item.GetComponent<WeaponController>() == inventory.currentWeapon)
                {
                    swappingCoroutine = StartCoroutine(ThrowoutCurrentWeapon());
                }

                WeaponSlot slot = item.GetComponentInParent<WeaponSlot>();
                item.transform.SetParent(GameController.Items.transform);
                item.GetComponent<WeaponStatus>().SetWeaponStatus(false);
                slot.UpdateItemIndex();
            }
            else if (item.GetItemType() == ItemType.Container)
            {
                Container container = item.GetComponent<Container>();
                container.isEquieped = false;
                foreach (var grid in container.gridList)
                {
                    grid.transform.SetParent(null, false);
                }
                item.transform.SetParent(null);
                inventory.SetContainers();
            }
            else if (item.GetItemType() == ItemType.Helmet)
            {
                inventory.helmetSlot.ThrowOutItem(icon.index - 1, player);
            }
            else if (item.GetItemType() == ItemType.Armor)
            {
                inventory.armorSlot.ThrowOutItem(icon.index - 1, player);
            }

            foreach(var slotUI in UIManager.Instance.armorSlots)
            {
                slotUI.InitWeaponSlotUI(player);
            }

            icon.InitIcon();
            

            if (item.rigidBody != null)
            {
                item.rigidBody.useGravity = true;
                item.rigidBody.isKinematic = false;
                item.rigidBody.velocity += new Vector3(Camera.main.transform.forward.x, 0f, Camera.main.transform.forward.z);
            }
            else
            {
                item.transform.SetParent(GameController.Items.transform);
            }

            item.transform.position = Camera.main.transform.position;

            foreach(var obj in item.GetComponentsInChildren<Transform>())
            {
                obj.gameObject.layer = LayerMask.NameToLayer("Interactable");
            }
            item.GetComponent<Rigidbody>().isKinematic = false;
            item.gameObject.SetActive(true);
        }
    }

    private void GetFocusedItem(out GameObject focusedItem)
    {
        List<RaycastResult> rayResults = new List<RaycastResult>();
        PointerEventData pointer = new PointerEventData(EventSystem.current);
        pointer.position = Input.mousePosition;
        EventSystem.current.RaycastAll(pointer, rayResults);

        foreach (var ray in rayResults)
        {
            if (ray.gameObject.transform.parent.GetComponent<ItemUIIcon>() != null)
            {
                focusedItem = ray.gameObject.transform.parent.gameObject;
                return;
            }
        }
        focusedItem = null;
    }

    #endregion

    #region Getter
    public bool HasFire() => isFire;

    public bool HasRun() => isRun;

    public bool HasCrouch() => isCrouch;

    public bool HasMove() => isMove;

    public bool HasJump() => isJump;

    public bool HasJumpDone() => isJumpDone;

    public bool HasAimming() => isAim;

    public Animator HasAnimator() => playerAnimator;

    public EnableOutline HasEnableOutline() => enableOutline;
    #endregion Getter

    #region Method

    private IEnumerator ThrowoutCurrentWeapon()
    {
        if (aimming > 0f)
        {
            isAim = false;

            //if (aimmingCoroutine != null)
            //{
            //    StopCoroutine(aimmingCoroutine);
            //    aimmingCoroutine = null;
            //}
            ProcessAiming(0f, false);

            yield return aimmingCoroutine;
        }

        isHolstered = true;

        foreach (var animator in animators)
        {
            animator.SetBool("Holstered", isHolstered);
        }

        swappingCoroutine = null;
        inventory.currentWeapon = null;

    }
    /// <summary>
    /// Populate components from player script
    /// </summary>
    public void Init()
    {
        rigidBody = GetComponent<Rigidbody>();
        playerCapsuleCollider = GetComponent<CapsuleCollider>();
        enableOutline = GetComponent<EnableOutline>();
    }

    /// <summary>
    /// Set fire boolean
    /// </summary>
    public void SetFire(bool fire)
    {
        isFire = fire;
    }

    private void SetInputSystemInventory()
    {
        if (status.isDead) return;
        if (!status.isInGame) 
        {
            InitializeParameters();
            iA_Player.Player.Disable();
            iA_Player.PlayerInventoryUI.Enable();
        }

        if (UIManager.Instance.inventoryUI.gameObject.activeSelf)
        {
            InitializeParameters();
            iA_Player.Player.Disable();
            iA_Player.PlayerInventoryUI.Enable();
        }
        else
        {
            iA_Player.Player.Enable();
            iA_Player.PlayerInventoryUI.Disable();
        }
    }

    public void DisableInput()
    {
        InitializeParameters();
        iA_Player.Player.Disable();
        iA_Player.PlayerInventoryUI.Disable();
    }

    public void EnableInput()
    {
        InitializeParameters();
        iA_Player.Player.Enable();
        iA_Player.PlayerInventoryUI.Disable();
    }

    private void InitializeParameters()
    {
        isMove = false;
        isRun = false;
        isAim = false;
        isFire = false;
    }

    /// <summary>
    /// Set holstered
    /// </summary>
    public void SetHolstered(bool holstered)
    {
        isHolstered = holstered;
    }

    /// <summary>
    /// if player movements(move, jump ect...) input exists, then clost inventory ui
    /// </summary>
    private void CheckInput()
    {
        if (!isMovementsInput) return;

        GameObject inventory = UIManager.Instance.inventoryUI.gameObject;

        if (inventory.activeSelf)
        {
            inventory.SetActive(false);
        }

        isMovementsInput = false;
    }

    /// <summary>
    /// Process leaning
    /// </summary>
    private void ProcessLeaning()
    {
        transform.localEulerAngles = new Vector3(transform.localEulerAngles.x,
                                                       transform.localEulerAngles.y,
                                                       -leaningInput * 5f);
    }

    /// <summary>
    /// Check reloaing is done
    /// </summary>
    public void DoneToReload()
    {
        isReload = false;
    }

    /// <summary>
    /// Set Animator's Parameters
    /// </summary>
    private void SetAnimatorParameters()
    {
        foreach(var animator in animators)
        { 
            animator.SetFloat("Movement", currentSpeed);
            animator.SetFloat("Horizontal", movementInput.x);
            animator.SetFloat("Vertical", movementInput.z);
            animator.SetBool("Running", isRun && isMove);
            animator.SetBool("Aim", isAim);
            animator.SetBool("Jump", isJump);
            animator.SetBool("Reload", isReload);
            animator.SetBool("EmptyClip", isEmpty);
            animator.SetFloat("Aiming", aimming);
            animator.SetFloat("Leaning Input", leaningInput);
            animator.SetBool("Holstered", isHolstered);
            animator.SetBool("Crouching", isCrouch);
        }
    }

    /// <summary>
    /// Clam player X axis angle
    /// </summary>
    private void ClampXAxisAngle()
    {
        if (characterRoot.localEulerAngles.x >= 80f && characterRoot.localEulerAngles.x <= 110f)
        {
            characterRoot.localEulerAngles = new Vector3(80f,
                                                    0f,
                                                    0f);
        }

        if (characterRoot.localEulerAngles.x <= 280f && characterRoot.localEulerAngles.x >= 250f)
        {
            characterRoot.localEulerAngles = new Vector3(280f,
                                                    0f,
                                                    0f);
        }
    }

    /// <summary>
    /// Process crouch
    /// </summary>
    private void ProcessCrouch(float targetheight, float delayTime)
    {
        if(crouchingCoroutine != null)
        {
            StopCoroutine(crouchingCoroutine);
            crouchingCoroutine = null;
        }
        crouchingCoroutine = StartCoroutine(LerpCrouch(targetheight, delayTime));
    }

    private IEnumerator LerpLeaning(float target)
    {
        float start = leaningInput;
        float delayTime = 1f;
        float elapsed = 0f;
        float currentRotationRatio = transform.localEulerAngles.z / 5f;

        if(currentRotationRatio > 36f)
        {
            currentRotationRatio -= 72f;
        }

        float delayMultiply = Mathf.Abs(target + currentRotationRatio) / 5f;

        while (elapsed < 1f)
        {
            elapsed += Time.deltaTime / (delayTime * delayMultiply);

            leaningInput = Mathf.Lerp(start, target, elapsed);

            yield return null;
        }
    }

    private IEnumerator LerpCrouch(float targetHeight, float delayTime)
    {
        float elapsed = 0f;
        float checkHeight = 1.7f;

        if(targetHeight < 1.5f)
        {
            checkHeight /= 2;
        }
        
        while(elapsed <= 1f)
        {
            elapsed += Time.deltaTime / delayTime;
            playerCapsuleCollider.height = Mathf.Lerp(playerCapsuleCollider.height, targetHeight, elapsed);
            controllingCapsuleColldier.height = Mathf.Lerp(controllingCapsuleColldier.height, checkHeight, elapsed);
            yield return null;
        }
    }

    /// <summary>
    /// Process Jump
    /// </summary>
    private void ProcessJumpCharacter()
    {
        JumpUp();
        //CheckHeightCondition();
    }

    /// <summary>
    /// Process Jump up
    /// </summary>
    private void JumpUp()
    {
        if (!isJump) return;
        if (isJumping) return;

        rigidBody.velocity += new Vector3(0f, jumpingHeight, 0f);
        isJumping = true;
    }

    /// <summary>
    /// Unused
    /// </summary>
    private void CheckHeightCondition()
    {
        Vector3 cameraPos = GameController.Instance.mainCameraController.transform.position;
        Vector3 target = transform.position - playerCapsuleCollider.center;

        RaycastHit[] rayHits = Physics.BoxCastAll(target,
                                                  new Vector3(0.5f, 1.78f / 2f, 0.5f), 
                                                  Vector3.down, 
                                                  playerAnimator.transform.rotation, 
                                                  2f, 
                                                  ~(1 << LayerMask.NameToLayer("Character"))
                                                   + ~(1 << LayerMask.NameToLayer("Third Person View")));

        if (rayHits.Length == 0 || isJumpDone == true || (isJump = true && rigidBody.velocity.y >= 0f)) return;

        isJumpDone = true;
        isJump = false;
        isJumping = false;


        //float minY = 10000;

        //foreach (var ray in rayHits)
        //{
        //    if (minY == 10000)
        //    {
        //        minY = target.y - ray.point.y;
        //    }

        //    if (minY > target.y - ray.point.y)
        //    {
        //        minY = target.y - ray.point.y;
        //    }
        //}

        //if (minY <= 1f && !isJumpDone && rigidBody.velocity.y < 0)
        //{
        //    isJumpDone = true;
        //    isJump = false;
        //    isJumping = false;
        //}

    }

    //private void OnCollisionEnter(Collision collision)
    //{
    //    if(collision.gameObject.layer == 3)
    //    {
    //        InitializeJumping(collision.gameObject.layer);
    //    }

    //}

    private void InitializeJumping(int layer)
    {
        if (layer == 3)
        {
            isJump = false;
            isJumping = false;
        }
    }


    private void ProcessLerpLeaning(float target)
    {
        if (leaningCoroutine != null)
        {
            StopCoroutine(leaningCoroutine);
            leaningCoroutine = null;
        }

        leaningCoroutine = StartCoroutine(LerpLeaning(target));
    }



    /// <summary>
    /// if get move input, then set rigidbody velocity
    /// </summary>
    private void ProcessMoveCharacter()
    {
        currentSpeed = SetSpeed();

        if (!isMove) return;
        if (isJump) return;
        
        
        currentSpeed /= isCrouch ? 2f : 1f;
        currentSpeed *= isAim ? 0.75f : 1f;

        Vector3 velocity = new Vector3(currentSpeed * movementInput.x,
                                        rigidBody.velocity.y,
                                        currentSpeed * movementInput.z);

        rigidBody.velocity = RotateVelocity(velocity);
    }

    private void ProcessAiming(float target, bool isIncrease = true)
    {
        if(aimmingCoroutine != null)
        {
            StopCoroutine(aimmingCoroutine);
            aimmingCoroutine = null;
        }

        aimmingCoroutine = StartCoroutine(AimingCoroutine(target, isIncrease));
    }

    private IEnumerator AimingCoroutine(float target, bool isIncrease = true)
    {
        if (isAim)
        {
            inventory.currentWeapon.GetComponentInChildren<Scope>()?.OnAim();
        }
        else
        {
            GameController.Instance.mainCameraController.CameraRePosiiton(Vector3.zero, 0.0f);
            inventory.currentWeapon.GetComponentInChildren<Scope>()?.OnAimStop();
            GameController.Instance.mainCameraController.SetPosition(Vector3.zero);
            GameController.Instance.mainCameraController.SetRotation(Vector3.zero);
        }

        while (true)
        {
            if (isIncrease)
            {
                aimming += aimmingSpeed * Time.deltaTime;
                if(aimming >= target)
                {
                    aimming = 1f;
                    break;
                }
            }
            else
            {
                aimming -= aimmingSpeed * Time.deltaTime;
                if (aimming <= target)
                {
                    aimming = 0f;
                    break;
                }
            }

            yield return null;
        }
    }

    /// <summary>
    /// Rotate velocity at player direction
    /// </summary>
    private Vector3 RotateVelocity(Vector3 velocity)
    {
        float signedAngle = Vector2.SignedAngle(Vector2.up, new Vector2(transform.forward.x, transform.forward.z));

        return Quaternion.AngleAxis(-signedAngle, Vector3.up) * velocity;
    }

    /// <summary>
    /// Set speed for run or walk
    /// </summary>
    private float SetSpeed()
    {
        float speed = isRun ? runSpeed : moveSpeed;

        return isMove ? speed : 0;
    }


    /// <summary>
    /// if get mouse input, then process mouse input
    /// </summary>
    private void ProcessMouseInput()
    {
        if (!isMouseInput) return;

        characterRoot.localEulerAngles += new Vector3(-mouseInput.y * sensitivity, 0f, 0f);

        transform.localEulerAngles += new Vector3(0f, mouseInput.x * sensitivity, 0f);
        //transform.localEulerAngles = new Vector3(-Mathf.Clamp(transform.localEulerAngles.x, 0, 180), transform.localEulerAngles.y, transform.localEulerAngles.z);
    }
    private void CheckMovementToFront()
    {
        if (movementInput.z <= 0f)
        {
            isRun = false;
        }
    }

    /// <summary>
    /// Check swap coroutine is working
    /// </summary>
    private void ProcessSwapCoroutine()
    {
        if (isAim)
        {
            inventory.currentWeapon.GetComponentInChildren<Scope>()?.OnAimStop();
        }

        if (swappingCoroutine != null)
        {
            StopCoroutine(swappingCoroutine);
            swappingCoroutine = null;
        }

        swappingCoroutine = StartCoroutine(SwapMotionCoroutine());
    }

    /// <summary>
    /// Process swap motion using coroutine
    /// </summary>
    private IEnumerator SwapMotionCoroutine()
    {
        if (aimming > 0f)
        {
            isAim = false;

            //if (aimmingCoroutine != null)
            //{
            //    StopCoroutine(aimmingCoroutine);
            //    aimmingCoroutine = null;
            //}
            ProcessAiming(0f, false);

            yield return aimmingCoroutine;
        }

        isHolstered = true;

        foreach(var animator in animators)
        {
            animator.SetBool("Holstered", isHolstered);
        }

        // Wait a frame for setting animation
        yield return null;

        AnimatorClipInfo[] holsterState = playerAnimator.GetCurrentAnimatorClipInfo(playerAnimator.GetLayerIndex("Layer Holster"));

        yield return new WaitForSeconds(holsterState[0].clip.length);

        ChangeWeapon();

        yield return new WaitForSeconds(holsterState[0].clip.length);
        swappingCoroutine = null;
    }

    /// <summary>
    /// Change weapon
    /// </summary>
    private void ChangeWeapon()
    {
        //inventory.EnableWeapon(numIndex - 1);
        inventory.EnableWeapon();

        playerAnimationController.SetAnimator((int)inventory.currentWeapon.GetComponent<WeaponDetails>().weaponType);
        isHolstered = false;
        isFire = false;
    }

    private void CheckLeaningForward()
    {
        if (playerAnimationController.isLeanForward && isAim)
        {
            isAim = false;
            ProcessAiming(0f, false);
        }
    }

    private bool SetCurrentWeapon(WeaponSlotType type)
    {
        foreach (WeaponSlot slot in inventory.slots)
        {
            if (slot.weaponSlotType == type)
            {
                if (slot.itemList.Count > 0 && slot.itemList[0] != null)
                {
                    if(inventory.currentWeapon != slot.itemList[0].GetComponent<WeaponController>() || !slot.itemList[0].gameObject.activeSelf)
                    {
                        inventory.currentWeapon = slot.itemList[0].GetComponent<WeaponController>();
                        return true;
                    }
                }
            }
        }
        return false;
    }

    #endregion Method
}