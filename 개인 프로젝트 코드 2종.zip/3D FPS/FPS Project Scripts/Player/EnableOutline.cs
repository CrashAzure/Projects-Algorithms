using cakeslice;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEngine;

public class EnableOutline : MonoBehaviour
{
    private RaycastHit rayHit;
    private bool isRayHit = false;

    private void Update()
    {
        Transform cameraTransform = GameController.Instance.mainCameraController.transform;

        RaycastHit[] rayHits = GetRayHits(cameraTransform);

        CheckOutlineObjects(rayHits);
    }

    #region Getter
    public RaycastHit GetRayPoint() 
    {
        Transform cameraTransform = GameController.Instance.mainCameraController.transform;

        RaycastHit[] rayHits = GetRayHits(cameraTransform);

        CheckOutlineObjects(rayHits);

        return rayHit;
    }
    public string GetTargetTag() => GetOutLine().gameObject.tag;

    public Outline GetOutLine()
    {
        Outline outline = rayHit.transform.GetComponentInChildren<Outline>(true);

        if (outline == null)
        {
            if (rayHit.transform.GetComponentInParent<Enemy>() != null)
            {
                outline = rayHit.transform.GetComponentInParent<Enemy>()?.GetComponentInChildren<Outline>(true);
            }
            else if (rayHit.transform.GetComponentInParent<Player>() != null)
            {
                outline = rayHit.transform.GetComponentInParent<Player>()?.GetComponentInChildren<Outline>(true);
            }
            else
            {
                return null;
            }
        }

        return outline;
    }
    public bool HasRayHit() => isRayHit;
    #endregion Getter

    #region Method
    /// <summary>
    /// Check about outline objects
    /// </summary>
    private void CheckOutlineObjects(RaycastHit[] rayHits)
    {
        if (rayHits.Length > 0)
        {
            //foreach (var ray in rayHits)
            //{
            //    Outline outlines = ray.transform.GetComponentInChildren<Outline>(true);
            //    outlines.enabled = true;
            //    rayHit = ray;
            //    isRayHit = true;
            //}
            DisableAllOutlines();

            Outline outline = rayHits[0].transform.GetComponentInChildren<Outline>(true);

            if(outline == null)
            {
                if (rayHits[0].transform.GetComponentInParent<Enemy>() != null)
                {
                    outline = rayHits[0].transform.GetComponentInParent<Enemy>()?.GetComponentInChildren<Outline>(true);
                }
                else if(rayHits[0].transform.GetComponentInParent<Player>() != null)
                {
                    outline = rayHits[0].transform.GetComponentInParent<Player>()?.GetComponentInChildren<Outline>(true);
                }
                else
                {
                    return;
                }
            }

            outline.enabled = true;
            rayHit = rayHits[0];
            isRayHit = true;
        }
        else
        {
            DisableAllOutlines();
        }
    }

    private void DisableAllOutlines()
    {
        Outline[] outlines = FindObjectsOfType<Outline>();

        foreach (var outline in outlines)
        {
            if (outline.enabled)
                outline.enabled = false;
        }
        isRayHit = false;
    }

    /// <summary>
    /// Get ray cast hits
    /// </summary>
    private RaycastHit[] GetRayHits(Transform transform)
    {
        RaycastHit[] raycastHits = Physics.RaycastAll(transform.position,
                            transform.forward,
                            2.0f, 1 << LayerMask.NameToLayer("Interactable"));

        return raycastHits.OrderBy(h => h.distance).ToArray();
    }
    #endregion Method
}
