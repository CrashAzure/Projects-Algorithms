using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PlayerStatusEffectType
{
    None,
    Dizzy,
    Bleeding,
    Pain
}

public class CameraForPlayerStatus : MonoBehaviour
{
    private Material bleedingMaterial;
    [SerializeField]
    private Texture bloodTexture;
    public PlayerStatusEffectType playerStatusEffectType;
    public bool isHit = false;
    private float timer = 0f;
    private Camera thisCam;
    
    private void Awake()
    {
        Shader bleedingShader = Shader.Find("Custom/Bleeding");
        bleedingMaterial = new Material(bleedingShader);
        thisCam = GetComponent<Camera>();
    }

    private void Update()
    {
        if(thisCam.fieldOfView != transform.parent.GetComponent<Camera>().fieldOfView)
        {
            thisCam.fieldOfView = transform.parent.GetComponent<Camera>().fieldOfView;
        }
        if (timer > 0f)
        {
            timer -= Time.deltaTime;
        }
        
        if(isHit && timer <= 0f)
        {
            timer = 1f;
            isHit = false;
            CameraPlay.BloodHit(thisCam);
        }
    }

    //private void OnRenderImage(RenderTexture source, RenderTexture destination)
    //{
    //    if(playerStatusEffectType == PlayerStatusEffectType.Bleeding)
    //    {
    //        bleedingMaterial.SetTexture("iChannel0", source);
    //        bleedingMaterial.SetTexture("bloodTexture", bloodTexture);
    //        Graphics.Blit(source, destination, bleedingMaterial);
    //    }
    //    else
    //    {
    //        Graphics.Blit(source, destination);
    //    }
    //}
}
