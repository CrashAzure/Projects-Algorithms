using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public enum EffectTypeRoot
{
    None,
    NightVision,
}

public class CameraForNightVision : MonoBehaviour
{
    private bool isNightVision = false;
    private Material nightVisionMaterial;

    [SerializeField]
    private Texture particleTexture;

    [SerializeField]
    private AudioClip triggerSound;
    [SerializeField]
    private AudioClip nightVisionSound;

    private Camera thisCam;

    private CameraEffect camEff;

    private Coroutine LetNightVisionDonwOrUpCoroutine;

    private void Awake()
    {
        nightVisionMaterial = new Material(Shader.Find("Custom/NightVision"));
        camEff = GetComponentInParent<CameraEffect>();
        thisCam = GetComponent<Camera>();
        thisCam.fieldOfView = transform.parent.GetComponent<Camera>().fieldOfView;
    }
    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (isNightVision)
        {
            if(camEff.effectType == EffectType.Blizzard)
            {
                nightVisionMaterial.SetFloat("_Intesity", 2.0f);
            }
            else
            {
                nightVisionMaterial.SetFloat("_Intesity", 1f);
            }

            nightVisionMaterial.SetTexture("_MainTex", source);
            Graphics.Blit(source, destination, nightVisionMaterial);
        }
        else
        {
            Graphics.Blit(source, destination);
        }
    }

    public void SetNightVision()
    {
        isNightVision = !isNightVision;

        StartCoroutine(DelayCoroutine(0f, triggerSound));
        if (isNightVision)
        {
            StartCoroutine(DelayCoroutine(triggerSound.length, nightVisionSound, 0.1f, 2.0f));
        }
    }

    public void LetNightVisionDownUp()
    {
        if(LetNightVisionDonwOrUpCoroutine != null)
        {
            StopCoroutine(LetNightVisionDonwOrUpCoroutine);
            LetNightVisionDonwOrUpCoroutine = null;
        }

        if(thisCam.rect.y > 0f)
        {
            LetNightVisionDonwOrUpCoroutine = StartCoroutine(HelperUtilities.LerpCoroutine(thisCam.rect.y,
                                                                                           0f,
                                                                                           0.18f,
                                                                                           a => thisCam.rect = new Rect(0, a, 1, 1),
                                                                                           b => LetNightVisionDonwOrUpCoroutine = b));
        }
        else
        {
            thisCam.rect = new Rect(0, 1, 1, 1);
        }
        
    }

    private IEnumerator DelayCoroutine(float delayTime, AudioClip clip, float volume = 1.0f, float pitch = 1.0f)
    {
        yield return new WaitForSeconds(delayTime);

        GameObject audioPrefab = Resources.Load<GameObject>("Audio");
        SetAudio audio = (SetAudio)PoolManager.Instance.ReuseComponent(audioPrefab,
                                                             GameController.Instance.mainCameraController.transform.position,
                                                             Quaternion.identity);

        audio.SetAudioSource(clip);
        audio.SetPitch(pitch);
        audio.SetVolume(volume);
        audio.gameObject.SetActive(true);
        audio.Play();
    }

    private void Update()
    {
        if(thisCam.fieldOfView != transform.parent.GetComponent<Camera>().fieldOfView)
        {
            thisCam.fieldOfView = transform.parent.GetComponent<Camera>().fieldOfView;
        }
    }


}
