using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;

[DisallowMultipleComponent]
public class CameraEffect : MonoBehaviour
{
    private Material fogMaterial;
    private Shader fogShader;
    private Color blueFogColor = new Color(0.7f, 0.8f, 1f, 0f);
    private Color blackFogColor = new Color(0.2f, 0.2f, 0.2f, 0f);
    private Color whiteFogColor = new Color(0.9f, 0.9f, 0.9f, 0f);
    private float fogDensity = 0f;
    private float fogOffset = 0f;
    private Coroutine fogCoroutine = null;
    public EffectType effectType;
    public Camera rendererCam;
    private LightController lightController;

    private void Awake()
    {
        fogShader = Shader.Find("Hidden/FogEffect");
        fogMaterial = new Material(fogShader);
        rendererCam = GetComponent<Camera>();
        lightController = FindObjectOfType<LightController>();
        CameraEffect[] effects = GetComponents<CameraEffect>();
        if (effects.Length == 1) return;
        for(int i = 1; i< effects.Length; i++)
        {
            Destroy(effects[i]);
        }
        
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if(lightController == null)
        {
            lightController = FindObjectOfType<LightController>();
        }
        if(effectType == EffectType.Blizzard)
        {
            float fogColorRatio = lightController.ratio;
            Color fogColor = whiteFogColor;

            if (fogColorRatio >= 0f && fogColorRatio <= 0.125f)
            {
                fogColor = Color.Lerp(blueFogColor, whiteFogColor, fogColorRatio / 0.125f);
            }
            else if (fogColorRatio > 0.125f && fogColorRatio <= 0.375f)
            {
                fogColor = whiteFogColor;
            }
            else if (fogColorRatio > 0.375f && fogColorRatio <= 0.5f)
            {
                fogColor = Color.Lerp(whiteFogColor, blueFogColor, (fogColorRatio - 0.375f) / 0.125f);
            }
            else if (fogColorRatio > 0.5f && fogColorRatio <= 0.625f)
            {
                fogColor = Color.Lerp(blueFogColor, blackFogColor, (fogColorRatio - 0.5f) / 0.125f);
            }
            else if (fogColorRatio > 0.625f && fogColorRatio <= 0.875f)
            {
                fogColor = blackFogColor;
            }
            else if (fogColorRatio > 0.875f && fogColorRatio <= 1f)
            {
                fogColor = Color.Lerp(blackFogColor, blueFogColor, (fogColorRatio - 0.875f) / 0.125f);
            }
            fogMaterial.SetColor("_FogColor", fogColor);
            
            Graphics.Blit(source, destination, fogMaterial);
        }
        else
        {
            Graphics.Blit(source, destination);
        }
    }

    private void Update()
    {
        if (effectType == EffectType.Blizzard
            && fogCoroutine == null
            && fogMaterial.GetFloat("_FogDensity") <= 0f)
        {
            fogCoroutine = StartCoroutine(FadeFog(0f, 0.01f, 5f));
        }

        if(GameController.Instance.effects.currentEffect != EffectType.Blizzard
            && fogCoroutine == null
            && fogMaterial.GetFloat("_FogDensity") > 0f)
        {
            fogCoroutine = StartCoroutine(FadeFog(0.01f, 0f, 5f));
        }
    }

    private IEnumerator FadeFog(float startAlpha, float targetAlpha, float duration)
    {
        float elapsed = 0f;
        fogDensity = 0f;
        fogOffset = 0f;
        float targetOffset;
        float startOffset;
        if(startAlpha < targetAlpha)
        {
            targetOffset = 5f;
            startOffset = 2100f;
        }
        else
        {
            targetOffset = 2100f;
            startOffset = 5f;
        }

        while (elapsed < 1f)
        {
            elapsed += Time.deltaTime / duration;
            fogDensity = Mathf.Lerp(startAlpha, targetAlpha, elapsed);
            fogOffset = Mathf.Lerp(startOffset, targetOffset, elapsed);
            fogMaterial.SetFloat("_FogDensity", fogDensity);
            fogMaterial.SetFloat("_FogOffset", fogOffset);
            yield return null;
        }
        fogCoroutine = null;
    }
}
