using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Footstep : MonoBehaviour
{
    public List<AudioClip> concreteFootstepSounds = new List<AudioClip>();
    public float cycleTime = 0.5f;
    private AudioSource audioSource;
    private Coroutine footstepCoroutine = null;
    private CharacterInput input;

    public virtual void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        input = GetComponent<CharacterInput>();
    }

    public virtual void Update()
    {
        if (input.HasMove())
        {
            PlayFootstep();
        }
        else
        {
            StopFootstep();
        }
    }

    /// <summary>
    /// Play foot step
    /// </summary>
    public void PlayFootstep()
    {
        if(footstepCoroutine == null)
        {
            footstepCoroutine = StartCoroutine(FootstepCoroutine(cycleTime));
        }
    }

    /// <summary>
    /// Stop foot step
    /// </summary>
    public void StopFootstep()
    {
        if (footstepCoroutine == null) return;

        StopCoroutine(footstepCoroutine);
        footstepCoroutine = null;
    }

    /// <summary>
    /// Looping coroutine for foot step
    /// </summary>
    public virtual IEnumerator FootstepCoroutine(float cycleTime)
    {
        float elapsed = 0f;
        float cycle = 0;
        float volume = 1f;

        while (true)
        {
            if (input.HasRun())
            {
                cycle = cycleTime / 2;
                volume = 1f;
            }
            else
            {
                cycle = cycleTime;
                volume = 0.4f;
            }

            if (elapsed == 0f && !input.HasJump())
            {
                GameObject audioPrefab = Resources.Load<GameObject>("Audio");
                SetAudio audio = (SetAudio)PoolManager.Instance.ReuseComponent(audioPrefab, transform.position, Quaternion.identity);
                AudioClip footstep = concreteFootstepSounds[Random.Range(0, concreteFootstepSounds.Count - 1)];

                audio.SetVolume(volume);
                audio.SetPitch(1.0f);
                audio.SetAudioSource(footstep);
                audio.gameObject.SetActive(true);
                audio.Play();
                StartCoroutine(HelperUtilities.DisableObject(footstep.length, audio.gameObject));
            }

            if (input.HasJump())
            {
                elapsed = 0f;
            }
            else
            {
                elapsed += Time.deltaTime;
            }

            

            if(elapsed >= cycle)
            {
                elapsed = 0f;
            }

            yield return null;
        }
    }


}
