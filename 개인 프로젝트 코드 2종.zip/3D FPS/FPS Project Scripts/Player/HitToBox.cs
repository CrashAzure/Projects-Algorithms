using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static DamageIndicator;

public enum BodyType
{
    LeftLeg,
    RightLeg,
    Body,
    Head,
    LeftArm,
    RightArm,
}

public class HitToBox : MonoBehaviour
{
    public float totalHpAmount;
    public float currentHpAmount;
    public BodyType bodypartType;
    private DamageIndicator[] indicators;
    private bool playerDead = false;
    private bool isBlackOut = false;
    private HitBoxContainer container;
    private CameraForPlayerStatus bloodEffectCamera;
    private HitToBox parentBox;
    private Character parent;

    private void Awake()
    {
        indicators = UIManager.Instance.damageIndicators;
        container = GetComponentInParent<HitBoxContainer>();

        Player player = GetComponentInParent<Player>();
        Enemy enemy = GetComponentInParent<Enemy>();

        if (player != null)
        {
            parent = player;
        }
        else if (enemy != null)
        {
            parent = enemy;
        }
    }
    private void Start()
    {
        bloodEffectCamera = GameController.Instance.mainCameraController.GetComponentInChildren<CameraForPlayerStatus>();


        if(bodypartType != BodyType.Head && bodypartType != BodyType.Body)
        {
            foreach(var hitBox in container.hitBoxList)
            {
                if(hitBox.bodypartType == BodyType.Body)
                {
                    parentBox= hitBox;
                }
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Projectile"))
        {
            if (parent.transform != other.GetComponent<Projectiles>().startTransform)
            {
                Projectiles bullet = other.gameObject.GetComponent<Projectiles>();

                TakeDamage(CaculateDamagePenetratedArmor(bullet));
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Projectile"))
        {
            if (parent.transform != collision.gameObject.GetComponent<Projectiles>().startTransform)
            {
                Projectiles bullet = collision.gameObject.GetComponent<Projectiles>();
                
                TakeDamage(CaculateDamagePenetratedArmor(bullet));
            }
        }
    }

    public void TakeDamage(float damage)
    {
        if (currentHpAmount < damage)
        {
            float restDamage = damage - currentHpAmount;
            currentHpAmount = 0;
            isBlackOut = true;

            // legs or arms
            if(parentBox != null)
            {
                parentBox.TakeDamage(restDamage / 3.0f);
            }
            // Head or Body
            else
            {
                playerDead = true;
            }
        }
        else
        {
            currentHpAmount -= damage;
        }

        float reduceWithBodyType = 1f;


        if (bodypartType != BodyType.Head && bodypartType != BodyType.Body)
        {
            reduceWithBodyType = 2.5f;
        }

        if (playerDead)
        {
            if (parent as Enemy != null)
            {
                Enemy enemy = parent as Enemy;
                enemy.isDead = playerDead;
            }
            else
            {
                parent.GetComponent<PlayerStatus>().isDead = playerDead;
            }
        }

        if(parent.transform == GameController.Instance.player.transform)
        {
            // Player effect section
            bloodEffectCamera.isHit = true;

            // minus or plus
            float randomAimPunchAmount = (Random.Range(0, 2) * 2 - 1) * Random.Range(damage / (10 * reduceWithBodyType), damage / (6 * reduceWithBodyType));
            GameController.Instance.player.transform.localEulerAngles += new Vector3(0f, randomAimPunchAmount, 0f);
            GameController.Instance.player.playerRootAnimator.transform.localEulerAngles += new Vector3(randomAimPunchAmount, 0f, 0f);
            GameController.Instance.GetCharacterInput().HasAnimator().SetTrigger("Hit");
            UpdateDamageIndicatorUI();
        }
    }

    public void HealBodyPart(float ratio = 1f)
    {
        currentHpAmount = totalHpAmount * ratio;
        UpdateDamageIndicatorUI();
    }

    /// <summary>
    /// Update health ui
    /// </summary>
    private void UpdateDamageIndicatorUI()
    {
        int partsNumber = 0;

        switch (bodypartType)
        {
            case BodyType.LeftLeg:
                partsNumber = 0;
                break;

            case BodyType.RightLeg:
                partsNumber = 1;
                break;

            case BodyType.Body:
                partsNumber = 2;
                break;

            case BodyType.Head:
                partsNumber = 3;
                break;

            case BodyType.LeftArm:
                partsNumber = 4;
                break;

            case BodyType.RightArm:
                partsNumber = 5;
                break;
        }

        foreach(DamageIndicator indicator in indicators)
        {
            indicator.parts[partsNumber].Target.material.SetFloat("_DamageAmount", 1f - currentHpAmount / totalHpAmount);
        }
    }

    private float CaculateDamagePenetratedArmor(Projectiles bullet)
    {
        float restDamage = 0f;
        float damageToArmors = 0f;
        float levelDiff = 0;

        if (bodypartType == BodyType.Head)
        {
            HelmetSlot helmetSlot = parent.inventory.helmetSlot;

            if(helmetSlot.itemList.Count != 0)
            {
                Helmet helmet = helmetSlot.itemList[0] as Helmet;

                levelDiff = helmet.level - bullet.penetrationlevel;

                damageToArmors = CaculateDamageOnArmor(ref levelDiff, bullet);

                if(helmet.currentDurability >= damageToArmors)
                {
                    helmet.currentDurability -= damageToArmors;
                }
                else
                {
                    restDamage = damageToArmors - helmet.currentDurability;
                    helmet.currentDurability = 0f;
                }
                

            }
        }
        else if (bodypartType == BodyType.Body)
        {
            ArmorSlot armorSlot = parent.inventory.armorSlot;

            if (armorSlot.itemList.Count != 0)
            {
                Armor armor = armorSlot.itemList[0] as Armor;

                levelDiff = armor.level - bullet.penetrationlevel;

                damageToArmors = CaculateDamageOnArmor(ref levelDiff, bullet);

                if(armor.currentDurability >= damageToArmors)
                {
                    armor.currentDurability -= damageToArmors;
                }
                else
                {
                    restDamage = damageToArmors - armor.currentDurability;
                    armor.currentDurability = 0f;
                }
            }
        }

        levelDiff = levelDiff == 0 ? 1 : levelDiff;

        return bullet.damage / levelDiff + restDamage;

    }

    private float CaculateDamageOnArmor(ref float levelDiff, Projectiles bullet)
    {
        levelDiff *= levelDiff;
        levelDiff = levelDiff == 0 ? 1 : levelDiff;

        return bullet.damage / levelDiff;
    }
}
