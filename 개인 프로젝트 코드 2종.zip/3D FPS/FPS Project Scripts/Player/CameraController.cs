using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UIElements;

public class CameraController : MonoBehaviour
{
    public Camera depthCamera;
    private float timer = 0f;
    
    /// <summary>
    /// How much will you change camera position?
    /// </summary>
    public void CameraRePosiiton(Vector3 position, float duration)
    {
        if(transform.localPosition != Vector3.zero)
        {
            transform.localPosition = Vector3.zero;
        }

        StartCoroutine(HelperUtilities.LerpCoroutine(Vector3.zero,
                                                     position,
                                                     duration,
                                                     a => transform.localPosition = a));

        //StartCoroutine(LerpPositioning(Vector3.zero, position, duration));
        

        //transform.localPosition += position;
    }

    /// <summary>
    /// Change camera field of view 
    /// </summary>
    public void CameraFovChange(float targetFieldofView, float duration)
    {
        StartCoroutine(HelperUtilities.LerpCoroutine(depthCamera.fieldOfView,
                                                     targetFieldofView, duration, 
                                                     a => depthCamera.fieldOfView = a));
    }


    /// <summary>
    /// Reset camera
    /// </summary>
    public void CameraResetPosition(float duration)
    {
        StartCoroutine(HelperUtilities.LerpCoroutine(Vector3.zero, 
                                                     -transform.localPosition, 
                                                     duration,
                                                     a => transform.localPosition = a));
    }

    /// <summary>
    /// Rotate camera
    /// </summary>
    public void CameraRotate(Vector3 rotation)
    {
        transform.localEulerAngles += rotation;
    }

    /// <summary>
    /// Set position of camera
    /// </summary>
    public void SetPosition(Vector3 position)
    {
        transform.localPosition = position;
    }

    /// <summary>
    /// Set Rotation
    /// </summary>
    public void SetRotation(Vector3 rotation)
    {
        transform.localEulerAngles = rotation;
    }

}
