using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class PlayerStatus : MonoBehaviour
{
    public bool isInGame = false;
    public bool isDead = false;
    private NavMeshAgent agent;
    [SerializeField]
    private GameObject animationDollGameObject;
    [SerializeField]
    private GameObject ragdollGameObject;
    [SerializeField]
    private Transform ragDollHead;
    
    private Rigidbody rb;
    private CharacterInput input;
    private Player player;
    [SerializeField]
    private Transform head;
    private HitBoxContainer hitBoxContainer;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        input = GetComponent<CharacterInput>();
        player = GetComponent<Player>();
        hitBoxContainer = GetComponent<HitBoxContainer>();
    }
    private void Start()
    {
        GameController.Instance.input.EnableInput();
    }

    // Update is called once per frame
    void Update()
    {
        if (isInGame)
        {
            if (isDead && GameController.Instance.mainCameraController.transform.parent != ragDollHead)
            {
                GameController.Instance.mainCameraController.transform.SetParent(ragDollHead, false);
                GameController.Instance.input.DisableInput();
                animationDollGameObject.gameObject.SetActive(false);
                ragdollGameObject.gameObject.SetActive(true);

                Animator targetAinmator = ragdollGameObject.GetComponent<Animator>();

                targetAinmator.SetFloat("Horizontal", 0);
                targetAinmator.SetFloat("Vertical", 0);
                targetAinmator.SetBool("Dead", isDead);

                targetAinmator.enabled = false;

                player.inventory.ResetInventory();

                //UIManager.Instance.fadeUI.FadeInAndOut(1.5f, 1.5f, true);
                UIManager.Instance.loadingUI.FadeLoading(0f, 1f, 1.5f, 1.5f, Color.black);
                UIManager.Instance.loadingUI.FadeLoading(1f, 0f, 3f, 1.5f, Color.black);
                StartCoroutine(DelayChangeScene(3f));
            }
            else if (!isDead && GameController.Instance.mainCameraController.transform.parent != head)
            {
                GameController.Instance.mainCameraController.transform.SetParent(head, false);
                GameController.Instance.mainCameraController.transform.position = Vector3.zero;
                GameController.Instance.mainCameraController.transform.localEulerAngles = Vector3.zero;
                GameController.Instance.input.EnableInput();
                ragdollGameObject.GetComponent<Animator>().enabled = true;
                animationDollGameObject.gameObject.SetActive(true);
                ragdollGameObject.gameObject.SetActive(false);
            }
        }
        

        if (!isInGame && (!rb.isKinematic))
        {
            rb.isKinematic = true;
            player.animator.gameObject.SetActive(false);
            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.Confined;
            GameController.Instance.input.DisableInput();
            UIManager.Instance.playerStatusUI.gameObject.SetActive(false);
            UIManager.Instance.CenterPoint.gameObject.SetActive(false);
            UIManager.Instance.weaponStatusUI.gameObject.SetActive(false);
            UIManager.Instance.mainUIButtons.gameObject.SetActive(true);
            UIManager.Instance.titleImage.gameObject.SetActive(true);
            StaticManager.Instance.mainMenuObjects.gameObject.SetActive(true);
            ragdollGameObject.gameObject.SetActive(false);
            transform.position = Vector3.up * 100f;
        }
        else if(isInGame && (rb.isKinematic))
        {
            rb.isKinematic = false;
            isDead = false;
            player.animator.gameObject.SetActive(true);
            GameController.Instance.input.EnableInput();
            Cursor.visible = false;
            Cursor.lockState = CursorLockMode.Locked;
            UIManager.Instance.playerStatusUI.gameObject.SetActive(true);
            UIManager.Instance.weaponStatusUI.gameObject.SetActive(true);

            foreach(HitToBox box in hitBoxContainer.hitBoxList)
            {
                box.HealBodyPart();
            }
        }
    }

    private IEnumerator DelayChangeScene(float delayTime)
    {
        yield return new WaitForSeconds(delayTime);
        SceneManager.UnloadSceneAsync(SceneManager.GetSceneAt(SceneManager.sceneCount - 1));
    }

    
}
