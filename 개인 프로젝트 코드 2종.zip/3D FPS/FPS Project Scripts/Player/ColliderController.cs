using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColliderController : MonoBehaviour
{
    private CharacterInput input;
    private bool prevCrouch = false;
    [SerializeField]
    private PhysicMaterial ice;
    [SerializeField]
    private PhysicMaterial ground;
    [SerializeField]
    private PhysicMaterial normal;

    private void Start()
    {
        input = GameController.Instance.GetCharacterInput();
    }

    private void Update()
    {
        if (prevCrouch == input.HasCrouch()) return;

        if (input.HasCrouch())
        {
            transform.localPosition = Vector3.up * 0.43f;
        }
        else
        {
            transform.localPosition = Vector3.zero;
        }

        prevCrouch = input.HasCrouch();
    }

    private void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.layer != LayerMask.NameToLayer("Default")) return;
        collider.material = ice;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer != LayerMask.NameToLayer("Default")) return;
        collision.gameObject.GetComponent<Collider>().material = ice;
    }
    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.layer != LayerMask.NameToLayer("Default")) return;
        collision.gameObject.GetComponent<Collider>().material = ground;
    }

    private void OnTriggerExit(Collider collider)
    {
        if (collider.gameObject.layer != LayerMask.NameToLayer("Default")) return;
        collider.material = ground;
    }
}
