using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Player : Character
{
    [HideInInspector]
    public CharacterInput characterInput;
    [HideInInspector]
    public EnableOutline enableOutline;
    [HideInInspector]
    public CapsuleCollider capsuleCollider;
    [HideInInspector]
    public Transform playerRootAnimator;
    [HideInInspector]
    public PlayerStatus playerStatus;
    public Transform bodyTransform;

    private void Awake()
    {
        characterInput = GetComponent<CharacterInput>();
        enableOutline = GetComponent<EnableOutline>();
        animators = GetComponentsInChildren<Animator>();
        rigidBody = GetComponent<Rigidbody>();
        capsuleCollider = GetComponent<CapsuleCollider>();
        enableOutline = GetComponent<EnableOutline>();
        characterInput.Init();
        playerRootAnimator = transform.GetChild(0);
        agent = GetComponent<NavMeshAgent>();
        inventory= GetComponentInChildren<Inventory>();
        playerStatus = GetComponent<PlayerStatus>();
    }

    private void Start()
    {
        if (GameObject.Find("StartingPoint") == null) return;
        Transform starting = GameObject.Find("StartingPoint").transform;
        
        //Transform randomStartingPoint = starting.GetChild(Random.Range(0, starting.childCount - 1));
        Transform randomStartingPoint = starting.GetChild(1);
        transform.position = randomStartingPoint.position;
        transform.rotation = randomStartingPoint.rotation;
    }

    public CharacterInput GetCharacterInput() => characterInput;
    public EnableOutline GetEnableOutline() => enableOutline;

    public Animator[] GetAnimator() => animators;
    public Rigidbody GetRigidbody() => rigidBody;
    public CapsuleCollider GetCapsuleCollider() => capsuleCollider;
}
