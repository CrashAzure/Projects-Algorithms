using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Character : MonoBehaviour
{
    [HideInInspector]
    public Animator[] animators;
    [HideInInspector]
    public Rigidbody rigidBody;
    [HideInInspector]
    public NavMeshAgent agent;

    public Animator animator;

    public Transform headTransform;

    [HideInInspector]
    public Inventory inventory;
}
