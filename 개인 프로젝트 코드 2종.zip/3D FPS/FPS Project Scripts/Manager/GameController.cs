using InfimaGames.LowPolyShooterPack;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;

public class GameController : SingletonMonobehaviour<GameController>
{
    private static GameController instance;

    public Player player;
    public CameraController mainCameraController;
    public Inventory playerInventory;
    public Transform playerStatusUI;
    public CharacterInput input;
    public ShaderEffects effects;
    public static GameObject items;

    public static GameController Instance
    {
        get
        {
            if(instance == null)
            {
                GameObject gameController = new GameObject("GameController");
                instance = gameController.AddComponent<GameController>();
                gameController.transform.SetParent(GameObject.Find("Managers").transform);
                gameController.GetComponent<GameController>().Init();
            }
            return instance;
        }
    }

    public static GameObject Items
    {
        get
        {
            if(items == null)
            {
                items = GameObject.Find("items");
            }
            return items;
        }
    }

    private void Init()
    {
        InitialiseCursor();
        player = FindObjectOfType<Player>(true);
        playerInventory = player.GetComponentInChildren<Inventory>(true);
        mainCameraController = FindObjectOfType<CameraController>(true);
        input = player.GetComponent<CharacterInput>();
        effects = FindObjectOfType<ShaderEffects>(true);
        items = GameObject.Find("Items");
    }

    private void InitialiseCursor()
    {
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;
    }


    #region Getter
    public EnableOutline GetEnableOutline() => player.GetEnableOutline();
    public CharacterInput GetCharacterInput() => player.GetCharacterInput();
    public Animator[] GetPlayerAnimator() => player.GetAnimator();
    #endregion Getter

}
