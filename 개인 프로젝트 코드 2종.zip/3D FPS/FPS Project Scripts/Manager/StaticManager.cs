using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class StaticManager : MonoBehaviour
{
    public static StaticManager instance;
    public GameObject mainMenuObjects;

    public static StaticManager Instance
    {
        get
        {
            if(instance == null)
            {
                instance = new StaticManager();
                GameObject staticManager = new GameObject("StaticManager");
                instance = staticManager.AddComponent<StaticManager>();
                staticManager.transform.SetParent(GameObject.Find("Managers").transform);
                staticManager.GetComponent<StaticManager>().Init();
            }
            return instance;
        }
    }

    private void Init()
    {
        mainMenuObjects = GameObject.Find("MainMenu");
    }
}
