using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.GlobalIllumination;

public class ImpactClass : MonoBehaviour
{
    [Header("Impact Despawn Timer")]
    //How long before the impact is destroyed
    public float despawnTimer = 4.0f;

    public float delightTimer = 0.5f;

    [Header("Audio")]
    public AudioClip[] impactSounds;

    public AudioSource audioSource;

    private Light pointLight;
    private Transform home;

    private void OnEnable()
    {
        if(home == null)
        {
            home = transform.parent;
        }

        if(pointLight == null)
        {
            pointLight = GetComponentInChildren<Light>(true);
        }

        if(pointLight != null)
        {
            pointLight.gameObject.SetActive(true);
        }
        

        // Start the despawn timer
        StartCoroutine(DespawnTimer());

        //Get a random impact sound from the array
        audioSource.clip = impactSounds
            [Random.Range(0, impactSounds.Length)];
        //Play the random impact sound
        audioSource.Play();
    }

    private IEnumerator DespawnTimer()
    {
        yield return new WaitForSeconds(delightTimer);

        if(pointLight != null)
        {
            pointLight.gameObject.SetActive(false);
        }
        //Wait for set amount of time
        yield return new WaitForSeconds(despawnTimer - delightTimer);
        transform.parent= home;
        // Return to object pool
        gameObject.SetActive(false);
    }
}
