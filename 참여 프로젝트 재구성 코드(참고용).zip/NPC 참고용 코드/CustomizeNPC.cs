using System;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.EventSystems;

namespace KJJ
{
    /// <summary>
    /// NPC 데이터를 담고 있는 클래스 <br/>
    /// </summary>
    public class CustomizeNPC : MonoBehaviour
    {
        #region Members
        public enum LanguageType
        {
            KOREAN,
            ENGLISH,
        }
        /// <summary>
        /// 언어팩 설정 별 스크립트를 가지고 있는 구조체
        /// </summary>
        [Serializable]
        public struct DialogueListForEachLanguges
        {
            public LanguageType language;
            public Dialogue[] dialogues;
        }

        [Header("NPC Dialogues")]
        public DialogueListForEachLanguges[] dialoguesForEachLanguages;

        /// <summary>
        /// 현재 출력 중인 대사<br/>
        /// 분기 처리 <br/>
        /// 하나 이상의 분기에서 타겟이 될 다음 대사 인덱스를 설정
        /// </summary>
        [Serializable]
        public struct Dialogue
        {
            public int[] targetDialogueIndex;
            public string[] currentDialogues;
        }

        public enum NpcBaseType
        {
            CustomizeCharacter,
            Moongcho,
        }

        public enum NpcType
        {
            NoneDialogType,
            DialogType,
        }

        [Header("NPC UI")]
        public NPCUI npcUI;
        public StaticAboveUITarget aboveUITarget;
        public StaticAboveUI aboveUI;
        public EventTrigger eventTrigger;

        [Header("NPC Info")]
        public bool moveAble;
        public NpcBaseType baseType;
        public NpcType type;
        public GameObject[] npcBaseGameobjects;
        public Animator animator;

        [Header("NPC Parts")]
        public int headIndex = 0;
        public int bodyIndex = 0;
        public int hairIndex = 0;
        public int shirtIndex = 0;
        public int pantsIndex = 0;
        public int shoesIndex = 0;
        public int hairColorIndex = 0;
        public int bodyColorIndex = 0;
        public bool randomCustomizing = false;

        private NavMeshAgent agent;
        private CustomizeCharacter customizeCharacter;
        [Header("Find Info")]
        [SerializeField]
        private bool isTrigger = false;
        #endregion

        #region Unity
        private void OnValidate()
        {
            // 편집 모드에서 필요 요소들을 탐색
            if (!isTrigger) return;
            isTrigger = false;
            if( type == NpcType.DialogType && npcUI == null) npcUI = FindObjectOfType<NPCUI>(true);
            if (aboveUITarget == null) aboveUITarget = GetComponent<StaticAboveUITarget>();
            if (aboveUI == null) aboveUI = GameObject.Find("NPC Talk").GetComponentInChildren<StaticAboveUI>(true);
            if (eventTrigger == null) eventTrigger = aboveUI.GetComponent<EventTrigger>();
        }

        private void Start()
        {
            agent = GetComponent<NavMeshAgent>();
            if (moveAble && agent == null) agent = gameObject.AddComponent<NavMeshAgent>();
            customizeCharacter = GetComponent<CustomizeCharacter>();
            if (randomCustomizing)
            {
                // 헤드를 우선적으로 선택
                // 성별에 따라 해당하는 랜덤 파츠를 선택하여 장착
                customizeCharacter.Func_RandomCustomizing(customizeCharacter);
            }
            else
            {
                SetNPCCustominzing();
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            // 로컬 플레이어가 영역에 들어오면
            // NPC를 따라 다니는 UI를 활성화
            // 이벤트 트리거 리스트에서 커서가 포커스 될 때의 트리거를 추가
            if (!other.CompareTag("Local Player")) return;
            EnableAboveUI(true);
            eventTrigger.triggers.Add(SetNPCForUIEvent(true));
        }

        private void OnTriggerExit(Collider other)
        {
            if (!other.CompareTag("Local Player")) return;
            // 로컬 플레이어가 영역에서 나가면
            // NPC를 따라 다니는 UI를 비활성화
            // 이벤트 트리거 리스트에 커서가 포커스 될 때의 트리거를 초기화
            EnableAboveUI(false);
            eventTrigger.triggers.Clear();
        }
        #endregion


        #region Methods
        /// <summary>
        /// NPC에 커서가 포커스 될 때의 트리거 함수
        /// </summary>
        public EventTrigger.Entry SetNPCForUIEvent(bool enable)
        {
            // 커서가 들어갈 때
            EventTrigger.Entry entry = new EventTrigger.Entry();
            // 해당 트리거에 이벤트 추가
            entry.callback.AddListener(delegate
            {
                aboveUI.gameObject.SetActive(enable);
                
                SetNPCForUI(enable);
            });
            // 클릭 될 때 해당 이벤트를 호출
            entry.eventID = EventTriggerType.PointerDown;

            return entry;
        }

        /// <summary>
        /// 떠다니는 UI를 활성화
        /// </summary>
        public void EnableAboveUI(bool enable)
        {
            if(enable) aboveUITarget.SetAboveUI(aboveUI);
            aboveUITarget.EnableAboveUI(enable);
            if(!enable) aboveUITarget.SetAboveUI(null);
        }

        /// <summary>
        /// UI 활성화
        /// </summary>
        public void SetNPCForUI(bool enable)
        {
            npcUI.currentNPC = enable ? this : null;
            npcUI.gameObject.SetActive(enable);
        }

        /// <summary>
        /// 미리 지정한 인덱스에 따른 파츠 장착 함수
        /// </summary>
        private void SetNPCCustominzing()
        {
            if (randomCustomizing) return;
            customizeCharacter.Func_EquipPart(CharacterPartType.Head, headIndex);
            customizeCharacter.Func_EquipPart(CharacterPartType.Body, bodyIndex);
            customizeCharacter.Func_EquipPart(CharacterPartType.Hair, hairIndex);
            customizeCharacter.Func_EquipPart(CharacterPartType.Shirt, shirtIndex);
            customizeCharacter.Func_EquipPart(CharacterPartType.Pants, pantsIndex);
            customizeCharacter.Func_EquipPart(CharacterPartType.Shoes, shoesIndex);

            customizeCharacter.Func_SetHairColor(hairColorIndex);
            customizeCharacter.Func_SetBodyColor(bodyColorIndex);
        }
        #endregion
    }
}
