using UnityEngine;
using UnityEngine.AI;

namespace KJJ
{
    /// <summary>
    /// 내    용: 풀링 개념의 NPC 처리, 플레이어 주변에만 이동하므로 플레이어 객체에 붙는다.
    /// </summary>
    public class NPCPooling : MonoBehaviour
    {
        #region Parameters
        public Transform[] npcTransforms;
        public NPCAgent[] npcAgents;

        public int npcLength = 10;

        public float radius = 50f;

        public float rayHeight = 30f;

        public GameObject npcPrefab;

        public float searchingTime = 2f;

        public int searchCount = 5;

        private float timer = 0f;
        #endregion

        #region Unity
        private void Awake()
        {
            npcTransforms = new Transform[npcLength];
            npcAgents = new NPCAgent[npcLength];
            for (int i = 0; i < npcLength; i++)
            {
                GameObject temp = Instantiate(npcPrefab);
                npcTransforms[i] = temp.transform;
                npcAgents[i] = temp.GetComponent<NPCAgent>();
                temp.SetActive(false);
            }
        }

        private void Start()
        {
            for (int i = 0; i < npcLength; i++)
            {
                ResetNPCPosition(npcTransforms[i], true);
            }
        }

        private void Update()
        {
            timer += Time.deltaTime;

            if (timer > searchingTime)
            {
                timer = 0f;

                CheckInCircle();
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// 주기적으로 플레이어 주변에 있는지를 체크하는 함수<br/>
        /// 밖이라면 플레이어 시야각 앞쪽으로 위치를 재설정 시도
        /// </summary>
        private void CheckInCircle()
        {
            Vector2 playerPosXZ = new Vector2(transform.position.x, transform.position.z);
            for (int i = 0; i < npcLength; i++) 
            {
                Vector3 npcPos = npcTransforms[i].position;
                Vector2 npcPosXZ = new Vector2(npcPos.x, npcPos.z);

                // 설정된 반지름 보다 멀다면
                if (Vector2.Distance(playerPosXZ, npcPosXZ) > radius) 
                {
                    npcAgents[i].gameObject.SetActive(false);
                    npcAgents[i].Func_RandomCustomizing();
                    // 재설정
                    ResetNPCPosition(npcTransforms[i], false);
                    npcAgents[i].ResetDestination();
                }
            }
        }

        /// <summary>
        /// 플레이어의 시야각 앞 쪽의 랜덤한 좌표계에 따라 목적지를 재설정하는 함수
        /// </summary>
        private void ResetNPCPosition(Transform npcTransform, bool isFirst)
        {
            int count = 0;
            while (count < searchCount)
            {
                // 시야각 앞 쪽 랜덤 좌표를 받아온다
                Vector3 randomPos = GetCircleOutsideMinRadius();

                // 처음에만 시야각 무시
                if (isFirst) randomPos = Random.insideUnitSphere * (radius - 5f);

                // 플레이어 기준
                randomPos += transform.position;

                // 도달 가능한 목적지라면
                if (NavMesh.SamplePosition(randomPos, out NavMeshHit hit, rayHeight, NavMesh.AllAreas)) 
                {
                    npcTransform.position = hit.position;
                    
                    npcTransform.gameObject.SetActive(true);
                    return;
                }
                count++;
            }
            
            // Count Over
            npcTransform.gameObject.SetActive(false);
        }

        /// <summary>
        /// 플레이어 시야각 앞쪽의 랜덤 좌표를 가져오는 함수
        /// </summary>
        private Vector3 GetCircleOutsideMinRadius()
        {
            // 최소와 최대 반지름 사이에서 무작위 반지름을 선택
            float randomRadius = Random.Range(radius - 15f, radius - 5f);

            // 무작위 각도 생성 (대략적인 시야각)
            float randomAngle = Random.Range(25f , 155f);

            // 극좌표를 직교 좌표로 변환
            float randomX = randomRadius * Mathf.Cos(randomAngle * Mathf.Deg2Rad);
            float randomZ = randomRadius * Mathf.Sin(randomAngle * Mathf.Deg2Rad);

            // Y 축 회전각 (플레이어)
            float playerRotationAngle = transform.eulerAngles.y;
            // 쿼터니언 생성
            Quaternion rotationQuaternion = Quaternion.Euler(0, playerRotationAngle, 0);
            // 벡터를 회전
            Vector3 rotatedVector = rotationQuaternion * new Vector3(randomX, 0, randomZ);

            return rotatedVector;
        }
        #endregion
    }

}
