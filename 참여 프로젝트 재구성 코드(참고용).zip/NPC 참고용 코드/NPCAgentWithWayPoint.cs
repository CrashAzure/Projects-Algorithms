using UnityEngine;
using UnityEngine.AI;
namespace KJJ 
{
    public class NPCAgentWithWayPoint : MonoBehaviour
    {
        #region Parameters
        public NavMeshAgent agent;
        public CustomizeCharacter character;
        public CustomizeNPC npcInfo;

        public int searchCount = 5;

        public float rayHeight = 30f;

        public float walkSpeed = 1;
        public float runSpeed = 4;

        public Transform[] wayPoints;

        public bool isLoop = false;

        public int i = 0;
        #endregion

        #region Unity
        void Start()
        {
            if (isLoop) agent.speed = runSpeed;
            else agent.speed = walkSpeed;
            agent.SetDestination(wayPoints[i].position);
        }

        void Update()
        {
            character.characterAnimator.SetFloat("Speed", agent.speed);
            character.characterAnimator.SetBool("Run", agent.speed > 2f);

            if (isLoop)
            {
                if (agent.remainingDistance < 1f)
                {
                    i++;
                    if (i == wayPoints.Length) { i = 0; }
                    agent.SetDestination(wayPoints[i].position);

                }
            }
            else
            {
                if (agent.destination == null)
                {
                    agent.SetDestination(wayPoints[Random.Range(0, wayPoints.Length - 1)].position);
                }
            }
        }
        #endregion

    }

}
