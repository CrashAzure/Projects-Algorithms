using UnityEngine;
using UnityEngine.AI;

namespace KJJ
{
    /// <summary>
    /// 내    용: NPC가 랜덤한 주기와 속도에 따라 자동으로 목적지를 재설정하는 클래스
    /// </summary>
    public class NPCAgent : MonoBehaviour
    {
        #region Parameters
        public NavMeshAgent agent;
        public CustomizeCharacter character;
        public CustomizeNPC npcInfo;

        public int searchCount = 5;

        public float rayHeight = 30f;

        public float walkSpeed = 1;
        public float runSpeed = 4;

        public float maxSearchTime = 10;
        public float minSearchTime = 5;

        public float maxWaitingTime = 3;
        public float minWaitingTime = 0;

        private float currentWaitingTime = 0;

        private float currentSearchTime = 0;

        private float timer = 0f;

        private Animator animator;

        private bool isFirst = false;
        #endregion

        #region Unity
        private void Start()
        {
            currentWaitingTime = Random.Range(minWaitingTime, maxWaitingTime);
            Invoke("StartMove", currentWaitingTime);
        }

        private void Update()
        {
            if (!isFirst) return;

            timer += Time.deltaTime;

            if (timer > currentSearchTime) ResetDestination();

            character.characterAnimator.SetFloat("Speed", agent.velocity.magnitude < 0.1f ? 0 : agent.speed);
            
            character.characterAnimator.SetBool("Run", agent.speed > 2f);
        }
        #endregion

        #region Methods
        /// <summary>
        /// 랜덤한 스피드를 부여
        /// </summary>
        private void ResetSpeed()
        {
            int result = Random.Range(0, 5);

            if (result == 4) agent.speed = runSpeed;
            else agent.speed = walkSpeed;
        }

        /// <summary>
        /// 랜덤한 주기 및 대기 시간 부여
        /// </summary>
        private void ResetSearchTime()
        {
            timer = 0;
            currentSearchTime = Random.Range(minSearchTime, maxSearchTime);
            currentWaitingTime = Random.Range(minWaitingTime, maxWaitingTime);
        }

        public void StartMove() 
        {
            isFirst = true;
        }

        /// <summary>
        /// 주기가 되었을 때 랜덤한 좌표의 목적지를 재설정하는 함수
        /// </summary>
        public void ResetDestination()
        {
            // 변수값 재설정
            ResetSpeed();
            ResetSearchTime();

            int count = 0;

            // 카운트 만큼만 탐색
            while (count < searchCount)
            {
                // 랜덤하게 부여된 속도와 시간에 비례한 반지름의 원의 랜덤 좌표
                Vector2 randomCircle = Random.insideUnitCircle.normalized * agent.speed * (currentSearchTime + currentWaitingTime);
                // 해당 NPC 좌표계 기준에 랜덤 좌표를 더해줌
                Vector3 randomPos = transform.position + new Vector3(randomCircle.x, 0, randomCircle.y);

                // 랜덤하게 설정된 좌표에 NavMeshAgent가 도달할 수 있다면 재설정 완료
                if (gameObject.activeSelf && agent.enabled && NavMesh.SamplePosition(randomPos, out NavMeshHit hit, rayHeight, NavMesh.AllAreas))
                {
                    // reset Done
                    agent.SetDestination(hit.position);
                    return;
                }
                count++;
            }

            // 실패 시에 해당 NPC를 비활성화
            if (gameObject.activeSelf)
            {
                agent.isStopped = true;
            }
            agent.speed = 0;
            // Reset fail
            gameObject.SetActive(false);
        }

        /// <summary>
        /// 랜덤 커스터 마이징 함수
        /// </summary>
        public void Func_RandomCustomizing()
        {
            character.Func_RandomCustomizing(character);
        }
        #endregion
    }
}
