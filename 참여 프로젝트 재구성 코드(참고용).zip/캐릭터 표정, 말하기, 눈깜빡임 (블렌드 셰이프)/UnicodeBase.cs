using System;
namespace KJJ
{
    /// <summary>
    /// ��    ��: ���ڿ��� ����, ������ �и��ϴ� Ŭ����
    /// </summary>
    public class UnicodeBase
    {
        public static string firstConsonant = "��������������������������������������";
        public static string vowel = "�������¤äĤŤƤǤȤɤʤˤ̤ͤΤϤФѤҤ�";
        public static string lastConsonant = " ������������������������������������������������������";

        private static string aTypeVowel = "������";
        private static string eTypeVowel = "���¤ĤƤɤʤ�";
        private static string iTypeVowel = "�ϤҤ�";
        private static string oTypeVowel = "�äŤǤˤ�";
        private static string uTypeVowel = "�̤Ф�";

        public static ushort UnicodeKoreanBase = 0xAC00;
        public static ushort UnicodeKoreanLast = 0xD79F;

        /// <summary>
        /// get string's vowels to char array
        /// </summary>
        public static char[] GetVowels(string text)
        {
            char[] dividedStr = text.ToCharArray();

            for(int i = 0; i < dividedStr.Length; i++)
            {
                dividedStr[i] = GetVowel(dividedStr[i]);
            }

            return dividedStr;
        }

        /// <summary>
        /// Get vowel
        /// </summary>
        private static char GetVowel(char c)
        {
            ushort text = Convert.ToUInt16(c);

            // is this Korean?
            if (text <= UnicodeKoreanLast && text >= UnicodeKoreanBase) return GetKoreanVowel(text);
            else return ' ';
        }

        /// <summary>
        /// Get vowel in Korean Case
        /// </summary>
        private static char GetKoreanVowel(ushort text)
        {
            int code = text - UnicodeKoreanBase;

            int lastConsonantCode = code % 28; // Take Last Consonant
            code = (code - lastConsonantCode) / 28;

            int vowelCode = code % 21; // Take Vowel
            code = (code - vowelCode) / 21;

            int firstConsonantCOde = code; // Remained First Consonant

            // Get character in that list
            char firstConsonantChar = firstConsonant[firstConsonantCOde];
            char vowelChar = GetVowelType(vowel[vowelCode]);
            char lastConsonantChar = lastConsonant[lastConsonantCode];

            return vowelChar;
        }

        private static char GetVowelType(char c)
        {
            char result = ' ';
            if (aTypeVowel.Contains(c))
            {
                result = (char)VowelType.A;
            }
            else if (eTypeVowel.Contains(c))
            {
                result = (char)VowelType.E;
            }
            else if (iTypeVowel.Contains(c))
            {
                result = (char)VowelType.I;
            }
            else if (oTypeVowel.Contains(c)|| uTypeVowel.Contains(c))
            {
                result = (char)VowelType.O;
            }
            //else if (uTypeVowel.Contains(c))
            //{
            //    result = (char)VowelType.U;
            //}

            return result;
        }
    }

}
